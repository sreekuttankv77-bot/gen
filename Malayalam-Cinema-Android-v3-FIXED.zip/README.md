# Malayalam Cinema — Android

Apple-style Malayalam film catalogue starter project.

## Why the previous ZIP failed

The previous archive had an extra directory layer:

`project/malayalam_cinema/...`

and did not contain `gradlew` at the actual Gradle project root. The workflow therefore could not locate the Android project.

This ZIP is intentionally flat. The root contains:

- `settings.gradle`
- `build.gradle`
- `gradlew`
- `gradlew.bat`
- `app/`
- `.github/workflows/build-apk.yml`

## Data

`app/src/main/assets/movies.json` contains a small verified starter catalogue for the UI/build test. It is not a 7,000+ movie database.

For a large catalogue, the app should use a separate data source/API or a properly licensed dataset rather than bundling scraped commercial database content.

## Build

The included GitHub Actions workflow installs Gradle 8.10.2 and Java 17, then runs:

`./gradlew --no-daemon assembleDebug`

The generated APK is uploaded as the workflow artifact `Malayalam-Cinema-debug`.
