package com.codemate.ai.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.codemate.ai.R;
import com.codemate.ai.data.ApiProfile;
import com.codemate.ai.data.AppStorage;
import com.codemate.ai.data.ChatSession;
import com.codemate.ai.ui.adapter.ChatListAdapter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private AppStorage storage;
    private RecyclerView recyclerView;
    private ChatListAdapter adapter;
    private TextView emptyView;
    private List<ChatSession> chats = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        storage = new AppStorage(this);

        recyclerView = findViewById(R.id.recycler_chats);
        emptyView = findViewById(R.id.text_empty);
        FloatingActionButton fabNew = findViewById(R.id.fab_new_chat);
        View settingsBtn = findViewById(R.id.btn_settings);
        View themeBtn = findViewById(R.id.btn_theme);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ChatListAdapter(chats, new ChatListAdapter.Listener() {
            @Override
            public void onChatClick(ChatSession session) {
                openChat(session.id);
            }

            @Override
            public void onChatDelete(ChatSession session) {
                chats.remove(session);
                storage.saveChats(chats);
                refreshEmptyState();
                adapter.notifyDataSetChanged();
            }
        });
        recyclerView.setAdapter(adapter);

        fabNew.setOnClickListener(v -> createNewChat());
        settingsBtn.setOnClickListener(v -> startActivity(new Intent(this, ProfilesActivity.class)));
        themeBtn.setOnClickListener(v -> cycleTheme());
    }

    private void cycleTheme() {
        AppStorage.Prefs prefs = storage.loadPrefs();
        String current = prefs.themeMode == null ? "system" : prefs.themeMode;
        String next;
        String message;
        switch (current) {
            case "light":
                next = "dark";
                message = "Dark theme";
                break;
            case "dark":
                next = "system";
                message = "System theme";
                break;
            default:
                next = "light";
                message = "Light theme";
                break;
        }
        prefs.themeMode = next;
        storage.savePrefs(prefs);
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
        com.codemate.ai.CodeMateApp.applyThemeMode(next);
        recreate();
    }

    @Override
    protected void onResume() {
        super.onResume();
        chats = storage.loadChats();
        adapter.updateData(chats);
        refreshEmptyState();
    }

    private void refreshEmptyState() {
        boolean empty = chats.isEmpty();
        emptyView.setVisibility(empty ? View.VISIBLE : View.GONE);
        recyclerView.setVisibility(empty ? View.GONE : View.VISIBLE);
    }

    private void createNewChat() {
        List<ApiProfile> profiles = storage.loadProfiles();
        if (profiles.isEmpty()) {
            Toast.makeText(this, "Add an API profile first", Toast.LENGTH_LONG).show();
            startActivity(new Intent(this, ProfilesActivity.class));
            return;
        }
        ChatSession session = new ChatSession();
        AppStorage.Prefs prefs = storage.loadPrefs();
        String profileId = prefs.lastProfileId;
        boolean valid = false;
        for (ApiProfile p : profiles) {
            if (p.id.equals(profileId)) { valid = true; break; }
        }
        session.profileId = valid ? profileId : profiles.get(0).id;

        chats.add(0, session);
        storage.saveChats(chats);
        openChat(session.id);
    }

    private void openChat(String chatId) {
        Intent intent = new Intent(this, ChatActivity.class);
        intent.putExtra("chat_id", chatId);
        startActivity(intent);
    }
}
