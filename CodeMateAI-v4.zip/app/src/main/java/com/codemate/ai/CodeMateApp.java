package com.codemate.ai;

import android.app.Application;

import androidx.appcompat.app.AppCompatDelegate;

import com.codemate.ai.data.AppStorage;

public class CodeMateApp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        AppStorage storage = new AppStorage(this);
        applyThemeMode(storage.loadPrefs().themeMode);
    }

    public static void applyThemeMode(String mode) {
        if ("light".equals(mode)) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        } else if ("dark".equals(mode)) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
        }
    }
}
