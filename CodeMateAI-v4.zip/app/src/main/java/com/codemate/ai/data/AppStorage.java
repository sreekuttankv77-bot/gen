package com.codemate.ai.data;

import android.content.Context;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Simple JSON-file-backed persistence layer. No external database needed:
 * profiles.json holds API profiles, chats.json holds all chat sessions.
 */
public class AppStorage {

    private static final String PROFILES_FILE = "profiles.json";
    private static final String CHATS_FILE = "chats.json";
    private static final String PREFS_FILE = "prefs.json";

    private final Gson gson = new Gson();
    private final File filesDir;

    public AppStorage(Context context) {
        this.filesDir = context.getApplicationContext().getFilesDir();
    }

    // ---------- Profiles ----------

    public List<ApiProfile> loadProfiles() {
        File f = new File(filesDir, PROFILES_FILE);
        if (!f.exists()) return new ArrayList<>();
        try (FileReader reader = new FileReader(f)) {
            Type type = new TypeToken<List<ApiProfile>>() {}.getType();
            List<ApiProfile> list = gson.fromJson(reader, type);
            return list != null ? list : new ArrayList<>();
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    public void saveProfiles(List<ApiProfile> profiles) {
        File f = new File(filesDir, PROFILES_FILE);
        try (FileWriter writer = new FileWriter(f)) {
            gson.toJson(profiles, writer);
        } catch (Exception ignored) {
        }
    }

    // ---------- Chats ----------

    public List<ChatSession> loadChats() {
        File f = new File(filesDir, CHATS_FILE);
        if (!f.exists()) return new ArrayList<>();
        try (FileReader reader = new FileReader(f)) {
            Type type = new TypeToken<List<ChatSession>>() {}.getType();
            List<ChatSession> list = gson.fromJson(reader, type);
            if (list == null) list = new ArrayList<>();
            Collections.sort(list, (a, b) -> Long.compare(b.updatedAt, a.updatedAt));
            return list;
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    public void saveChats(List<ChatSession> chats) {
        File f = new File(filesDir, CHATS_FILE);
        try (FileWriter writer = new FileWriter(f)) {
            gson.toJson(chats, writer);
        } catch (Exception ignored) {
        }
    }

    // ---------- Prefs (last used profile id etc.) ----------

    public static class Prefs {
        public String lastProfileId;
        public String themeMode; // "light", "dark", or null/"system"
    }

    public Prefs loadPrefs() {
        File f = new File(filesDir, PREFS_FILE);
        if (!f.exists()) return new Prefs();
        try (FileReader reader = new FileReader(f)) {
            Prefs p = gson.fromJson(reader, Prefs.class);
            return p != null ? p : new Prefs();
        } catch (Exception e) {
            return new Prefs();
        }
    }

    public void savePrefs(Prefs prefs) {
        File f = new File(filesDir, PREFS_FILE);
        try (FileWriter writer = new FileWriter(f)) {
            gson.toJson(prefs, writer);
        } catch (Exception ignored) {
        }
    }
}
