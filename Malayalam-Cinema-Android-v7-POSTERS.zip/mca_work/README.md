# Malayalam Cinema Android v7

- Same dark Apple-style UI as the previous version.
- Bottom navigation: Home, Years, Favorites, More. Search is only on Home.
- 106 Malayalam film records bundled locally (1928–2025).
- Every movie now has a bundled poster-style artwork card, so the app works offline without an image-loading dependency.
- App logo is bundled as `app_logo.png`.
- Poster artwork is metadata-based placeholder artwork, not a claim of being the original theatrical poster. Original poster scans can be substituted later from a properly sourced archive.

Poster/archive sources researched for a future original-poster pass include M3DB and Nostalgic Movie Posters.
