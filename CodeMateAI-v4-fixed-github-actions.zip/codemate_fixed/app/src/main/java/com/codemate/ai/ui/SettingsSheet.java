package com.codemate.ai.ui;

import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.codemate.ai.CodeMateApp;
import com.codemate.ai.R;
import com.codemate.ai.data.AppStorage;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.io.File;

/** Refined settings surface matching the dark/orange CodeMate design. */
public final class SettingsSheet {
    private SettingsSheet() {}

    public static void show(Context context) {
        BottomSheetDialog dialog = new BottomSheetDialog(context);
        View view = LayoutInflater.from(context).inflate(R.layout.dialog_settings_sheet, null);
        dialog.setContentView(view);
        dialog.setCanceledOnTouchOutside(true);

        AppStorage storage = new AppStorage(context);
        AppStorage.Prefs prefs = storage.loadPrefs();
        String theme = prefs.themeMode == null ? "dark" : prefs.themeMode;
        TextView themeValue = view.findViewById(R.id.text_theme_value);
        themeValue.setText(theme.substring(0,1).toUpperCase() + theme.substring(1) + " theme");

        Switch notifications = view.findViewById(R.id.switch_notifications);
        Switch autosave = view.findViewById(R.id.switch_autosave);
        Switch highlighting = view.findViewById(R.id.switch_highlighting);
        Switch lineNumbers = view.findViewById(R.id.switch_line_numbers);
        notifications.setChecked(prefs.notifications);
        autosave.setChecked(prefs.autoSaveChats);
        highlighting.setChecked(prefs.codeHighlighting);
        lineNumbers.setChecked(prefs.showLineNumbers);

        notifications.setOnCheckedChangeListener((b, checked) -> { prefs.notifications = checked; storage.savePrefs(prefs); });
        autosave.setOnCheckedChangeListener((b, checked) -> { prefs.autoSaveChats = checked; storage.savePrefs(prefs); });
        highlighting.setOnCheckedChangeListener((b, checked) -> { prefs.codeHighlighting = checked; storage.savePrefs(prefs); });
        lineNumbers.setOnCheckedChangeListener((b, checked) -> { prefs.showLineNumbers = checked; storage.savePrefs(prefs); });

        view.findViewById(R.id.setting_appearance).setOnClickListener(v -> {
            String next = "dark".equals(theme) ? "system" : ("system".equals(theme) ? "light" : "dark");
            prefs.themeMode = next;
            storage.savePrefs(prefs);
            CodeMateApp.applyThemeMode(next);
            dialog.dismiss();
        });
        view.findViewById(R.id.setting_behavior).setOnClickListener(v -> Toast.makeText(context, "Behavior settings are shown below", Toast.LENGTH_SHORT).show());
        view.findViewById(R.id.setting_language).setOnClickListener(v -> new androidx.appcompat.app.AlertDialog.Builder(context)
                .setTitle("Language").setSingleChoiceItems(new String[]{"System", "English"}, 0, (d, which) -> d.dismiss()).show());

        TextView cache = view.findViewById(R.id.text_cache_size);
        cache.setText(formatSize(dirSize(context.getCacheDir())) + "  ›");
        view.findViewById(R.id.action_clear_cache).setOnClickListener(v -> {
            clearCache(context.getCacheDir());
            cache.setText("0 MB  ›");
            Toast.makeText(context, "Cache cleared", Toast.LENGTH_SHORT).show();
        });
        view.findViewById(R.id.action_export_chats).setOnClickListener(v -> Toast.makeText(context, "Use Export Chat from a conversation to share a chat", Toast.LENGTH_LONG).show());
        view.findViewById(R.id.action_about).setOnClickListener(v -> new androidx.appcompat.app.AlertDialog.Builder(context)
                .setTitle("CodeMate AI").setMessage("Version 1.0.0\n\nA focused AI coding companion for chat, code, files, and model profiles.")
                .setPositiveButton("OK", null).show());

        dialog.setOnShowListener(d -> {
            View sheet = dialog.findViewById(com.google.android.material.R.id.design_bottom_sheet);
            if (sheet != null) {
                sheet.setBackgroundResource(android.R.color.transparent);
                com.google.android.material.bottomsheet.BottomSheetBehavior<?> behavior = com.google.android.material.bottomsheet.BottomSheetBehavior.from(sheet);
                behavior.setSkipCollapsed(true);
                behavior.setState(com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_EXPANDED);
            }
        });
        dialog.show();
    }

    private static long dirSize(File file) {
        if (file == null || !file.exists()) return 0;
        if (file.isFile()) return file.length();
        long total = 0;
        File[] files = file.listFiles();
        if (files != null) for (File child : files) total += dirSize(child);
        return total;
    }

    private static void clearCache(File file) {
        if (file == null || !file.exists()) return;
        File[] files = file.listFiles();
        if (files != null) for (File child : files) deleteRecursively(child);
    }

    private static void deleteRecursively(File f) {
        if (f.isDirectory()) {
            File[] children = f.listFiles();
            if (children != null) for (File c : children) deleteRecursively(c);
        }
        // Do not delete the cache directory itself.
        f.delete();
    }

    private static String formatSize(long bytes) {
        return String.format(java.util.Locale.US, "%.1f MB", bytes / 1024f / 1024f);
    }
}
