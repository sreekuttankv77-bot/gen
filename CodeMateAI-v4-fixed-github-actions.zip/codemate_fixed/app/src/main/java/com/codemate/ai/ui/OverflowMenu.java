package com.codemate.ai.ui;

import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.PopupWindow;
import android.widget.Toast;

import com.codemate.ai.R;

/** Compact custom overflow menu matching the reference design. */
public final class OverflowMenu {
    public interface Listener {
        void newChat();
        void history();
        void profiles();
        void settings();
        void exportChat();
        void importData();
        void clearChat();
    }

    private OverflowMenu() {}

    public static void show(Context context, View anchor, Listener listener) {
        View menu = LayoutInflater.from(context).inflate(R.layout.popup_overflow, null);
        PopupWindow popup = new PopupWindow(menu, dp(context, 228), android.view.ViewGroup.LayoutParams.WRAP_CONTENT, true);
        popup.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
        popup.setOutsideTouchable(true);
        popup.setElevation(dp(context, 14));
        bind(menu, R.id.menu_new_chat, popup, listener::newChat);
        bind(menu, R.id.menu_history, popup, listener::history);
        bind(menu, R.id.menu_profiles, popup, listener::profiles);
        bind(menu, R.id.menu_settings, popup, listener::settings);
        bind(menu, R.id.menu_export, popup, listener::exportChat);
        bind(menu, R.id.menu_import, popup, listener::importData);
        bind(menu, R.id.menu_clear, popup, listener::clearChat);
        popup.showAsDropDown(anchor, -dp(context, 190), dp(context, 6), Gravity.END);
    }

    private static void bind(View root, int id, PopupWindow popup, Runnable action) {
        root.findViewById(id).setOnClickListener(v -> { popup.dismiss(); action.run(); });
    }
    private static int dp(Context c, int v) { return (int)(v * c.getResources().getDisplayMetrics().density + 0.5f); }
}
