package com.codemate.ai.data;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ChatSession {
    public String id;
    public String title;
    public String profileId;
    public long createdAt;
    public long updatedAt;
    public List<ChatMessage> messages = new ArrayList<>();

    public ChatSession() {
        this.id = UUID.randomUUID().toString();
        this.createdAt = System.currentTimeMillis();
        this.updatedAt = this.createdAt;
        this.title = "New Chat";
    }

    public String preview() {
        for (int i = messages.size() - 1; i >= 0; i--) {
            ChatMessage m = messages.get(i);
            if (m.content != null && !m.content.trim().isEmpty()) {
                String c = m.content.trim().replace("\n", " ");
                return c.length() > 60 ? c.substring(0, 60) + "…" : c;
            }
        }
        return "No messages yet";
    }
}
