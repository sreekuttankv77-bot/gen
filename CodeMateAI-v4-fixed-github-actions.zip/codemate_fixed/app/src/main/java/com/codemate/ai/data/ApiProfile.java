package com.codemate.ai.data;

import java.util.UUID;

public class ApiProfile {
    public String id;
    public String name;
    public String baseUrl;
    public String apiKey;
    public String model;
    public double temperature = 0.7;
    public boolean supportsImageGen = false; // if true, the image-gen button becomes available for chats using this profile
    public String systemPrompt = "";         // optional persona / custom instructions sent as the system message

    public ApiProfile() {
        this.id = UUID.randomUUID().toString();
    }

    public ApiProfile(String name, String baseUrl, String apiKey, String model) {
        this.id = UUID.randomUUID().toString();
        this.name = name;
        this.baseUrl = baseUrl;
        this.apiKey = apiKey;
        this.model = model;
    }
}
