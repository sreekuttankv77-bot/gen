package com.codemate.ai.data;

public class ChatMessage {
    public static final String ROLE_USER = "user";
    public static final String ROLE_ASSISTANT = "assistant";
    public static final String ROLE_SYSTEM = "system";

    public String role;
    public String content;
    public long timestamp;
    public boolean isError;

    // --- Optional attachment metadata (set on user messages) ---
    public String attachmentName;          // display label, e.g. "notes.txt" or "photo.jpg"
    public String attachmentMime;          // mime type of the attached file, if known
    public String attachmentImageBase64;   // raw base64 (no data: prefix) when the attachment is an image
    public String attachmentTextContent;   // extracted text content when the attachment is a text/code file

    // --- Generated image result (set on assistant messages produced by image generation) ---
    public String generatedImageBase64;    // raw base64 PNG data returned by an image-gen call

    public ChatMessage() {
    }

    public ChatMessage(String role, String content) {
        this.role = role;
        this.content = content;
        this.timestamp = System.currentTimeMillis();
    }
}
