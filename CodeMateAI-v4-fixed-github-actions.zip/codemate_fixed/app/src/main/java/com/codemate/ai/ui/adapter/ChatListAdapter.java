package com.codemate.ai.ui.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.codemate.ai.R;
import com.codemate.ai.data.ChatSession;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;

public class ChatListAdapter extends RecyclerView.Adapter<ChatListAdapter.VH> {

    public interface Listener {
        void onChatClick(ChatSession session);
        void onChatDelete(ChatSession session);
    }

    private List<ChatSession> data;
    private final Listener listener;

    public ChatListAdapter(List<ChatSession> data, Listener listener) {
        this.data = data;
        this.listener = listener;
    }

    public void updateData(List<ChatSession> newData) {
        this.data = newData;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_chat_session, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        ChatSession session = data.get(position);
        holder.title.setText(session.title == null || session.title.trim().isEmpty() ? "New Chat" : session.title);
        holder.preview.setText(session.preview());
        holder.time.setText(DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
                .format(new Date(session.updatedAt)));
        holder.itemView.setOnClickListener(v -> listener.onChatClick(session));
        holder.delete.setOnClickListener(v -> listener.onChatDelete(session));
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView title, preview, time;
        ImageView delete;

        VH(View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.text_title);
            preview = itemView.findViewById(R.id.text_preview);
            time = itemView.findViewById(R.id.text_time);
            delete = itemView.findViewById(R.id.btn_delete);
        }
    }
}
