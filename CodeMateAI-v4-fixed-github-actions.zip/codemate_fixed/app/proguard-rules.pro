# Default rules
-keep class com.codemate.ai.data.** { *; }
