# Malayalam Cinema Android v8

Updated from v7 with the original dark Apple-style UI preserved.

## UI fixes
- Bottom navigation: Home, Years, Favorites, More (no Search tab).
- Home keeps the main search field.
- App logo remains the supplied club/spade logo.
- Home movie cards now use a proper 2:3 poster ratio, larger readable titles, year overlay, favorite button, and consistent spacing.
- Year/decade/favorites grids use the same poster card component and no longer crop the card height.
- Poster cards are sized for common 360dp Android layouts and scale cleanly.

## Posters
The previous v7 poster files were decorative placeholders, not real movie posters. v8 keeps them only as offline fallbacks and now attempts to load a real poster image for each movie from Wikipedia/Wikimedia Commons using the movie title + year. Downloaded posters are cached locally so they remain available after the first successful load.

No TMDB API key is required.
