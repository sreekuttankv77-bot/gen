package com.malayalam.cinema;

import android.app.*;import android.os.*;import android.content.*;import android.net.Uri;import android.graphics.*;import android.graphics.drawable.GradientDrawable;import android.text.*;import android.view.*;import android.widget.*;import java.io.*;import java.net.*;import java.nio.charset.StandardCharsets;import java.util.*;import java.util.concurrent.*;import org.json.*;import org.jsoup.Jsoup;import org.jsoup.nodes.Document;import org.jsoup.nodes.Element;import org.jsoup.select.Elements;

public class MainActivity extends Activity{
    final ArrayList<Movie> all=new ArrayList<>(); final ArrayList<Movie> shown=new ArrayList<>();
    final ExecutorService posterExecutor=Executors.newFixedThreadPool(3);
    final ExecutorService catalogExecutor=Executors.newFixedThreadPool(6);
    final ExecutorService directorExecutor=Executors.newFixedThreadPool(2); volatile boolean syncRunning=false;
    LinearLayout bottom; FrameLayout content; SharedPreferences prefs; int accent=Color.rgb(232,184,109), white=Color.rgb(242,242,245), muted=Color.rgb(142,142,152), card=Color.rgb(28,28,36), bg=Color.rgb(14,14,18), line=Color.rgb(42,42,52);
    int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);} TextView tv(String s,float size,int color){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(color);return v;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);return l;} LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.rgb(14,14,18));getWindow().setNavigationBarColor(Color.rgb(14,14,18));setContentView(R.layout.activity_main);prefs=getSharedPreferences("favorites",0);content=findViewById(R.id.content);bottom=findViewById(R.id.bottomNav);load();buildNav();home();syncAllYears();}
    void load(){
      try{
        File cache=new File(getFilesDir(),"movies_full_v22.json");
        byte[] d;
        if(cache.exists() && cache.length()>100){ d=readBytes(new FileInputStream(cache)); }
        else { InputStream in=getAssets().open("movies.json"); d=readBytes(in); in.close(); }
        JSONArray a=new JSONArray(new String(d,StandardCharsets.UTF_8));
        for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);all.add(Movie.fromJson(o));}
      }catch(Exception ignored){}
      dedupeEnglish();
      shown.addAll(all);
    }
    byte[] readBytes(InputStream in)throws IOException{ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)out.write(b,0,n);return out.toByteArray();}

    void syncAllYears(){
      // Populate the complete archive in the background from 1928 through the current year.
      for(int y=1928;y<=2026;y++) syncYearIfNeeded(y);
    }

    void syncYearIfNeeded(int year){
      if(year<1928||year>2026)return;
      String marker="year_"+year;
      if(prefs.getBoolean(marker,false))return;
      catalogExecutor.execute(()->{
        try{
          ArrayList<Movie> fetched=fetchMalayalaChalachithramYear(year);
          if(!fetched.isEmpty()){
            synchronized(all){ for(Movie m:fetched){ boolean exists=false; for(Movie x:all){ if(x.key().equals(m.key())){exists=true;break;} } if(!exists) all.add(m); } }
            JSONArray out=new JSONArray(); synchronized(all){ Collections.sort(all,(a,b)->{int c=Integer.compare(b.year,a.year);return c!=0?c:a.title.compareToIgnoreCase(b.title);}); for(Movie m:all)out.put(m.toJson()); }
            FileOutputStream fos=openFileOutput("movies_full_v22.json",MODE_PRIVATE);fos.write(out.toString().getBytes(StandardCharsets.UTF_8));fos.close();
            prefs.edit().putBoolean(marker,true).apply();
            runOnUiThread(()->{ if(currentPageYear==year) yearPage(year); else if(currentPageDecade==year/10*10) decadePage(currentPageDecade); });
          }
        }catch(Exception ignored){}
      });
    }
    int currentPageYear=-1,currentPageDecade=-1;
    ArrayList<Movie> fetchMalayalaChalachithramYear(int year){
      ArrayList<Movie> result=new ArrayList<>();
      try{
        Document doc=Jsoup.connect("https://www.malayalachalachithram.com/movieslist.php?y="+year+"&ln=en").userAgent("Mozilla/5.0 CHITHRAM/22").timeout(15000).get();
        Elements blocks=doc.select("body a");
        HashSet<String> seen=new HashSet<>();
        for(Element a:blocks){
          String title=a.text().trim(); String href=a.attr("href");
          if(title.isEmpty()||href.isEmpty()||!href.contains("movie.php")||title.length()>140)continue;
          String norm=title.replaceAll("[^A-Za-z0-9 ]"," ").replaceAll("\\s+"," ").trim().toLowerCase(Locale.ROOT);
          if(norm.isEmpty()||seen.contains(norm))continue;
          seen.add(norm); Movie m=new Movie(title,year,"Unknown","Unknown","","");m.source="MalayalaChalachithram";result.add(m);
        }
      }catch(Exception ignored){}
      return result;
    }

    void dedupeEnglish(){
      LinkedHashMap<String,Movie> u=new LinkedHashMap<>();
      for(Movie m:all){ String k=m.key(); if(!u.containsKey(k))u.put(k,m); }
      all.clear();all.addAll(u.values());
    }
    TextView label(String s,float sz,int c){TextView v=tv(s,sz,c);v.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));return v;}
    TextView bold(String s,float sz,int c){TextView v=tv(s,sz,c);v.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));return v;}
    void pad(View v,int l,int t,int r,int b){v.setPadding(dp(l),dp(t),dp(r),dp(b));}

    // Floating navigation keeps the app calm and spacious. Search lives on Home.
    int activeTab=0;
    final TextView[] navItems=new TextView[4];
    void buildNav(){
      String[] names={"Home","Years","Favorites","More"};
      int[] icons={R.drawable.ic_home,R.drawable.ic_calendar,R.drawable.ic_heart,R.drawable.ic_more};
      bottom.removeAllViews();
      for(int i=0;i<4;i++){
        final int n=i; LinearLayout item=col(); item.setGravity(Gravity.CENTER); item.setPadding(0,dp(4),0,dp(3));
        ImageView iv=new ImageView(this); iv.setImageResource(icons[i]); iv.setColorFilter(i==0?accent:muted);
        item.addView(iv,new LinearLayout.LayoutParams(dp(22),dp(22)));
        TextView v=bold(names[i],11,i==0?accent:muted); v.setGravity(Gravity.CENTER);
        item.addView(v,new LinearLayout.LayoutParams(-1,dp(22)));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1); bottom.addView(item,p); navItems[i]=v;
        item.setOnClickListener(x->setTab(n));
      }
    }
    void setTab(int n){
      activeTab=n;
      for(int i=0;i<navItems.length;i++)if(navItems[i]!=null){
        navItems[i].setTextColor(i==n?accent:muted);
        View parent=(View)navItems[i].getParent();
        if(parent instanceof LinearLayout) ((ImageView)((LinearLayout)parent).getChildAt(0)).setColorFilter(i==n?accent:muted);
      }
      if(n==0)home();else if(n==1)years();else if(n==2)favorites();else more();
    }
    void clear(){content.removeAllViews();}
    ScrollView scroll(LinearLayout l){ScrollView s=new ScrollView(this);s.setFillViewport(true);s.addView(l);return s;}

    void home(){clear();LinearLayout l=col();pad(l,20,20,20,28);
      LinearLayout head=row();LinearLayout h=col();h.setLayoutParams(new LinearLayout.LayoutParams(0,-2,1));TextView small=bold("CHITHRAM",12,accent);small.setLetterSpacing(.16f);h.addView(small);h.addView(bold("Malayalam cinema,\nbeautifully archived.",26,white));h.addView(label("Every year. Every story. One place.",13,muted),marginTop(5));head.addView(h);ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.app_logo);logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);head.addView(logo,new LinearLayout.LayoutParams(dp(52),dp(58)));l.addView(head);
      EditText search=new EditText(this);search.setHint("⌕  Search films, actors or directors");search.setTextColor(white);search.setHintTextColor(muted);search.setTextSize(14);search.setSingleLine();search.setBackgroundResource(R.drawable.bg_search);pad(search,18,0,18,0);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(50));sp.topMargin=dp(18);l.addView(search,sp);search.setOnEditorActionListener((v,a,e)->{search();return true;});search.setOnClickListener(v->search());
      LinearLayout hero=col();hero.setBackgroundResource(R.drawable.bg_hero);pad(hero,18,18,14,16);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,dp(218));hp.topMargin=dp(18);l.addView(hero,hp);
      LinearLayout heroRow=row();LinearLayout copy=col();copy.setLayoutParams(new LinearLayout.LayoutParams(0,-1,1));copy.addView(bold("The archive",13,0xFFB8A890));copy.addView(bold("A living history\nof Malayalam film.",21,white),marginTop(5));copy.addView(label("Discover films from 1928 to today.",12,0xFF9A9080),marginTop(8));TextView explore=bold("Browse the years  ->",12,white);explore.setPadding(0,dp(13),0,0);copy.addView(explore);explore.setOnClickListener(v->years());heroRow.addView(copy);
      LinearLayout stack=row();stack.setGravity(Gravity.CENTER_VERTICAL);ArrayList<Movie> feature=pick(3);for(int i=0;i<feature.size();i++){ImageView pi=new ImageView(this);pi.setScaleType(ImageView.ScaleType.CENTER_CROP);pi.setBackgroundResource(R.drawable.bg_poster);pi.setClipToOutline(true);LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(dp(66),dp(100));pp.leftMargin=dp(-8);if(i==1)pp.topMargin=dp(-10);if(i==2)pp.topMargin=dp(8);stack.addView(pi,pp);pi.setRotation(i==0?-6:(i==2?6:0));loadPoster(pi,feature.get(i));}heroRow.addView(stack);hero.addView(heroRow,new LinearLayout.LayoutParams(-1,0,1));
      l.addView(sectionHeader("New Releases","Fresh from the archive",false),marginTop(24));LinearLayout latest=row();latest.setPadding(0,dp(10),0,0);ArrayList<Movie> recent=new ArrayList<>(all);Collections.sort(recent,(a,b)->{int c=Integer.compare(b.year,a.year);return c!=0?c:a.title.compareToIgnoreCase(b.title);});for(int i=0;i<Math.min(7,recent.size());i++)latest.addView(posterCard(recent.get(i)));HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);hs.addView(latest);l.addView(hs);
      l.addView(sectionHeader("Malayalam Classics","Films worth coming back to",false),marginTop(24));LinearLayout classics=row();classics.setPadding(0,dp(10),0,0);ArrayList<Movie> old=new ArrayList<>();for(Movie m:all)if(m.year>0&&m.year<=1999)old.add(m);Collections.sort(old,(a,b)->{int c=Integer.compare(b.year,a.year);return c!=0?c:a.title.compareToIgnoreCase(b.title);});for(int i=0;i<Math.min(7,old.size());i++)classics.addView(posterCard(old.get(i)));HorizontalScrollView cs=new HorizontalScrollView(this);cs.setHorizontalScrollBarEnabled(false);cs.addView(classics);l.addView(cs);
      l.addView(sectionHeader("Directors","The filmmakers behind Malayalam cinema",false),marginTop(24));LinearLayout directors=row();directors.setPadding(0,dp(10),0,dp(0));ArrayList<String> directorNames=new ArrayList<>();LinkedHashMap<String,Movie> directorMovies=new LinkedHashMap<>();for(Movie m:all){String d=m.director==null?"":m.director.trim();if(d.isEmpty()||d.equalsIgnoreCase("Unknown")||d.equalsIgnoreCase("unknown"))continue;for(String part:d.split("\\s*,\\s*")){String dn=part.trim();if(dn.isEmpty()||dn.equalsIgnoreCase("Unknown"))continue;if(!directorMovies.containsKey(dn))directorMovies.put(dn,m);}}directorNames.addAll(directorMovies.keySet());Collections.sort(directorNames,(a,b)->{Movie ma=directorMovies.get(a),mb=directorMovies.get(b);int c=Integer.compare(mb.year,ma.year);return c!=0?c:a.compareToIgnoreCase(b);});for(int i=0;i<Math.min(7,directorNames.size());i++){String dn=directorNames.get(i);directors.addView(directorCard(dn,directorMovies.get(dn)));}HorizontalScrollView ds=new HorizontalScrollView(this);ds.setHorizontalScrollBarEnabled(false);ds.addView(directors);l.addView(ds);      content.addView(scroll(l));
    }
    TextView sectionHeader(String title,String sub,boolean isAccent){TextView t=bold(title,17,white);t.setLetterSpacing(.02f);return t;}
    TextView softTile(String title,String sub,String icon){TextView v=bold(icon+"  "+title+"\n"+sub,14,white);v.setBackgroundResource(R.drawable.bg_card);v.setGravity(Gravity.CENTER_VERTICAL);v.setPadding(dp(16),0,dp(10),0);return v;}
    LinearLayout.LayoutParams marginTop(int n){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(n);return p;}
    TextView chip(String s,boolean sel){TextView c=bold(s,12,sel?Color.rgb(20,16,10):white);c.setGravity(Gravity.CENTER);c.setBackgroundResource(R.drawable.bg_chip);c.setSelected(sel);return c;}
    ArrayList<Movie> pick(int n){ArrayList<Movie>x=new ArrayList<>();for(Movie m:all){if(x.size()>=n)break;if(m.year>=1990)x.add(m);}return x;}
    View posterCard(Movie m){
      LinearLayout wrap=col();wrap.setLayoutParams(new LinearLayout.LayoutParams(dp(126),dp(214)));wrap.setPadding(0,0,dp(10),0);
      FrameLayout cardView=new FrameLayout(this);cardView.setBackgroundResource(R.drawable.bg_poster);cardView.setClipToOutline(true);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(116),dp(168));cardView.setLayoutParams(cp);
      ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);im.setBackgroundColor(Color.rgb(36,36,44));im.setImageResource(android.R.drawable.ic_menu_report_image);im.setColorFilter(0x66FFFFFF);cardView.addView(im,new FrameLayout.LayoutParams(-1,-1));
      TextView heart=bold(prefs.getBoolean(m.key(),false)?"♥":"♡",18,prefs.getBoolean(m.key(),false)?accent:white);heart.setGravity(Gravity.CENTER);GradientDrawable hb=new GradientDrawable();hb.setColor(0xCC1C1C24);hb.setShape(GradientDrawable.OVAL);heart.setBackground(hb);FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(dp(34),dp(34),Gravity.RIGHT|Gravity.TOP);hp.setMargins(0,dp(7),dp(7),0);cardView.addView(heart,hp);heart.setOnClickListener(v->{boolean n=!prefs.getBoolean(m.key(),false);prefs.edit().putBoolean(m.key(),n).apply();heart.setText(n?"♥":"♡");heart.setTextColor(n?accent:white);});
      cardView.setOnClickListener(v->details(m));loadPoster(im,m);wrap.addView(cardView);TextView title=bold(m.title,13,white);title.setMaxLines(2);title.setEllipsize(TextUtils.TruncateAt.END);title.setPadding(0,dp(8),dp(4),0);wrap.addView(title);wrap.setOnClickListener(v->details(m));return wrap;
    }
    View directorCard(String name, Movie representative){
      LinearLayout wrap=col();wrap.setLayoutParams(new LinearLayout.LayoutParams(dp(126),dp(214)));wrap.setPadding(0,0,dp(10),0);
      FrameLayout cardView=new FrameLayout(this);cardView.setBackgroundResource(R.drawable.bg_poster);cardView.setClipToOutline(true);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(116),dp(168));cardView.setLayoutParams(cp);
      ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);im.setBackgroundColor(Color.rgb(36,36,44));im.setImageResource(android.R.drawable.ic_menu_report_image);im.setColorFilter(0x66FFFFFF);cardView.addView(im,new FrameLayout.LayoutParams(-1,-1));
      TextView badge=bold("DIRECTOR",10,Color.WHITE);badge.setGravity(Gravity.CENTER);GradientDrawable gb=new GradientDrawable();gb.setColor(0xCC2A2218);gb.setCornerRadius(dp(10));badge.setBackground(gb);FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(76),dp(26),Gravity.LEFT|Gravity.TOP);bp.setMargins(dp(7),dp(7),0,0);cardView.addView(badge,bp);
      loadDirectorPhoto(im,name);wrap.addView(cardView);TextView title=bold(name,13,white);title.setMaxLines(2);title.setEllipsize(TextUtils.TruncateAt.END);title.setPadding(0,dp(8),dp(4),0);wrap.addView(title);wrap.setOnClickListener(v->directorPage(name));return wrap;
    }
    void directorPage(String director){clear();LinearLayout l=col();pad(l,20,22,20,24);LinearLayout head=row();TextView b=bold("‹",30,white);head.addView(b,new LinearLayout.LayoutParams(dp(40),dp(48)));b.setOnClickListener(v->home());LinearLayout h=col();h.addView(bold(director,22,white));int count=0;for(Movie m:all)if(m.director!=null&&Arrays.asList(m.director.split("\\s*,\\s*")).contains(director))count++;h.addView(label(count+" films",13,muted));head.addView(h,new LinearLayout.LayoutParams(0,-2,1));l.addView(head);GridLayout grid=new GridLayout(this);grid.setColumnCount(2);for(Movie m:all){if(m.director==null)continue;boolean match=false;for(String d:m.director.split("\\s*,\\s*"))if(d.trim().equalsIgnoreCase(director)){match=true;break;}if(match){View v=posterCard(m);GridLayout.LayoutParams gp=new GridLayout.LayoutParams();int gw=Math.max(dp(132),(getResources().getDisplayMetrics().widthPixels-dp(56))/2);gp.width=gw;gp.height=(int)(gw*1.5f);gp.setMargins(dp(4),dp(6),dp(4),dp(6));grid.addView(v,gp);}}l.addView(grid,marginTop(12));content.addView(scroll(l));}
    void loadDirectorPhoto(ImageView target, String name){
      String key=name.replaceAll("[^A-Za-z0-9_-]","_"); File cache=new File(getCacheDir(),"director_"+key+".jpg");
      if(cache.exists()){Bitmap b=BitmapFactory.decodeFile(cache.getAbsolutePath());if(b!=null){target.setImageBitmap(b);target.clearColorFilter();return;}}
      target.setImageResource(android.R.drawable.ic_menu_myplaces);
      directorExecutor.execute(()->{try{
        String q=URLEncoder.encode(name,"UTF-8");
        URL u=new URL("https://en.wikipedia.org/w/api.php?action=query&prop=pageimages&piprop=thumbnail&pithumbsize=500&titles="+q+"&format=json&origin=*");
        HttpURLConnection c=(HttpURLConnection)u.openConnection();c.setConnectTimeout(7000);c.setReadTimeout(10000);c.setRequestProperty("User-Agent","CHITHRAM-Malayalam-Cinema/2.1");
        InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);in.close();c.disconnect();
        JSONObject root=new JSONObject(out.toString(StandardCharsets.UTF_8.name()));JSONObject pages=root.optJSONObject("query")==null?null:root.getJSONObject("query").optJSONObject("pages");String src=null;
        if(pages!=null){Iterator<String> it=pages.keys();while(it.hasNext()){JSONObject page=pages.getJSONObject(it.next());JSONObject th=page.optJSONObject("thumbnail");if(th!=null){src=th.optString("source",null);if(src!=null&&!src.isEmpty())break;}}}
        if(src==null)return;HttpURLConnection ic=(HttpURLConnection)new URL(src).openConnection();ic.setConnectTimeout(7000);ic.setReadTimeout(10000);ic.setRequestProperty("User-Agent","CHITHRAM-Malayalam-Cinema/2.1");InputStream pi=ic.getInputStream();FileOutputStream fos=new FileOutputStream(cache);byte[] bb=new byte[8192];int k;while((k=pi.read(bb))!=-1)fos.write(bb,0,k);pi.close();fos.close();ic.disconnect();
        Bitmap b=BitmapFactory.decodeFile(cache.getAbsolutePath());if(b!=null)runOnUiThread(()->{target.setImageBitmap(b);target.clearColorFilter();target.setScaleType(ImageView.ScaleType.CENTER_CROP);});
      }catch(Exception ignored){}});
    }

    void loadPoster(ImageView target, Movie m){
      final String key=m.key().replaceAll("[^A-Za-z0-9_-]","_"); final File cache=new File(getCacheDir(),"poster_"+key+".jpg");
      // Prefer the poster bundled into the APK. Network lookup is only a fallback.
      if(m.posterLocal!=null&&!m.posterLocal.isEmpty()){try{InputStream ai=getAssets().open(m.posterLocal);Bitmap b=BitmapFactory.decodeStream(ai);ai.close();if(b!=null){target.setImageBitmap(b);target.clearColorFilter();return;}}catch(Exception ignored){}}
      if(cache.exists()){Bitmap b=BitmapFactory.decodeFile(cache.getAbsolutePath());if(b!=null){target.setImageBitmap(b);target.clearColorFilter();return;}}
      posterExecutor.execute(()->{try{
        String src=null;
        // 1) M3DB: try its film slug and read the real og:image poster.
        String slug=m.title.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+","-").replaceAll("^-|-$","");
        String[] m3urls={"https://m3db.com/film/"+slug,"https://m3db.com/film/"+slug+"-"+m.year};
        for(String pageUrl:m3urls){
          try{
            HttpURLConnection c=(HttpURLConnection)new URL(pageUrl).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(10000);c.setRequestProperty("User-Agent","Mozilla/5.0 (Android) Chithram/1.0");
            InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);in.close();c.disconnect();
            String html=out.toString(StandardCharsets.UTF_8.name()); java.util.regex.Matcher mm=java.util.regex.Pattern.compile("<meta[^>]+property=[\\\"']og:image[\\\"'][^>]+content=[\\\"']([^\\\"']+)",java.util.regex.Pattern.CASE_INSENSITIVE).matcher(html); if(mm.find()){src=mm.group(1);break;}
          }catch(Exception ignored){}
        }
        // 2) Wikipedia: exact film page thumbnail only.
        if(src==null){
          String[] titles={m.title+" (film)",m.title+" ("+m.year+" film)",m.title+" ("+m.year+" Malayalam film)",m.title};
          for(String title:titles){
            try{
              String tq=URLEncoder.encode(title,"UTF-8"); URL u=new URL("https://en.wikipedia.org/w/api.php?action=query&prop=pageimages&piprop=thumbnail&pithumbsize=700&titles="+tq+"&format=json&origin=*");
              HttpURLConnection c=(HttpURLConnection)u.openConnection();c.setConnectTimeout(7000);c.setReadTimeout(10000);c.setRequestProperty("User-Agent","Chithram-Malayalam-Cinema-Demo/1.0");
              InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);in.close();c.disconnect();
              JSONObject root=new JSONObject(out.toString(StandardCharsets.UTF_8.name()));JSONObject pages=root.optJSONObject("query")==null?null:root.getJSONObject("query").optJSONObject("pages");
              if(pages!=null){Iterator<String> it=pages.keys();while(it.hasNext()){JSONObject page=pages.getJSONObject(it.next());JSONObject th=page.optJSONObject("thumbnail");if(th!=null){String candidate=th.optString("source",null);if(candidate!=null&&!candidate.isEmpty()){src=candidate;break;}}}}
              if(src!=null)break;
            }catch(Exception ignored){}
          }
        }
        // 3) Wikimedia Commons: search specifically for poster + title, never use a generic film still.
        if(src==null){
          try{
            String q=URLEncoder.encode(m.title+" poster Malayalam","UTF-8"); URL cu=new URL("https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrsearch="+q+"&gsrnamespace=6&gsrlimit=10&prop=imageinfo&iiprop=url|mime|size&iiurlwidth=700&format=json&origin=*");
            HttpURLConnection c=(HttpURLConnection)cu.openConnection();c.setConnectTimeout(7000);c.setReadTimeout(10000);c.setRequestProperty("User-Agent","Chithram-Malayalam-Cinema-Demo/1.0");InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);in.close();c.disconnect();
            JSONObject cr=new JSONObject(out.toString(StandardCharsets.UTF_8.name()));JSONObject cp=cr.optJSONObject("query")==null?null:cr.getJSONObject("query").optJSONObject("pages");
            if(cp!=null){ArrayList<JSONObject> candidates=new ArrayList<>();Iterator<String> it=cp.keys();while(it.hasNext())candidates.add(cp.getJSONObject(it.next()));Collections.sort(candidates,(a,b)->Integer.compare(scorePoster(b,m),scorePoster(a,m)));for(JSONObject page:candidates){if(scorePoster(page,m)>0){JSONArray ia=page.optJSONArray("imageinfo");if(ia!=null&&ia.length()>0){JSONObject ii=ia.getJSONObject(0);src=ii.optString("thumburl",ii.optString("url",null));if(src!=null&&!src.isEmpty())break;}}}}
          }catch(Exception ignored){}
        }
        if(src==null)return;
        HttpURLConnection ic=(HttpURLConnection)new URL(src).openConnection();ic.setConnectTimeout(7000);ic.setReadTimeout(12000);ic.setRequestProperty("User-Agent","Chithram-Malayalam-Cinema-Demo/1.0");InputStream pi=ic.getInputStream();FileOutputStream fos=new FileOutputStream(cache);byte[] buf2=new byte[8192];int n2;while((n2=pi.read(buf2))!=-1)fos.write(buf2,0,n2);pi.close();fos.close();ic.disconnect();
        Bitmap b=BitmapFactory.decodeFile(cache.getAbsolutePath());if(b!=null)runOnUiThread(()->{target.setImageBitmap(b);target.clearColorFilter();target.setScaleType(ImageView.ScaleType.CENTER_CROP);});
      }catch(Exception ignored){}}
      );
    }
    int scorePoster(JSONObject page, Movie m){
      String n=page.optString("title","").toLowerCase(Locale.ROOT);String t=m.title.toLowerCase(Locale.ROOT);int s=0;if(n.contains(t))s+=5;if(n.contains("poster"))s+=6;if(n.contains(String.valueOf(m.year)))s+=2;if(n.contains("cover"))s+=1;return s;
    }
    void years(){clear();LinearLayout l=col();pad(l,20,22,20,24);LinearLayout head=row();TextView back=bold("‹",30,white);head.addView(back,new LinearLayout.LayoutParams(dp(40),dp(48)));back.setOnClickListener(v->home());head.addView(bold("Browse by Year",18,white),new LinearLayout.LayoutParams(0,-1,1));l.addView(head);LinearLayout tabs=row();TextView y=chip("Year",true),t=chip("Timeline",false);tabs.addView(y,new LinearLayout.LayoutParams(0,42,1));tabs.addView(t,new LinearLayout.LayoutParams(0,42,1));l.addView(tabs,marginTop(8));l.addView(bold("Recent Years",16,white),marginTop(18));GridLayout g=new GridLayout(this);g.setColumnCount(2);for(int year:new int[]{2024,2023,2022,2021,2020,2019,2018,2017,2016}){TextView c=bold(year+"\n"+countYear(year)+" movies",14,white);c.setGravity(Gravity.CENTER);c.setBackgroundResource(R.drawable.bg_card);GridLayout.LayoutParams gp=new GridLayout.LayoutParams();gp.width=0;gp.height=dp(78);gp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);gp.setMargins(dp(4),dp(4),dp(4),dp(4));g.addView(c,gp);final int yy=year;c.setOnClickListener(v->yearPage(yy));}l.addView(g);l.addView(bold("All Years",16,white),marginTop(18));for(int year=2026;year>=1928;year--){if(countYear(year)>0){LinearLayout r=row();r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(0,dp(12),0,dp(12));TextView a=label("▣  "+year,14,white);r.addView(a,new LinearLayout.LayoutParams(0,-2,1));r.addView(label(countYear(year)+" movies   ›",12,muted));final int yy=year;r.setOnClickListener(v->yearPage(yy));l.addView(r);View div=new View(this);div.setBackgroundColor(line);l.addView(div,new LinearLayout.LayoutParams(-1,1));}}content.addView(scroll(l));}
    int countYear(int y){int c=0;for(Movie m:all)if(m.year==y)c++;return c;}
    void decadePage(int decade){currentPageDecade=decade;clear();LinearLayout l=col();pad(l,20,22,20,24);LinearLayout head=row();TextView b=bold("‹",30,white);head.addView(b,new LinearLayout.LayoutParams(dp(40),dp(48)));b.setOnClickListener(v->home());head.addView(bold(decade+"s",24,white));l.addView(head);GridLayout grid=new GridLayout(this);grid.setColumnCount(2);for(Movie m:all)if(m.year>=decade&&m.year<decade+10){View v=posterCard(m);GridLayout.LayoutParams gp=new GridLayout.LayoutParams();int gw=Math.max(dp(132),(getResources().getDisplayMetrics().widthPixels-dp(56))/2); gp.width=gw; gp.height=(int)(gw*1.5f);gp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED);gp.setMargins(dp(4),dp(6),dp(4),dp(6));grid.addView(v,gp);}l.addView(grid,marginTop(12));content.addView(scroll(l));}
    void syncYearsForRange(int startYear,int endYear){ for(int y=startYear;y<=endYear;y++)syncYearIfNeeded(y); }
    void yearPage(int year){currentPageYear=year;clear();LinearLayout l=col();pad(l,20,22,20,24);LinearLayout head=row();TextView b=bold("‹",30,white);head.addView(b,new LinearLayout.LayoutParams(dp(40),dp(48)));b.setOnClickListener(v->years());LinearLayout h=col();h.addView(bold(String.valueOf(year),28,white));h.addView(label(countYear(year)+" movies",13,muted));head.addView(h,new LinearLayout.LayoutParams(0,-2,1));head.addView(label("☷",22,white));l.addView(head);GridLayout grid=new GridLayout(this);grid.setColumnCount(2);for(Movie m:all)if(m.year==year){View v=posterCard(m);GridLayout.LayoutParams gp=new GridLayout.LayoutParams();int gw=Math.max(dp(132),(getResources().getDisplayMetrics().widthPixels-dp(56))/2); gp.width=gw; gp.height=(int)(gw*1.5f);gp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED);gp.setMargins(dp(4),dp(6),dp(4),dp(6));grid.addView(v,gp);}l.addView(grid);content.addView(scroll(l));}
    void details(Movie m){clear();LinearLayout l=col();pad(l,18,20,18,30);LinearLayout top=row();TextView b=bold("‹",30,white);top.addView(b,new LinearLayout.LayoutParams(dp(40),dp(48)));b.setOnClickListener(v->yearPage(m.year));top.addView(label("",1,white),new LinearLayout.LayoutParams(0,1,1));TextView heart=bold(prefs.getBoolean(m.key(),false)?"♥":"♡",28,white);top.addView(heart);heart.setOnClickListener(v->{boolean n=!prefs.getBoolean(m.key(),false);prefs.edit().putBoolean(m.key(),n).apply();heart.setText(n?"♥":"♡");});l.addView(top);ImageView poster=new ImageView(this);poster.setImageResource(android.R.drawable.ic_menu_report_image);poster.setColorFilter(0xFF77777F);poster.setScaleType(ImageView.ScaleType.CENTER_CROP);l.addView(poster,new LinearLayout.LayoutParams(-1,dp(410)));loadPoster(poster,m);l.addView(bold(m.title,30,white),marginTop(16));l.addView(label(m.year+"  •  "+m.genre+"  •  U",13,muted));l.addView(label("Director",12,muted),marginTop(14));l.addView(label(m.director==null||m.director.isEmpty()?"Unknown":m.director,14,white));l.addView(label("Cast",12,muted),marginTop(12));l.addView(label(m.cast==null||m.cast.isEmpty()?"Not listed":m.cast,14,white));l.addView(bold("Synopsis",16,white),marginTop(14));l.addView(label(m.synopsis==null||m.synopsis.isEmpty()?"No synopsis added yet.":m.synopsis,13,muted));
      TextView source=bold("IMDb  ·  Source / title page",13,accent); source.setPadding(0,dp(16),0,dp(4)); l.addView(source); source.setOnClickListener(v->{try{String q=URLEncoder.encode(m.title+" "+m.year,"UTF-8");startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.imdb.com/find/?q="+q)));}catch(Exception ignored){}});
      l.addView(label("Poster image: real poster loaded from M3DB first, then Wikipedia/Wikimedia Commons where available. IMDb is provided as the movie title/source link.",11,muted));
      l.addView(bold("More Like This",16,white),marginTop(20));content.addView(scroll(l));}
    void favorites(){clear();LinearLayout l=col();pad(l,20,22,20,24);l.addView(bold("Favorites",30,white));l.addView(label("Your saved Malayalam films",13,muted),marginTop(2));GridLayout g=new GridLayout(this);g.setColumnCount(2);for(Movie m:all)if(prefs.getBoolean(m.key(),false)){View v=posterCard(m);GridLayout.LayoutParams gp=new GridLayout.LayoutParams();int gw=Math.max(dp(132),(getResources().getDisplayMetrics().widthPixels-dp(56))/2); gp.width=gw; gp.height=(int)(gw*1.5f);gp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED);gp.setMargins(dp(4),dp(12),dp(4),dp(12));g.addView(v,gp);}l.addView(g,marginTop(14));content.addView(scroll(l));}
    void search(){clear();LinearLayout l=col();pad(l,20,22,20,24);LinearLayout head=row();TextView b=bold("‹",30,white);head.addView(b,new LinearLayout.LayoutParams(dp(40),dp(48)));b.setOnClickListener(v->home());head.addView(bold("Search",24,white));l.addView(head);EditText e=new EditText(this);e.setHint("⌕  Search movies, actors, directors...");e.setHintTextColor(muted);e.setTextColor(white);e.setSingleLine();e.setBackgroundResource(R.drawable.bg_search);pad(e,14,0,14,0);l.addView(e,new LinearLayout.LayoutParams(-1,dp(58)));LinearLayout results=col();l.addView(results);e.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){results.removeAllViews();String q=s.toString().toLowerCase(Locale.ROOT);for(Movie m:all)if(q.length()>0&&(m.title.toLowerCase().contains(q)||(m.director!=null&&m.director.toLowerCase().contains(q))||(m.cast!=null&&m.cast.toLowerCase().contains(q)))){LinearLayout r=row();r.setPadding(0,dp(10),0,dp(10));LinearLayout info=col();info.setLayoutParams(new LinearLayout.LayoutParams(0,-2,1));info.addView(bold(m.title,15,white));String sub=m.year+"  •  "+(m.director!=null&&!m.director.isEmpty()?m.director:m.genre);info.addView(label(sub,11,muted));r.addView(info);r.setOnClickListener(v->details(m));results.addView(r);}}public void afterTextChanged(Editable e){}});content.addView(scroll(l));}
    void more(){clear();LinearLayout l=col();pad(l,20,22,20,24);l.addView(bold("CHITHRAM",30,white));l.addView(label("Malayalam Cinema Archive",13,muted));String[] items={"▣   My Watchlist","♡   Favorites","◷   Recently Viewed","⇩   Downloads","⚙   Settings","ⓘ   About"};for(String s:items){TextView x=label(s,15,white);x.setPadding(0,dp(22),0,dp(22));l.addView(x);View div=new View(this);div.setBackgroundColor(line);l.addView(div,new LinearLayout.LayoutParams(-1,1));}content.addView(scroll(l));}
    @Override protected void onDestroy(){posterExecutor.shutdownNow();catalogExecutor.shutdownNow();directorExecutor.shutdownNow();super.onDestroy();}
    static class Movie{String title,genre,director,cast,synopsis,poster,posterLocal,screenplay,releaseDate,source;int year;Movie(String t,int y,String g,String d,String s,String p){title=t;year=y;genre=g;director=d;synopsis=s;poster=p;cast="";posterLocal="";screenplay="";releaseDate="";source="";}String key(){return title.replaceAll("[^A-Za-z0-9]","_")+"_"+year;}JSONObject toJson(){JSONObject o=new JSONObject();try{o.put("title",title);o.put("year",year);o.put("genre",genre);o.put("director",director);o.put("cast",cast);o.put("synopsis",synopsis);o.put("poster",poster);o.put("posterLocal",posterLocal);o.put("screenplay",screenplay);o.put("releaseDate",releaseDate);o.put("source",source);}catch(Exception ignored){}return o;}static Movie fromJson(JSONObject o){Movie m=new Movie(o.optString("title"),o.optInt("year"),o.optString("genre","Unknown"),o.optString("director"),o.optString("synopsis"),o.optString("poster"));m.cast=o.optString("cast","");m.posterLocal=o.optString("posterLocal","");m.screenplay=o.optString("screenplay");m.releaseDate=o.optString("releaseDate");m.source=o.optString("source");return m;}}
}
