package com.malayalam.cinema;

import android.app.*;import android.os.*;import android.content.*;import android.net.Uri;import android.graphics.*;import android.graphics.drawable.GradientDrawable;import android.text.*;import android.view.*;import android.widget.*;import java.io.*;import java.net.*;import java.nio.charset.StandardCharsets;import java.util.*;import java.util.concurrent.*;import org.json.*;

public class MainActivity extends Activity{
    final ArrayList<Movie> all=new ArrayList<>(); final ArrayList<Movie> shown=new ArrayList<>();
    final ExecutorService posterExecutor=Executors.newFixedThreadPool(3);
    LinearLayout bottom; FrameLayout content; SharedPreferences prefs; int yellow=Color.rgb(255,210,31), white=Color.rgb(245,245,247), muted=Color.rgb(154,154,161), card=Color.rgb(26,26,29), bg=Color.rgb(11,11,13);
    int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);} TextView tv(String s,float size,int color){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(color);return v;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);return l;} LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);prefs=getSharedPreferences("favorites",0);content=findViewById(R.id.content);bottom=findViewById(R.id.bottomNav);load();buildNav();home();}
    void load(){try{InputStream in=getAssets().open("movies.json");byte[] d=new byte[in.available()];in.read(d);in.close();JSONArray a=new JSONArray(new String(d,StandardCharsets.UTF_8));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);all.add(new Movie(o.optString("title"),o.optInt("year"),o.optString("genre"),o.optString("director"),o.optString("synopsis"),o.optString("poster")));}}catch(Exception ignored){} shown.addAll(all);}
    TextView label(String s,float sz,int c){TextView v=tv(s,sz,c);v.setTypeface(Typeface.create("sans",Typeface.NORMAL));return v;}
    TextView bold(String s,float sz,int c){TextView v=tv(s,sz,c);v.setTypeface(Typeface.create("sans",Typeface.BOLD));return v;}
    void pad(View v,int l,int t,int r,int b){v.setPadding(dp(l),dp(t),dp(r),dp(b));}

    // Bottom navigation intentionally has no Search item: Home already contains the search field.
    void buildNav(){String[] names={"⌂\nHome","▣\nYears","♡\nFavorites","•••\nMore"};for(int i=0;i<4;i++){final int n=i;TextView v=bold(names[i],15,muted);v.setLineSpacing(dp(2),1f);v.setGravity(Gravity.CENTER);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);bottom.addView(v,p);v.setOnClickListener(x->{if(n==0)home();else if(n==1)years();else if(n==2)favorites();else more();});}}
    void clear(){content.removeAllViews();}
    ScrollView scroll(LinearLayout l){ScrollView s=new ScrollView(this);s.setFillViewport(true);s.addView(l);return s;}

    void home(){clear();LinearLayout l=col();pad(l,20,22,20,24);
      LinearLayout head=row();LinearLayout h=col();h.setLayoutParams(new LinearLayout.LayoutParams(0,-2,1));h.addView(bold("Malayalam",29,white));h.addView(bold("Cinema",29,white));h.addView(label("The complete archive of Malayalam movies by year.",13,muted));head.addView(h);
      ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.app_logo);logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);head.addView(logo,new LinearLayout.LayoutParams(dp(56),dp(60)));l.addView(head);
      EditText search=new EditText(this);search.setHint("⌕  Search for movies, actors, directors...");search.setTextColor(white);search.setHintTextColor(muted);search.setTextSize(13);search.setSingleLine();search.setBackgroundResource(R.drawable.bg_search);pad(search,14,0,14,0);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(58));sp.topMargin=dp(18);l.addView(search,sp);search.setOnEditorActionListener((v,a,e)->{search();return true;}); search.setOnClickListener(v->search());
      LinearLayout hero=col();hero.setBackgroundResource(R.drawable.bg_hero);pad(hero,18,18,18,18);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,dp(166));hp.topMargin=dp(18);l.addView(hero,hp);hero.addView(bold("Explore by Year",20,white));hero.addView(label("Browse all Malayalam movies\nby release year.",13,white),new LinearLayout.LayoutParams(-1,0,1));TextView go=bold("›",28,Color.BLACK);go.setGravity(Gravity.CENTER);go.setBackgroundColor(yellow);LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(dp(42),dp(42));gp.gravity=Gravity.RIGHT;hero.addView(go,gp);go.setOnClickListener(v->years());
      LinearLayout sec=row();sec.setGravity(Gravity.CENTER_VERTICAL);TextView pt=bold("Popular This Week",16,white);sec.addView(pt,new LinearLayout.LayoutParams(0,-2,1));TextView sa=label("See All",13,yellow);sec.addView(sa);l.addView(sec,marginTop(20));
      LinearLayout cards=row();cards.setPadding(0,dp(10),0,0);for(Movie m:pick(6)){cards.addView(posterCard(m));}HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);hs.addView(cards);l.addView(hs);
      l.addView(bold("Browse by Decade",16,white),marginTop(18));LinearLayout chips=row();for(String d:new String[]{"1920s","1930s","1940s","1950s","1960s","1970s","1980s","1990s","2000s","2010s","2020s"}){TextView c=chip(d,false);chips.addView(c,new LinearLayout.LayoutParams(dp(78),dp(34)));((LinearLayout.LayoutParams)c.getLayoutParams()).setMargins(0,0,dp(8),dp(8));final int decade=Integer.parseInt(d.substring(0,4));c.setOnClickListener(v->decadePage(decade));}l.addView(chips);
      content.addView(scroll(l)); }
    LinearLayout.LayoutParams marginTop(int n){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(n);return p;}
    TextView chip(String s,boolean sel){TextView c=bold(s,12,sel?Color.BLACK:white);c.setGravity(Gravity.CENTER);c.setBackgroundResource(R.drawable.bg_chip);c.setSelected(sel);return c;}
    ArrayList<Movie> pick(int n){ArrayList<Movie>x=new ArrayList<>();for(Movie m:all){if(x.size()>=n)break;if(m.year>=1990)x.add(m);}return x;}
    View posterCard(Movie m){
      FrameLayout cardView=new FrameLayout(this); cardView.setBackgroundResource(R.drawable.bg_poster); cardView.setClipToOutline(true);
      LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(144),dp(258)); cp.setMargins(0,0,dp(8),0); cardView.setLayoutParams(cp);
      ImageView im=new ImageView(this); im.setScaleType(ImageView.ScaleType.CENTER_CROP); im.setBackgroundColor(Color.rgb(30,30,34));
      im.setImageResource(android.R.drawable.ic_menu_report_image); im.setColorFilter(0xFF77777F);
      cardView.addView(im,new FrameLayout.LayoutParams(-1,dp(258)));
      View shade=new View(this); GradientDrawable gd=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0x00000000,0x55000000,0xEE000000}); shade.setBackground(gd); cardView.addView(shade,new FrameLayout.LayoutParams(-1,dp(108),Gravity.BOTTOM));
      LinearLayout info=col(); info.setGravity(Gravity.BOTTOM); pad(info,10,7,10,10); TextView yr=label(String.valueOf(m.year),11,0xFFD0D0D4); TextView title=bold(m.title,13,white); title.setMaxLines(2); title.setEllipsize(TextUtils.TruncateAt.END); info.addView(yr); info.addView(title); FrameLayout.LayoutParams ip=new FrameLayout.LayoutParams(-1,dp(112),Gravity.BOTTOM); cardView.addView(info,ip);
      TextView heart=bold(prefs.getBoolean(m.key(),false)?"♥":"♡",21,prefs.getBoolean(m.key(),false)?yellow:white); heart.setGravity(Gravity.CENTER); GradientDrawable hb=new GradientDrawable(); hb.setColor(0x99000000); hb.setShape(GradientDrawable.OVAL); heart.setBackground(hb); FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(dp(38),dp(38),Gravity.RIGHT|Gravity.TOP); hp.setMargins(0,dp(7),dp(7),0); cardView.addView(heart,hp);
      heart.setOnClickListener(v->{boolean n=!prefs.getBoolean(m.key(),false);prefs.edit().putBoolean(m.key(),n).apply();heart.setText(n?"♥":"♡");heart.setTextColor(n?yellow:white);});
      cardView.setOnClickListener(v->details(m));
      loadPoster(im,m);
      return cardView;
    }
    void loadPoster(ImageView target, Movie m){
      final String key=m.key().replaceAll("[^A-Za-z0-9_-]","_"); final File cache=new File(getCacheDir(),"poster_"+key+".jpg");
      if(cache.exists()){Bitmap b=BitmapFactory.decodeFile(cache.getAbsolutePath());if(b!=null){target.setImageBitmap(b);target.clearColorFilter();return;}}
      posterExecutor.execute(()->{try{
        String src=null;
        // 1) M3DB: try its film slug and read the real og:image poster.
        String slug=m.title.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+","-").replaceAll("^-|-$","");
        String[] m3urls={"https://m3db.com/film/"+slug,"https://m3db.com/film/"+slug+"-"+m.year};
        for(String pageUrl:m3urls){
          try{
            HttpURLConnection c=(HttpURLConnection)new URL(pageUrl).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(10000);c.setRequestProperty("User-Agent","Mozilla/5.0 (Android) Chithram/1.0");
            InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);in.close();c.disconnect();
            String html=out.toString(StandardCharsets.UTF_8.name()); java.util.regex.Matcher mm=java.util.regex.Pattern.compile("<meta[^>]+property=[\\\"']og:image[\\\"'][^>]+content=[\\\"']([^\\\"']+)",java.util.regex.Pattern.CASE_INSENSITIVE).matcher(html); if(mm.find()){src=mm.group(1);break;}
          }catch(Exception ignored){}
        }
        // 2) Wikipedia: exact film page thumbnail only.
        if(src==null){
          String[] titles={m.title+" (film)",m.title+" ("+m.year+" film)",m.title+" ("+m.year+" Malayalam film)",m.title};
          for(String title:titles){
            try{
              String tq=URLEncoder.encode(title,"UTF-8"); URL u=new URL("https://en.wikipedia.org/w/api.php?action=query&prop=pageimages&piprop=thumbnail&pithumbsize=700&titles="+tq+"&format=json&origin=*");
              HttpURLConnection c=(HttpURLConnection)u.openConnection();c.setConnectTimeout(7000);c.setReadTimeout(10000);c.setRequestProperty("User-Agent","Chithram-Malayalam-Cinema-Demo/1.0");
              InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);in.close();c.disconnect();
              JSONObject root=new JSONObject(out.toString(StandardCharsets.UTF_8.name()));JSONObject pages=root.optJSONObject("query")==null?null:root.getJSONObject("query").optJSONObject("pages");
              if(pages!=null){Iterator<String> it=pages.keys();while(it.hasNext()){JSONObject page=pages.getJSONObject(it.next());JSONObject th=page.optJSONObject("thumbnail");if(th!=null){String candidate=th.optString("source",null);if(candidate!=null&&!candidate.isEmpty()){src=candidate;break;}}}}
              if(src!=null)break;
            }catch(Exception ignored){}
          }
        }
        // 3) Wikimedia Commons: search specifically for poster + title, never use a generic film still.
        if(src==null){
          try{
            String q=URLEncoder.encode(m.title+" poster Malayalam","UTF-8"); URL cu=new URL("https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrsearch="+q+"&gsrnamespace=6&gsrlimit=10&prop=imageinfo&iiprop=url|mime|size&iiurlwidth=700&format=json&origin=*");
            HttpURLConnection c=(HttpURLConnection)cu.openConnection();c.setConnectTimeout(7000);c.setReadTimeout(10000);c.setRequestProperty("User-Agent","Chithram-Malayalam-Cinema-Demo/1.0");InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);in.close();c.disconnect();
            JSONObject cr=new JSONObject(out.toString(StandardCharsets.UTF_8.name()));JSONObject cp=cr.optJSONObject("query")==null?null:cr.getJSONObject("query").optJSONObject("pages");
            if(cp!=null){ArrayList<JSONObject> candidates=new ArrayList<>();Iterator<String> it=cp.keys();while(it.hasNext())candidates.add(cp.getJSONObject(it.next()));Collections.sort(candidates,(a,b)->Integer.compare(scorePoster(b,m),scorePoster(a,m)));for(JSONObject page:candidates){if(scorePoster(page,m)>0){JSONArray ia=page.optJSONArray("imageinfo");if(ia!=null&&ia.length()>0){JSONObject ii=ia.getJSONObject(0);src=ii.optString("thumburl",ii.optString("url",null));if(src!=null&&!src.isEmpty())break;}}}}
          }catch(Exception ignored){}
        }
        if(src==null)return;
        HttpURLConnection ic=(HttpURLConnection)new URL(src).openConnection();ic.setConnectTimeout(7000);ic.setReadTimeout(12000);ic.setRequestProperty("User-Agent","Chithram-Malayalam-Cinema-Demo/1.0");InputStream pi=ic.getInputStream();FileOutputStream fos=new FileOutputStream(cache);byte[] buf2=new byte[8192];int n2;while((n2=pi.read(buf2))!=-1)fos.write(buf2,0,n2);pi.close();fos.close();ic.disconnect();
        Bitmap b=BitmapFactory.decodeFile(cache.getAbsolutePath());if(b!=null)runOnUiThread(()->{target.setImageBitmap(b);target.clearColorFilter();target.setScaleType(ImageView.ScaleType.CENTER_CROP);});
      }catch(Exception ignored){}}
      );
    }
    int scorePoster(JSONObject page, Movie m){
      String n=page.optString("title","").toLowerCase(Locale.ROOT);String t=m.title.toLowerCase(Locale.ROOT);int s=0;if(n.contains(t))s+=5;if(n.contains("poster"))s+=6;if(n.contains(String.valueOf(m.year)))s+=2;if(n.contains("cover"))s+=1;return s;
    }
    void years(){clear();LinearLayout l=col();pad(l,20,22,20,24);LinearLayout head=row();TextView back=bold("‹",30,white);head.addView(back,new LinearLayout.LayoutParams(dp(40),dp(48)));back.setOnClickListener(v->home());head.addView(bold("Browse by Year",18,white),new LinearLayout.LayoutParams(0,-1,1));l.addView(head);LinearLayout tabs=row();TextView y=chip("Year",true),t=chip("Timeline",false);tabs.addView(y,new LinearLayout.LayoutParams(0,42,1));tabs.addView(t,new LinearLayout.LayoutParams(0,42,1));l.addView(tabs,marginTop(8));l.addView(bold("Recent Years",16,white),marginTop(18));GridLayout g=new GridLayout(this);g.setColumnCount(3);for(int year:new int[]{2024,2023,2022,2021,2020,2019,2018,2017,2016}){TextView c=bold(year+"\n"+countYear(year)+" movies",14,white);c.setGravity(Gravity.CENTER);c.setBackgroundResource(R.drawable.bg_card);GridLayout.LayoutParams gp=new GridLayout.LayoutParams();gp.width=0;gp.height=dp(78);gp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);gp.setMargins(dp(4),dp(4),dp(4),dp(4));g.addView(c,gp);final int yy=year;c.setOnClickListener(v->yearPage(yy));}l.addView(g);l.addView(bold("All Years",16,white),marginTop(18));for(int year=2026;year>=1928;year--){if(countYear(year)>0){LinearLayout r=row();r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(0,dp(12),0,dp(12));TextView a=label("▣  "+year,14,white);r.addView(a,new LinearLayout.LayoutParams(0,-2,1));r.addView(label(countYear(year)+" movies   ›",12,muted));final int yy=year;r.setOnClickListener(v->yearPage(yy));l.addView(r);View line=new View(this);line.setBackgroundColor(Color.rgb(42,42,46));l.addView(line,new LinearLayout.LayoutParams(-1,1));}}content.addView(scroll(l));}
    int countYear(int y){int c=0;for(Movie m:all)if(m.year==y)c++;return c;}
    void decadePage(int decade){clear();LinearLayout l=col();pad(l,20,22,20,24);LinearLayout head=row();TextView b=bold("‹",30,white);head.addView(b,new LinearLayout.LayoutParams(dp(40),dp(48)));b.setOnClickListener(v->home());head.addView(bold(decade+"s",24,white));l.addView(head);GridLayout grid=new GridLayout(this);grid.setColumnCount(3);for(Movie m:all)if(m.year>=decade&&m.year<decade+10){View v=posterCard(m);GridLayout.LayoutParams gp=new GridLayout.LayoutParams();gp.width=dp(144);gp.height=dp(258);gp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED);gp.setMargins(dp(4),dp(6),dp(4),dp(6));grid.addView(v,gp);}l.addView(grid,marginTop(12));content.addView(scroll(l));}
    void yearPage(int year){clear();LinearLayout l=col();pad(l,20,22,20,24);LinearLayout head=row();TextView b=bold("‹",30,white);head.addView(b,new LinearLayout.LayoutParams(dp(40),dp(48)));b.setOnClickListener(v->years());LinearLayout h=col();h.addView(bold(String.valueOf(year),28,white));h.addView(label(countYear(year)+" movies",13,muted));head.addView(h,new LinearLayout.LayoutParams(0,-2,1));head.addView(label("☷",22,white));l.addView(head);GridLayout grid=new GridLayout(this);grid.setColumnCount(3);for(Movie m:all)if(m.year==year){View v=posterCard(m);GridLayout.LayoutParams gp=new GridLayout.LayoutParams();gp.width=dp(144);gp.height=dp(258);gp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED);gp.setMargins(dp(4),dp(6),dp(4),dp(6));grid.addView(v,gp);}l.addView(grid);content.addView(scroll(l));}
    void details(Movie m){clear();LinearLayout l=col();pad(l,18,20,18,30);LinearLayout top=row();TextView b=bold("‹",30,white);top.addView(b,new LinearLayout.LayoutParams(dp(40),dp(48)));b.setOnClickListener(v->yearPage(m.year));top.addView(label("",1,white),new LinearLayout.LayoutParams(0,1,1));TextView heart=bold(prefs.getBoolean(m.key(),false)?"♥":"♡",28,white);top.addView(heart);heart.setOnClickListener(v->{boolean n=!prefs.getBoolean(m.key(),false);prefs.edit().putBoolean(m.key(),n).apply();heart.setText(n?"♥":"♡");});l.addView(top);ImageView poster=new ImageView(this);poster.setImageResource(android.R.drawable.ic_menu_report_image);poster.setColorFilter(0xFF77777F);poster.setScaleType(ImageView.ScaleType.CENTER_CROP);l.addView(poster,new LinearLayout.LayoutParams(-1,dp(410)));loadPoster(poster,m);l.addView(bold(m.title,30,white),marginTop(16));l.addView(label(m.year+"  •  "+m.genre+"  •  U",13,muted));l.addView(label("Director",12,muted),marginTop(14));l.addView(label(m.director,14,white));l.addView(bold("Synopsis",16,white),marginTop(14));l.addView(label(m.synopsis==null||m.synopsis.isEmpty()?"No synopsis added yet.":m.synopsis,13,muted));
      TextView source=bold("IMDb  ·  Source / title page",13,yellow); source.setPadding(0,dp(16),0,dp(4)); l.addView(source); source.setOnClickListener(v->{try{String q=URLEncoder.encode(m.title+" "+m.year,"UTF-8");startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.imdb.com/find/?q="+q)));}catch(Exception ignored){}});
      l.addView(label("Poster image: real poster loaded from M3DB first, then Wikipedia/Wikimedia Commons where available. IMDb is provided as the movie title/source link.",11,muted));
      l.addView(bold("More Like This",16,white),marginTop(20));content.addView(scroll(l));}
    void favorites(){clear();LinearLayout l=col();pad(l,20,22,20,24);l.addView(bold("Favorites",30,white));l.addView(label("Your saved Malayalam films",13,muted),marginTop(2));GridLayout g=new GridLayout(this);g.setColumnCount(3);for(Movie m:all)if(prefs.getBoolean(m.key(),false)){View v=posterCard(m);GridLayout.LayoutParams gp=new GridLayout.LayoutParams();gp.width=dp(144);gp.height=dp(258);gp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED);gp.setMargins(dp(4),dp(12),dp(4),dp(12));g.addView(v,gp);}l.addView(g,marginTop(14));content.addView(scroll(l));}
    void search(){clear();LinearLayout l=col();pad(l,20,22,20,24);LinearLayout head=row();TextView b=bold("‹",30,white);head.addView(b,new LinearLayout.LayoutParams(dp(40),dp(48)));b.setOnClickListener(v->home());head.addView(bold("Search",24,white));l.addView(head);EditText e=new EditText(this);e.setHint("⌕  Search movies, actors, directors...");e.setHintTextColor(muted);e.setTextColor(white);e.setSingleLine();e.setBackgroundResource(R.drawable.bg_search);pad(e,14,0,14,0);l.addView(e,new LinearLayout.LayoutParams(-1,dp(58)));LinearLayout results=col();l.addView(results);e.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){results.removeAllViews();String q=s.toString().toLowerCase(Locale.ROOT);for(Movie m:all)if(q.length()>0&&(m.title.toLowerCase().contains(q)||m.director.toLowerCase().contains(q))){LinearLayout r=row();r.setPadding(0,dp(10),0,dp(10));TextView p=bold(m.title,15,white);r.addView(p,new LinearLayout.LayoutParams(0,-2,1));r.addView(label(m.year+"  •  "+m.genre,11,muted));r.setOnClickListener(v->details(m));results.addView(r);}}public void afterTextChanged(Editable e){}});content.addView(scroll(l));}
    void more(){clear();LinearLayout l=col();pad(l,20,22,20,24);l.addView(bold("CHITHRAM",30,white));l.addView(label("Malayalam Cinema Archive",13,muted));String[] items={"▣   My Watchlist","♡   Favorites","◷   Recently Viewed","⇩   Downloads","⚙   Settings","ⓘ   About"};for(String s:items){TextView x=label(s,15,white);x.setPadding(0,dp(22),0,dp(22));l.addView(x);View line=new View(this);line.setBackgroundColor(Color.rgb(42,42,46));l.addView(line,new LinearLayout.LayoutParams(-1,1));}content.addView(scroll(l));}
    @Override protected void onDestroy(){posterExecutor.shutdownNow();super.onDestroy();}
    static class Movie{String title,genre,director,synopsis,poster;int year;Movie(String t,int y,String g,String d,String s,String p){title=t;year=y;genre=g;director=d;synopsis=s;poster=p;}String key(){return title.replaceAll("[^A-Za-z0-9]","_")+"_"+year;}}
}
