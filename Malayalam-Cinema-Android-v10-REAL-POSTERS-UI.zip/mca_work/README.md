# CHITHRAM v10

Malayalam Cinema Archive demo Android app.

## v10 changes
- Real poster loading: M3DB first, then exact Wikipedia page images, then Wikimedia Commons poster search.
- No generated/gold placeholder posters are used as movie artwork.
- Posters are cached locally after first successful download.
- IMDb remains available as a title/source link in movie details; IMDb poster files are not copied into the APK.
- Larger bottom navigation: Home, Years, Favorites, More.
- Larger 2:3 movie cards and improved spacing.
- CHITHRAM animated splash retained.

## Note
Poster availability depends on the source. If a film has no usable real poster at those sources, the app leaves the poster area neutral rather than inventing artwork.
