# Gen – AI Roleplay Chat App

Simple but powerful Android RP chat app.  
Works with **any OpenAI-compatible API**.

## Features

- **Multiple API profiles** – switch between OpenAI, OpenRouter, Groq, Together, DeepSeek, Ollama, etc.
- **Multiple characters** – each with name, description, personality, scenario, system prompt, first message
- **Import character cards** – SillyTavern / TavernAI JSON (v1 & v2)
- **Background images** – per character or global
- **Long-term memory** – always injected into the system prompt
- **Generation presets** – temperature, max tokens, top-p, penalties
- **Regex scripts** – find/replace on user & assistant messages
- **Select to delete** – long-press messages → multi-select → delete
- Local chat history
- Clean dark Material 3 UI

---

## Easiest way to get the APK (GitHub Actions)

1. Create a new **public** GitHub repository
2. Upload the contents of this project (or the outer `gen-main` zip)
3. Go to **Actions** → run the **Build Android APK** workflow
4. Download the artifact (`app-debug.apk`)

---

## Build locally with Android Studio

1. Open the `Gen` folder in Android Studio
2. Build → Build Bundle(s) / APK(s) → Build APK(s)
3. APK is in `app/build/outputs/apk/debug/`

---

## First-time setup

1. Open **Settings** (gear icon)
2. **APIs** tab → add or edit a profile (Base URL + API Key + Model)
3. **Characters** tab → create a character or **Import Character Card (JSON)**
4. **Memory** tab → write any long-term facts you want the character to remember
5. **Presets** tab → tweak temperature / max tokens if desired
6. **Regex** tab → optional find/replace scripts
7. **Background** tab → set a chat background image
8. Save and start chatting

### Select to delete messages
- Long-press any message → selection mode
- Tap more messages to select
- Tap the trash icon to delete selected messages
- Tap X to cancel

### Example API Base URLs
- OpenAI: `https://api.openai.com/v1`
- OpenRouter: `https://openrouter.ai/api/v1`
- Groq: `https://api.groq.com/openai/v1`
- Local Ollama: `http://localhost:11434/v1` (or your LAN IP)
