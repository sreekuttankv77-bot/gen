# Keep Gson and models
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.gen.rp.data.** { *; }
