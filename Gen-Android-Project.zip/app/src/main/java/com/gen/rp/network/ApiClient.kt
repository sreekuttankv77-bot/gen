package com.gen.rp.network

import com.gen.rp.data.ApiMessage
import com.gen.rp.data.ChatCompletionRequest
import com.gen.rp.data.ChatCompletionResponse
import com.gen.rp.data.GenerationPreset
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

class ApiClient {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val gson = Gson()
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun sendChat(
        baseUrl: String,
        apiKey: String,
        model: String,
        messages: List<ApiMessage>,
        preset: GenerationPreset = GenerationPreset()
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val cleanBase = baseUrl.trimEnd('/')
            val url = if (cleanBase.endsWith("/v1") || cleanBase.contains("/v1/")) {
                if (cleanBase.endsWith("/chat/completions")) cleanBase
                else "$cleanBase/chat/completions"
            } else {
                "$cleanBase/v1/chat/completions"
            }

            val requestBody = ChatCompletionRequest(
                model = model,
                messages = messages,
                temperature = preset.temperature,
                max_tokens = preset.maxTokens,
                top_p = preset.topP,
                frequency_penalty = preset.frequencyPenalty,
                presence_penalty = preset.presencePenalty
            )

            val json = gson.toJson(requestBody)
            val body = json.toRequestBody(jsonMediaType)

            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $apiKey")
                .addHeader("Content-Type", "application/json")
                .post(body)
                .build()

            client.newCall(request).execute().use { response ->
                val responseBody = response.body?.string() ?: ""
                if (!response.isSuccessful) {
                    return@withContext Result.failure(
                        Exception("HTTP ${response.code}: $responseBody")
                    )
                }

                val parsed = gson.fromJson(responseBody, ChatCompletionResponse::class.java)
                val content = parsed.choices?.firstOrNull()?.message?.content
                    ?: return@withContext Result.failure(Exception("No content in response"))

                Result.success(content.trim())
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
