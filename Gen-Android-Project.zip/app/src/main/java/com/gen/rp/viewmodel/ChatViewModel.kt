package com.gen.rp.viewmodel

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.gen.rp.data.*
import com.gen.rp.network.ApiClient
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.io.ByteArrayInputStream
import java.io.File
import java.util.Base64
import java.util.UUID
import java.util.zip.GZIPInputStream
import java.util.zip.InflaterInputStream
import java.util.zip.ZipInputStream

class ChatViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = SettingsRepository(application)
    private val api = ApiClient()
    private val gson = Gson()
    private val _settings = MutableStateFlow(AppSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()
    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()
    private val _selectionMode = MutableStateFlow(false)
    val selectionMode: StateFlow<Boolean> = _selectionMode.asStateFlow()
    private val _selectedIds = MutableStateFlow<Set<String>>(emptySet())
    val selectedIds: StateFlow<Set<String>> = _selectedIds.asStateFlow()

    init {
        viewModelScope.launch {
            _settings.value = repo.settingsFlow.first()
            val s = _settings.value
            val fixed = s.copy(
                activeApiId = s.apiProfiles.firstOrNull { it.id == s.activeApiId }?.id ?: s.apiProfiles.firstOrNull()?.id.orEmpty(),
                activeCharacterId = s.characters.firstOrNull { it.id == s.activeCharacterId }?.id ?: s.characters.firstOrNull()?.id.orEmpty(),
                activePersonaId = s.personas.firstOrNull { it.id == s.activePersonaId }?.id ?: s.personas.firstOrNull()?.id.orEmpty(),
                activePresetId = s.presets.firstOrNull { it.id == s.activePresetId }?.id ?: s.presets.firstOrNull()?.id.orEmpty()
            )
            if (fixed != s) updateSettings(fixed)
            loadHistory()
        }
        viewModelScope.launch { repo.settingsFlow.collect { _settings.value = it } }
    }

    private suspend fun loadHistory() {
        try {
            val type = object : TypeToken<List<ChatMessage>>() {}.type
            val list: List<ChatMessage> = gson.fromJson(repo.chatHistoryFlow.first(), type) ?: emptyList()
            _messages.value = list.map { if (it.id.isBlank()) it.copy(id = UUID.randomUUID().toString()) else it }
        } catch (_: Exception) { _messages.value = emptyList() }
    }

    private fun saveHistory() = viewModelScope.launch { repo.saveChatHistory(gson.toJson(_messages.value)) }
    fun updateSettings(newSettings: AppSettings) = viewModelScope.launch { repo.saveSettings(newSettings); _settings.value = newSettings }
    fun clearError() { _error.value = null }
    fun clearChat() { _messages.value = emptyList(); exitSelectionMode(); saveHistory() }

    fun enterSelectionMode(id: String) { _selectionMode.value = true; _selectedIds.value = setOf(id) }
    fun toggleSelection(id: String) { val s = _selectedIds.value.toMutableSet(); if (!s.add(id)) s.remove(id); _selectedIds.value = s; if (s.isEmpty()) exitSelectionMode() }
    fun exitSelectionMode() { _selectionMode.value = false; _selectedIds.value = emptySet() }
    fun deleteSelected() { val ids = _selectedIds.value; _messages.value = _messages.value.filterNot { it.id in ids }; exitSelectionMode(); saveHistory() }
    fun deleteMessage(id: String) { _messages.value = _messages.value.filterNot { it.id == id }; saveHistory() }

    private fun applyRegex(text: String, role: String): String {
        var result = text
        _settings.value.regexScripts.filter { it.enabled }.forEach { script ->
            if (role == "user" && !script.applyToUser) return@forEach
            if (role == "assistant" && !script.applyToAssistant) return@forEach
            if (script.find.isBlank()) return@forEach
            try { result = if (script.isRegex) result.replace(Regex(script.find), script.replace) else result.replace(script.find, script.replace) } catch (_: Exception) { }
        }
        return result
    }

    private fun buildApiMessages(history: List<ChatMessage>): List<ApiMessage> {
        val s = _settings.value
        val c = s.activeCharacter()
        val p = s.activePersona()
        val systemParts = mutableListOf<String>()
        if (c.systemPrompt.isNotBlank()) systemParts += c.systemPrompt
        if (c.description.isNotBlank()) systemParts += "Description: ${c.description}"
        if (c.personality.isNotBlank()) systemParts += "Personality: ${c.personality}"
        if (c.scenario.isNotBlank()) systemParts += "Scenario: ${c.scenario}"
        if (p.name.isNotBlank()) systemParts += "User Persona: ${p.name}\n${p.description}\nPersonality: ${p.personality}\nBackground: ${p.background}"
        if (s.longTermMemory.isNotBlank()) systemParts += "Long-term Memory:\n${s.longTermMemory}"
        if (c.exampleMessages.isNotBlank()) systemParts += "Example dialogue:\n${c.exampleMessages}"
        return buildList {
            if (systemParts.isNotEmpty()) add(ApiMessage("system", systemParts.joinToString("\n\n")))
            history.takeLast(30).forEach { add(ApiMessage(it.role, it.content)) }
        }
    }

    fun sendMessage(userText: String) {
        if (userText.isBlank() || _isLoading.value) return
        val s = _settings.value
        val apiProfile = s.activeApi()
        if (apiProfile.apiKey.isBlank()) { _error.value = "Add an API key in the menu → Settings → APIs"; return }
        val user = ChatMessage(role = "user", content = applyRegex(userText.trim(), "user"))
        _messages.value += user
        saveHistory()
        generateReply(_messages.value)
    }

    /** Replaces the current/latest assistant response. The old response is not sent as context. */
    fun rerollCurrentMessage() {
        if (_isLoading.value) return
        val list = _messages.value
        val index = list.indexOfLast { it.role == "assistant" }
        if (index < 0) return
        val before = list.take(index)
        if (before.none { it.role == "user" }) return
        _messages.value = list.toMutableList().also { it.removeAt(index) }
        generateReply(_messages.value, replaceIndex = index)
    }

    private fun generateReply(history: List<ChatMessage>, replaceIndex: Int? = null) {
        if (_isLoading.value) return
        val s = _settings.value
        val apiProfile = s.activeApi()
        val preset = s.activePreset()
        _isLoading.value = true
        _error.value = null
        viewModelScope.launch {
            val result = api.sendChat(apiProfile.baseUrl, apiProfile.apiKey, apiProfile.model, buildApiMessages(history), preset)
            result.onSuccess { reply ->
                val msg = ChatMessage(role = "assistant", content = applyRegex(reply, "assistant"))
                if (replaceIndex != null && replaceIndex <= _messages.value.size) {
                    val newList = _messages.value.toMutableList()
                    newList.add(replaceIndex.coerceAtMost(newList.size), msg)
                    _messages.value = newList
                } else _messages.value += msg
                saveHistory()
            }.onFailure { _error.value = it.message ?: "Unknown error" }
            _isLoading.value = false
        }
    }

    // API profiles
    fun addApiProfile(x: ApiProfile) = updateSettings(_settings.value.copy(apiProfiles = _settings.value.apiProfiles + x))
    fun updateApiProfile(x: ApiProfile) = updateSettings(_settings.value.copy(apiProfiles = _settings.value.apiProfiles.map { if (it.id == x.id) x else it }))
    fun deleteApiProfile(id: String) { val s = _settings.value; if (s.apiProfiles.size <= 1) return; val n = s.apiProfiles.filterNot { it.id == id }; updateSettings(s.copy(apiProfiles = n, activeApiId = if (s.activeApiId == id) n.first().id else s.activeApiId)) }
    fun setActiveApi(id: String) = updateSettings(_settings.value.copy(activeApiId = id))

    // Characters
    fun addCharacter(x: Character, activate: Boolean = false) { val s = _settings.value; updateSettings(s.copy(characters = s.characters + x, activeCharacterId = if (activate) x.id else s.activeCharacterId)) }
    fun updateCharacter(x: Character) = updateSettings(_settings.value.copy(characters = _settings.value.characters.map { if (it.id == x.id) x else it }))
    fun deleteCharacter(id: String) { val s = _settings.value; if (s.characters.size <= 1) return; val n = s.characters.filterNot { it.id == id }; updateSettings(s.copy(characters = n, activeCharacterId = if (s.activeCharacterId == id) n.first().id else s.activeCharacterId)) }
    fun setActiveCharacter(id: String) = updateSettings(_settings.value.copy(activeCharacterId = id))

    fun importCharacterCard(json: String, avatarUri: String = ""): Boolean {
        return try {
            val card = gson.fromJson(json, CharacterCard::class.java)
            val d = card.data
            val name = d?.name ?: card.name ?: "Imported Character"
            val desc = d?.description ?: card.description ?: ""
            val personality = d?.personality ?: card.personality ?: ""
            val scenario = d?.scenario ?: card.scenario ?: ""
            val first = d?.first_mes ?: card.first_mes ?: ""
            val example = d?.mes_example ?: card.mes_example ?: ""
            val system = d?.system_prompt ?: card.system_prompt ?: "You are $name. Stay in character at all times."
            addCharacter(Character(name = name, description = desc, personality = personality, scenario = scenario, systemPrompt = system, firstMessage = first, exampleMessages = example, avatarUri = avatarUri))
            true
        } catch (e: Exception) { _error.value = "Failed to import character card: ${e.message}"; false }
    }

    /** Imports common SillyTavern/TavernAI PNG cards. The card JSON is usually in a tEXt/iTXt/zTXt chunk named 'chara'. */
    fun importPngCharacter(context: Context, uri: Uri): Boolean {
        return try {
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Cannot read PNG")
            val json = extractPngCharacterJson(bytes) ?: error("No character-card metadata found in this PNG")
            val imageFile = copyToPrivateFile(context, uri, "character_${UUID.randomUUID()}.png")
            importCharacterCard(json, imageFile.toURI().toString())
        } catch (e: Exception) { _error.value = "PNG import failed: ${e.message}"; false }
    }

    fun importCharacterPack(context: Context, uri: Uri): Int {
        var count = 0
        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                ZipInputStream(input).use { zip ->
                    while (true) {
                        val entry = zip.nextEntry ?: break
                        if (entry.isDirectory) continue
                        val bytes = zip.readBytes()
                        val name = entry.name.lowercase()
                        when {
                            name.endsWith(".json") -> if (importCharacterCard(bytes.toString(Charsets.UTF_8))) count++
                            name.endsWith(".png") -> {
                                val tmp = File(context.cacheDir, "card_${UUID.randomUUID()}.png")
                                tmp.writeBytes(bytes)
                                val json = extractPngCharacterJson(bytes)
                                if (json != null) {
                                    val saved = File(context.filesDir, "character_${UUID.randomUUID()}.png")
                                    saved.writeBytes(bytes)
                                    if (importCharacterCard(json, saved.toURI().toString())) count++
                                }
                                tmp.delete()
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) { _error.value = "ZIP import failed: ${e.message}" }
        return count
    }

    private fun copyToPrivateFile(context: Context, uri: Uri, name: String): File {
        val file = File(context.filesDir, name)
        context.contentResolver.openInputStream(uri).use { input -> file.outputStream().use { out -> input!!.copyTo(out) } }
        return file
    }

    private fun extractPngCharacterJson(bytes: ByteArray): String? {
        if (bytes.size < 8 || bytes[0] != 137.toByte() || bytes[1] != 80.toByte() || bytes[2] != 78.toByte() || bytes[3] != 71.toByte()) return null
        var pos = 8
        while (pos + 12 <= bytes.size) {
            val len = ((bytes[pos].toInt() and 255) shl 24) or ((bytes[pos+1].toInt() and 255) shl 16) or ((bytes[pos+2].toInt() and 255) shl 8) or (bytes[pos+3].toInt() and 255)
            if (len < 0 || pos + 12 + len > bytes.size) break
            val type = String(bytes, pos + 4, 4, Charsets.ISO_8859_1)
            val data = bytes.copyOfRange(pos + 8, pos + 8 + len)
            when (type) {
                "tEXt" -> {
                    val zero = data.indexOf(0)
                    if (zero >= 0 && String(data, 0, zero, Charsets.ISO_8859_1).equals("chara", true)) return decodeCardPayload(String(data, zero + 1, data.size - zero - 1, Charsets.ISO_8859_1))
                }
                "iTXt" -> {
                    val s = String(data, Charsets.UTF_8)
                    if (s.startsWith("chara\u0000")) {
                        val parts = s.split('\u0000')
                        if (parts.size >= 6) {
                            val payload = parts.last()
                            return if (parts.getOrNull(1) == "1") {
                                val decoded = Base64.getDecoder().decode(payload)
                                GZIPInputStream(ByteArrayInputStream(decoded)).bufferedReader().readText()
                            } else decodeCardPayload(payload)
                        }
                    }
                }
                "zTXt" -> {
                    val zero = data.indexOf(0)
                    if (zero >= 0 && String(data, 0, zero, Charsets.ISO_8859_1).equals("chara", true)) {
                        val decoded = InflaterInputStream(ByteArrayInputStream(data, zero + 2, data.size - zero - 2)).bufferedReader().readText()
                        return decodeCardPayload(decoded)
                    }
                }
            }
            pos += 12 + len
            if (type == "IEND") break
        }
        return null
    }

    private fun decodeCardPayload(payload: String): String? = try {
        val decoded = Base64.getDecoder().decode(payload.trim())
        String(decoded, Charsets.UTF_8)
    } catch (_: Exception) { payload.takeIf { it.trim().startsWith("{") } }

    // Personas
    fun addPersona(x: UserPersona, activate: Boolean = false) { val s = _settings.value; updateSettings(s.copy(personas = s.personas + x, activePersonaId = if (activate) x.id else s.activePersonaId)) }
    fun updatePersona(x: UserPersona) = updateSettings(_settings.value.copy(personas = _settings.value.personas.map { if (it.id == x.id) x else it }))
    fun deletePersona(id: String) { val s = _settings.value; if (s.personas.size <= 1) return; val n = s.personas.filterNot { it.id == id }; updateSettings(s.copy(personas = n, activePersonaId = if (s.activePersonaId == id) n.first().id else s.activePersonaId)) }
    fun setActivePersona(id: String) = updateSettings(_settings.value.copy(activePersonaId = id))

    // Presets
    fun addPreset(x: GenerationPreset) = updateSettings(_settings.value.copy(presets = _settings.value.presets + x))
    fun updatePreset(x: GenerationPreset) = updateSettings(_settings.value.copy(presets = _settings.value.presets.map { if (it.id == x.id) x else it }))
    fun deletePreset(id: String) { val s = _settings.value; if (s.presets.size <= 1) return; val n = s.presets.filterNot { it.id == id }; updateSettings(s.copy(presets = n, activePresetId = if (s.activePresetId == id) n.first().id else s.activePresetId)) }
    fun setActivePreset(id: String) = updateSettings(_settings.value.copy(activePresetId = id))

    // Regex and memory/background
    fun addRegexScript(x: RegexScript) = updateSettings(_settings.value.copy(regexScripts = _settings.value.regexScripts + x))
    fun updateRegexScript(x: RegexScript) = updateSettings(_settings.value.copy(regexScripts = _settings.value.regexScripts.map { if (it.id == x.id) x else it }))
    fun deleteRegexScript(id: String) = updateSettings(_settings.value.copy(regexScripts = _settings.value.regexScripts.filterNot { it.id == id }))
    fun updateLongTermMemory(x: String) = updateSettings(_settings.value.copy(longTermMemory = x))
    fun setCharacterBackground(id: String, uri: String, isGif: Boolean) = updateSettings(_settings.value.copy(characters = _settings.value.characters.map { if (it.id == id) it.copy(backgroundUri = uri, backgroundIsGif = isGif) else it }))
    fun setGlobalBackground(uri: String, isGif: Boolean) = updateSettings(_settings.value.copy(globalBackgroundUri = uri, globalBackgroundIsGif = isGif))

    fun importGlobalBackground(context: Context, uri: Uri) {
        try {
            val type = context.contentResolver.getType(uri).orEmpty()
            val ext = if (type.equals("image/gif", true)) "gif" else "img"
            val file = copyToPrivateFile(context, uri, "background_${UUID.randomUUID()}.$ext")
            setGlobalBackground(file.toURI().toString(), ext == "gif")
        } catch (e: Exception) { _error.value = "Background import failed: ${e.message}" }
    }

    private fun ByteArray.indexOf(value: Byte): Int { for (i in indices) if (this[i] == value) return i; return -1 }
}
