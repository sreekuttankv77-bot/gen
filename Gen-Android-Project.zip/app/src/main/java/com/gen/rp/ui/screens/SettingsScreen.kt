package com.gen.rp.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.gen.rp.data.*
import com.gen.rp.viewmodel.ChatViewModel
import java.io.BufferedReader
import java.io.InputStreamReader

private enum class Section(val label: String) { API("APIs"), CHARACTERS("Characters"), PERSONAS("Personas"), PRESETS("Presets"), REGEX("Regex"), MEMORY("Memory"), BACKGROUND("Background") }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: ChatViewModel, onBack: () -> Unit) {
    val settings by viewModel.settings.collectAsState()
    var section by remember { mutableStateOf(Section.API) }
    Scaffold(topBar = { TopAppBar(title = { Text("Settings") }, navigationIcon = { IconButton(onBack) { Icon(Icons.Default.ArrowBack, "Back") } }) }) { pad ->
        Row(Modifier.fillMaxSize().padding(pad)) {
            NavigationRail(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f)) {
                Section.entries.forEach { s ->
                    NavigationRailItem(selected = section == s, onClick = { section = s }, icon = {
                        Icon(when(s) { Section.API -> Icons.Default.Cloud; Section.CHARACTERS -> Icons.Default.Face; Section.PERSONAS -> Icons.Default.Person; Section.PRESETS -> Icons.Default.Tune; Section.REGEX -> Icons.Default.Code; Section.MEMORY -> Icons.Default.Memory; Section.BACKGROUND -> Icons.Default.Image }, null)
                    }, label = { Text(s.label, style = MaterialTheme.typography.labelSmall) })
                }
            }
            Box(Modifier.weight(1f).fillMaxHeight().padding(horizontal = 14.dp)) {
                when(section) {
                    Section.API -> ApiSection(viewModel, settings)
                    Section.CHARACTERS -> CharactersSection(viewModel, settings)
                    Section.PERSONAS -> PersonasSection(viewModel, settings)
                    Section.PRESETS -> PresetsSection(viewModel, settings)
                    Section.REGEX -> RegexSection(viewModel, settings)
                    Section.MEMORY -> MemorySection(viewModel, settings)
                    Section.BACKGROUND -> BackgroundSection(viewModel, settings)
                }
            }
        }
    }
}

@Composable private fun AppleHeader(title: String, subtitle: String? = null) {
    Column(Modifier.padding(top = 18.dp, bottom = 10.dp)) { Text(title, style = MaterialTheme.typography.headlineSmall); subtitle?.let { Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall) } }
}

@Composable private fun ApiSection(vm: ChatViewModel, s: AppSettings) {
    var edit by remember { mutableStateOf<ApiProfile?>(null) }
    var add by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        AppleHeader("API profiles", "Switch providers without leaving the chat.")
        s.apiProfiles.forEach { p ->
            SettingsCard(selected = p.id == s.activeApiId, onClick = { vm.setActiveApi(p.id) }) {
                Text(p.name, style = MaterialTheme.typography.titleMedium); Text(p.model, color = MaterialTheme.colorScheme.onSurfaceVariant); Text(p.baseUrl, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { IconButton({ edit = p }) { Icon(Icons.Default.Edit, "Edit") }; if (s.apiProfiles.size > 1) IconButton({ vm.deleteApiProfile(p.id) }) { Icon(Icons.Default.Delete, "Delete") } }
            }
        }
        Button({ add = true }, Modifier.fillMaxWidth().padding(vertical = 10.dp), shape = RoundedCornerShape(22.dp)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Add API profile") }
    }
    if (add || edit != null) ApiDialog(edit ?: ApiProfile(), { add = false; edit = null }) { p -> if (edit != null) vm.updateApiProfile(p) else vm.addApiProfile(p); add = false; edit = null }
}

@Composable private fun CharactersSection(vm: ChatViewModel, s: AppSettings) {
    val context = LocalContext.current
    var edit by remember { mutableStateOf<Character?>(null) }
    var add by remember { mutableStateOf(false) }
    val png = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) vm.importPngCharacter(context, uri) }
    val json = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) context.contentResolver.openInputStream(uri)?.use { vm.importCharacterCard(BufferedReader(InputStreamReader(it)).readText()) } }
    val zip = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) vm.importCharacterPack(context, uri) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        AppleHeader("Characters", "PNG cards are saved locally as a selectable character library.")
        s.characters.forEach { c ->
            SettingsCard(selected = c.id == s.activeCharacterId, onClick = { vm.setActiveCharacter(c.id) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (c.avatarUri.isNotBlank()) AsyncImage(ImageRequest.Builder(context).data(Uri.parse(c.avatarUri)).build(), null, Modifier.size(62.dp).clip(RoundedCornerShape(18.dp)))
                    Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(c.name, style = MaterialTheme.typography.titleMedium); Text(c.description.ifBlank { "No description" }, maxLines = 2, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { IconButton({ edit = c }) { Icon(Icons.Default.Edit, "Edit") }; if (s.characters.size > 1) IconButton({ vm.deleteCharacter(c.id) }) { Icon(Icons.Default.Delete, "Delete") } }
            }
        }
        Button({ png.launch("image/png") }, Modifier.fillMaxWidth().padding(top = 8.dp), shape = RoundedCornerShape(22.dp)) { Icon(Icons.Default.Image, null); Spacer(Modifier.width(8.dp)); Text("Import PNG character card") }
        OutlinedButton({ json.launch("application/json") }, Modifier.fillMaxWidth()) { Icon(Icons.Default.Description, null); Spacer(Modifier.width(8.dp)); Text("Import JSON character card") }
        OutlinedButton({ zip.launch("application/zip") }, Modifier.fillMaxWidth()) { Icon(Icons.Default.FolderZip, null); Spacer(Modifier.width(8.dp)); Text("Import ZIP character pack") }
        OutlinedButton({ add = true }, Modifier.fillMaxWidth().padding(bottom = 12.dp)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Create character") }
    }
    if (add || edit != null) CharacterDialog(edit ?: Character(), { add = false; edit = null }) { c -> if (edit != null) vm.updateCharacter(c) else vm.addCharacter(c); add = false; edit = null }
}

@Composable private fun PersonasSection(vm: ChatViewModel, s: AppSettings) {
    var edit by remember { mutableStateOf<UserPersona?>(null) }; var add by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        AppleHeader("User personas", "Choose who you are in each character chat.")
        s.personas.forEach { p ->
            SettingsCard(p.id == s.activePersonaId, { vm.setActivePersona(p.id) }) { Text(p.name, style = MaterialTheme.typography.titleMedium); Text(p.description.ifBlank { "No description" }, maxLines = 2, color = MaterialTheme.colorScheme.onSurfaceVariant); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { IconButton({ edit = p }) { Icon(Icons.Default.Edit, "Edit") }; if (s.personas.size > 1) IconButton({ vm.deletePersona(p.id) }) { Icon(Icons.Default.Delete, "Delete") } } }
        }
        Button({ add = true }, Modifier.fillMaxWidth().padding(vertical = 10.dp), shape = RoundedCornerShape(22.dp)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Create persona") }
    }
    if (add || edit != null) PersonaDialog(edit ?: UserPersona(), { add = false; edit = null }) { p -> if (edit != null) vm.updatePersona(p) else vm.addPersona(p); add = false; edit = null }
}

@Composable private fun PresetsSection(vm: ChatViewModel, s: AppSettings) {
    var edit by remember { mutableStateOf<GenerationPreset?>(null) }; var add by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        AppleHeader("Generation presets", "Reusable model parameters.")
        s.presets.forEach { p -> SettingsCard(p.id == s.activePresetId, { vm.setActivePreset(p.id) }) { Text(p.name, style = MaterialTheme.typography.titleMedium); Text("Temperature ${p.temperature}  •  ${p.maxTokens} tokens", color = MaterialTheme.colorScheme.onSurfaceVariant); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { IconButton({ edit = p }) { Icon(Icons.Default.Edit, "Edit") }; if (s.presets.size > 1) IconButton({ vm.deletePreset(p.id) }) { Icon(Icons.Default.Delete, "Delete") } } } }
        Button({ add = true }, Modifier.fillMaxWidth().padding(vertical = 10.dp), shape = RoundedCornerShape(22.dp)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Create preset") }
    }
    if (add || edit != null) PresetDialog(edit ?: GenerationPreset(), { add = false; edit = null }) { p -> if (edit != null) vm.updatePreset(p) else vm.addPreset(p); add = false; edit = null }
}

@Composable private fun RegexSection(vm: ChatViewModel, s: AppSettings) {
    var edit by remember { mutableStateOf<RegexScript?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        AppleHeader("Regex", "Transform user or character text before it is sent/displayed.")
        s.regexScripts.forEach { r -> SettingsCard(false, {}) { Row(verticalAlignment = Alignment.CenterVertically) { Switch(r.enabled, { vm.updateRegexScript(r.copy(enabled = it)) }); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text(r.name, style = MaterialTheme.typography.titleMedium); Text(r.find.ifBlank { "No pattern" }, maxLines = 1, color = MaterialTheme.colorScheme.onSurfaceVariant) }; IconButton({ edit = r }) { Icon(Icons.Default.Edit, "Edit") }; IconButton({ vm.deleteRegexScript(r.id) }) { Icon(Icons.Default.Delete, "Delete") } } }
        }
        Button({ edit = RegexScript() }, Modifier.fillMaxWidth().padding(vertical = 10.dp), shape = RoundedCornerShape(22.dp)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Add regex") }
    }
    edit?.let { x -> RegexDialog(x, { edit = null }) { r -> if (s.regexScripts.any { it.id == r.id }) vm.updateRegexScript(r) else vm.addRegexScript(r); edit = null } }
}

@Composable private fun MemorySection(vm: ChatViewModel, s: AppSettings) {
    var text by remember(s.longTermMemory) { mutableStateOf(s.longTermMemory) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) { AppleHeader("Memory", "This text is always included in the system context."); OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth().heightIn(min = 220.dp), label = { Text("Long-term memory") }, shape = RoundedCornerShape(20.dp)); Button({ vm.updateLongTermMemory(text) }, Modifier.fillMaxWidth().padding(top = 12.dp), shape = RoundedCornerShape(22.dp)) { Text("Save memory") } }
}

@Composable private fun BackgroundSection(vm: ChatViewModel, s: AppSettings) {
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) { vm.importGlobalBackground(context, uri) } }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) { AppleHeader("Background", "Use an image or animated GIF behind the chat."); Text(if (s.globalBackgroundUri.isBlank()) "No global background selected" else if (s.globalBackgroundIsGif) "Animated GIF enabled" else "Image enabled", color = MaterialTheme.colorScheme.onSurfaceVariant); Button({ launcher.launch("image/*") }, Modifier.fillMaxWidth().padding(top = 12.dp), shape = RoundedCornerShape(22.dp)) { Icon(Icons.Default.Image, null); Spacer(Modifier.width(8.dp)); Text("Choose image / GIF") }; if (s.globalBackgroundUri.isNotBlank()) OutlinedButton({ vm.setGlobalBackground("", false) }, Modifier.fillMaxWidth()) { Text("Remove background") } }
}

@Composable private fun SettingsCard(selected: Boolean, onClick: () -> Unit, content: @Composable ColumnScope.() -> Unit) { Card(Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable(onClick = onClick), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.72f))) { Column(Modifier.padding(16.dp), content = content) } }

@Composable private fun ApiDialog(initial: ApiProfile, onDismiss: () -> Unit, onSave: (ApiProfile) -> Unit) { var name by remember { mutableStateOf(initial.name) }; var url by remember { mutableStateOf(initial.baseUrl) }; var key by remember { mutableStateOf(initial.apiKey) }; var model by remember { mutableStateOf(initial.model) }; FormDialog(if (initial.id == ApiProfile().id) "Add API profile" else "Edit API profile", onDismiss, { onSave(initial.copy(name = name.ifBlank { "API" }, baseUrl = url, apiKey = key, model = model)); }) { Field("Name", name) { name = it }; Field("Base URL", url) { url = it }; Field("API key", key, PasswordVisualTransformation()) { key = it }; Field("Model", model) { model = it } } }
@Composable private fun CharacterDialog(initial: Character, onDismiss: () -> Unit, onSave: (Character) -> Unit) { var name by remember { mutableStateOf(initial.name) }; var desc by remember { mutableStateOf(initial.description) }; var pers by remember { mutableStateOf(initial.personality) }; var scen by remember { mutableStateOf(initial.scenario) }; var sys by remember { mutableStateOf(initial.systemPrompt) }; var first by remember { mutableStateOf(initial.firstMessage) }; FormDialog("Character", onDismiss, { onSave(initial.copy(name=name, description=desc, personality=pers, scenario=scen, systemPrompt=sys, firstMessage=first)) }) { Field("Name", name) { name=it }; Field("Description", desc, null, 2) { desc=it }; Field("Personality", pers, null, 2) { pers=it }; Field("Scenario", scen, null, 2) { scen=it }; Field("System prompt", sys, null, 3) { sys=it }; Field("First message", first, null, 3) { first=it } } }
@Composable private fun PersonaDialog(initial: UserPersona, onDismiss: () -> Unit, onSave: (UserPersona) -> Unit) { var name by remember { mutableStateOf(initial.name) }; var desc by remember { mutableStateOf(initial.description) }; var pers by remember { mutableStateOf(initial.personality) }; var bg by remember { mutableStateOf(initial.background) }; FormDialog("User persona", onDismiss, { onSave(initial.copy(name=name, description=desc, personality=pers, background=bg)) }) { Field("Name", name) { name=it }; Field("Description", desc, null, 2) { desc=it }; Field("Personality", pers, null, 2) { pers=it }; Field("Background", bg, null, 2) { bg=it } } }
@Composable private fun PresetDialog(initial: GenerationPreset, onDismiss: () -> Unit, onSave: (GenerationPreset) -> Unit) { var name by remember { mutableStateOf(initial.name) }; var temp by remember { mutableStateOf(initial.temperature.toString()) }; var max by remember { mutableStateOf(initial.maxTokens.toString()) }; var top by remember { mutableStateOf(initial.topP.toString()) }; FormDialog("Generation preset", onDismiss, { onSave(initial.copy(name=name.ifBlank { "Preset" }, temperature=temp.toDoubleOrNull() ?: initial.temperature, maxTokens=max.toIntOrNull() ?: initial.maxTokens, topP=top.toDoubleOrNull() ?: initial.topP)) }) { Field("Name", name) { name=it }; Field("Temperature", temp) { temp=it }; Field("Max tokens", max) { max=it }; Field("Top P", top) { top=it } } }
@Composable private fun RegexDialog(initial: RegexScript, onDismiss: () -> Unit, onSave: (RegexScript) -> Unit) { var name by remember { mutableStateOf(initial.name) }; var find by remember { mutableStateOf(initial.find) }; var replace by remember { mutableStateOf(initial.replace) }; var regex by remember { mutableStateOf(initial.isRegex) }; var user by remember { mutableStateOf(initial.applyToUser) }; var assistant by remember { mutableStateOf(initial.applyToAssistant) }; FormDialog("Regex script", onDismiss, { onSave(initial.copy(name=name, find=find, replace=replace, isRegex=regex, applyToUser=user, applyToAssistant=assistant)) }) { Field("Name", name) { name=it }; Field("Find / pattern", find, null, 2) { find=it }; Field("Replace", replace, null, 2) { replace=it }; Row(verticalAlignment=Alignment.CenterVertically) { Switch(regex,{regex=it}); Text("Regex mode") }; Row(verticalAlignment=Alignment.CenterVertically) { Switch(user,{user=it}); Text("Apply to user") }; Row(verticalAlignment=Alignment.CenterVertically) { Switch(assistant,{assistant=it}); Text("Apply to character") } } }

@Composable private fun FormDialog(title: String, onDismiss: () -> Unit, onSave: () -> Unit, content: @Composable ColumnScope.() -> Unit) { AlertDialog(onDismissRequest=onDismiss, title={Text(title)}, text={Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement=Arrangement.spacedBy(8.dp), content=content)}, confirmButton={TextButton(onSave){Text("Save")}}, dismissButton={TextButton(onDismiss){Text("Cancel")}}) }
@Composable private fun Field(label: String, value: String, transform: androidx.compose.ui.text.input.VisualTransformation? = null, minLines: Int = 1, onChange: (String) -> Unit) { OutlinedTextField(value,onChange,label={Text(label)},modifier=Modifier.fillMaxWidth(),minLines=minLines,maxLines=if(minLines>1)6 else 1,visualTransformation=transform ?: androidx.compose.ui.text.input.VisualTransformation.None,shape=RoundedCornerShape(16.dp)) }
