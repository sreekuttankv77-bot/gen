package com.gen.rp.data

import java.util.UUID

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val role: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class ApiProfile(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Default",
    val baseUrl: String = "https://api.openai.com/v1",
    val apiKey: String = "",
    val model: String = "gpt-4o-mini"
)

data class Character(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Character",
    val description: String = "",
    val personality: String = "",
    val scenario: String = "",
    val systemPrompt: String = "You are a helpful and immersive roleplay character. Stay in character at all times.",
    val firstMessage: String = "",
    val exampleMessages: String = "",
    val avatarUri: String = "",
    val backgroundUri: String = "",
    val backgroundIsGif: Boolean = false
)

data class UserPersona(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Default Persona",
    val description: String = "",
    val personality: String = "",
    val background: String = "",
    val avatarUri: String = ""
)

data class GenerationPreset(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Default",
    val temperature: Double = 0.9,
    val maxTokens: Int = 1024,
    val topP: Double = 1.0,
    val frequencyPenalty: Double = 0.0,
    val presencePenalty: Double = 0.0
)

data class RegexScript(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "New Script",
    val find: String = "",
    val replace: String = "",
    val enabled: Boolean = true,
    val applyToUser: Boolean = true,
    val applyToAssistant: Boolean = true,
    val isRegex: Boolean = true
)

data class AppSettings(
    val activeApiId: String = "",
    val activeCharacterId: String = "",
    val activePersonaId: String = "",
    val activePresetId: String = "",
    val longTermMemory: String = "",
    val apiProfiles: List<ApiProfile> = listOf(ApiProfile(name = "OpenAI")),
    val characters: List<Character> = listOf(Character()),
    val personas: List<UserPersona> = listOf(UserPersona()),
    val presets: List<GenerationPreset> = listOf(GenerationPreset()),
    val regexScripts: List<RegexScript> = emptyList(),
    val globalBackgroundUri: String = "",
    val globalBackgroundIsGif: Boolean = false
) {
    fun activeApi(): ApiProfile = apiProfiles.find { it.id == activeApiId } ?: apiProfiles.firstOrNull() ?: ApiProfile()
    fun activeCharacter(): Character = characters.find { it.id == activeCharacterId } ?: characters.firstOrNull() ?: Character()
    fun activePersona(): UserPersona = personas.find { it.id == activePersonaId } ?: personas.firstOrNull() ?: UserPersona()
    fun activePreset(): GenerationPreset = presets.find { it.id == activePresetId } ?: presets.firstOrNull() ?: GenerationPreset()
}

data class ChatCompletionRequest(
    val model: String,
    val messages: List<ApiMessage>,
    val temperature: Double = 0.9,
    val max_tokens: Int = 1024,
    val top_p: Double = 1.0,
    val frequency_penalty: Double = 0.0,
    val presence_penalty: Double = 0.0,
    val stream: Boolean = false
)

data class ApiMessage(val role: String, val content: String)
data class ChatCompletionResponse(val choices: List<Choice>?)
data class Choice(val message: ApiMessage?)

data class CharacterCard(
    val name: String? = null,
    val description: String? = null,
    val personality: String? = null,
    val scenario: String? = null,
    val first_mes: String? = null,
    val mes_example: String? = null,
    val system_prompt: String? = null,
    val post_history_instructions: String? = null,
    val data: CharacterCardData? = null
)

data class CharacterCardData(
    val name: String? = null,
    val description: String? = null,
    val personality: String? = null,
    val scenario: String? = null,
    val first_mes: String? = null,
    val mes_example: String? = null,
    val system_prompt: String? = null,
    val post_history_instructions: String? = null
)
