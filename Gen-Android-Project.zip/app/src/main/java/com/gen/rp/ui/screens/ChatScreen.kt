package com.gen.rp.ui.screens

import android.net.Uri
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Face
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.gen.rp.data.ChatMessage
import com.gen.rp.viewmodel.ChatViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ChatScreen(viewModel: ChatViewModel, onOpenSettings: () -> Unit) {
    val messages by viewModel.messages.collectAsState()
    val loading by viewModel.isLoading.collectAsState()
    val error by viewModel.error.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val selectionMode by viewModel.selectionMode.collectAsState()
    val selectedIds by viewModel.selectedIds.collectAsState()
    val character = settings.activeCharacter()
    val persona = settings.activePersona()
    val bg = character.backgroundUri.ifBlank { settings.globalBackgroundUri }
    val bgGif = if (character.backgroundUri.isNotBlank()) character.backgroundIsGif else settings.globalBackgroundIsGif
    var input by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    var personaMenu by remember { mutableStateOf(false) }
    var characterMenu by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val context = LocalContext.current

    LaunchedEffect(messages.size) { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex) }

    Box(Modifier.fillMaxSize()) {
        if (bg.isNotBlank()) {
            AsyncImage(
                model = ImageRequest.Builder(context).data(Uri.parse(bg)).crossfade(true).build(),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop,
                alpha = if (bgGif) 0.42f else 0.35f
            )
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.48f)))
        }

        Scaffold(
            containerColor = if (bg.isNotBlank()) Color.Transparent else MaterialTheme.colorScheme.background.copy(alpha = 0.96f),
            topBar = {
                if (selectionMode) {
                    TopAppBar(
                        title = { Text("${selectedIds.size} selected") },
                        navigationIcon = { IconButton({ viewModel.exitSelectionMode() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } },
                        actions = { IconButton({ viewModel.deleteSelected() }) { Icon(Icons.Default.Delete, "Delete") } }
                    )
                } else {
                    TopAppBar(
                        title = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (character.avatarUri.isNotBlank()) AsyncImage(ImageRequest.Builder(context).data(Uri.parse(character.avatarUri)).build(), null, Modifier.size(36.dp).clip(CircleShape), contentScale = ContentScale.Crop)
                                Spacer(Modifier.width(10.dp))
                                Column {
                                    Text(character.name.ifBlank { "Gen" }, style = MaterialTheme.typography.titleMedium)
                                    Text(persona.name, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        },
                        actions = {
                            Box {
                                IconButton({ menu = true }) { Icon(Icons.Default.MoreVert, "Menu") }
                                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                    DropdownMenuItem(text = { Text("User Persona") }, leadingIcon = { Icon(Icons.Default.Person, null) }, onClick = { menu = false; personaMenu = true })
                                    DropdownMenuItem(text = { Text("Characters") }, leadingIcon = { Icon(Icons.Default.Face, null) }, onClick = { menu = false; characterMenu = true })
                                    DropdownMenuItem(text = { Text("Clear Chat") }, leadingIcon = { Icon(Icons.Default.Clear, null) }, onClick = { menu = false; viewModel.clearChat() })
                                    DropdownMenuItem(text = { Text("Settings") }, leadingIcon = { Icon(Icons.Default.Settings, null) }, onClick = { menu = false; onOpenSettings() })
                                }
                            }
                        }
                    )
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(vertical = 14.dp)
                ) {
                    items(messages, key = { it.id }) { msg ->
                        MessageBubble(
                            msg = msg,
                            selected = msg.id in selectedIds,
                            selectionMode = selectionMode,
                            canReroll = msg.role == "assistant" && msg.id == messages.lastOrNull { it.role == "assistant" }?.id,
                            onReroll = { viewModel.rerollCurrentMessage() },
                            onLongClick = { if (!selectionMode) viewModel.enterSelectionMode(msg.id) },
                            onClick = { if (selectionMode) viewModel.toggleSelection(msg.id) }
                        )
                    }
                    if (loading) item { Text("Thinking…", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(8.dp)) }
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(horizontal = 18.dp, vertical = 4.dp)) }
                Surface(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                    shape = RoundedCornerShape(26.dp), tonalElevation = 3.dp,
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f)
                ) {
                    Row(Modifier.padding(6.dp), verticalAlignment = Alignment.Bottom) {
                        OutlinedTextField(
                            value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                            placeholder = { Text("Message…") }, maxLines = 5, shape = RoundedCornerShape(22.dp),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                            keyboardActions = KeyboardActions(onSend = { if (input.isNotBlank()) { viewModel.sendMessage(input); input = "" } }),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color.Transparent, unfocusedBorderColor = Color.Transparent)
                        )
                        IconButton(
                            onClick = { if (input.isNotBlank()) { viewModel.sendMessage(input); input = "" } },
                            enabled = !loading && input.isNotBlank(), modifier = Modifier.size(50.dp)
                        ) { Icon(Icons.Default.Send, "Send") }
                    }
                }
            }
        }
    }

    if (personaMenu) PersonaPicker(viewModel, settings, onDismiss = { personaMenu = false })
    if (characterMenu) CharacterPicker(viewModel, settings, onDismiss = { characterMenu = false })
}

@Composable
private fun PersonaPicker(viewModel: ChatViewModel, settings: com.gen.rp.data.AppSettings, onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Choose persona") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            settings.personas.forEach { p ->
                Surface(onClick = { viewModel.setActivePersona(p.id); onDismiss() }, shape = RoundedCornerShape(18.dp), tonalElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Text(p.name, Modifier.weight(1f)); if (p.id == settings.activePersonaId) Text("✓", color = MaterialTheme.colorScheme.primary) }
                }
            }
        }
    }, confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } })
}

@Composable
private fun CharacterPicker(viewModel: ChatViewModel, settings: com.gen.rp.data.AppSettings, onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Choose character") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            settings.characters.forEach { c ->
                Surface(onClick = { viewModel.setActiveCharacter(c.id); onDismiss() }, shape = RoundedCornerShape(18.dp), tonalElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (c.avatarUri.isNotBlank()) AsyncImage(ImageRequest.Builder(LocalContext.current).data(Uri.parse(c.avatarUri)).build(), null, Modifier.size(48.dp).clip(CircleShape), contentScale = ContentScale.Crop)
                        Spacer(Modifier.width(10.dp)); Text(c.name, Modifier.weight(1f)); if (c.id == settings.activeCharacterId) Text("✓", color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }, confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } })
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MessageBubble(msg: ChatMessage, selected: Boolean, selectionMode: Boolean, canReroll: Boolean, onReroll: () -> Unit, onLongClick: () -> Unit, onClick: () -> Unit) {
    val user = msg.role == "user"
    Column(Modifier.fillMaxWidth().combinedClickable(onClick = onClick, onLongClick = onLongClick), horizontalAlignment = if (user) Alignment.End else Alignment.Start) {
        Surface(
            modifier = Modifier.widthIn(max = 340.dp), shape = RoundedCornerShape(22.dp),
            color = when { selected -> MaterialTheme.colorScheme.primaryContainer; user -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.86f); else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.92f) },
            tonalElevation = 1.dp
        ) { Text(msg.content, modifier = Modifier.padding(horizontal = 15.dp, vertical = 12.dp), fontSize = 15.sp) }
        if (canReroll && !selectionMode) {
            TextButton(onClick = onReroll, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) {
                Icon(Icons.Default.Refresh, null, Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Reroll", fontSize = 12.sp)
            }
        }
    }
}
