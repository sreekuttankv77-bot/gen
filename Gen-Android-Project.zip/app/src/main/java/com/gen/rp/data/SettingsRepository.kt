package com.gen.rp.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "gen_settings")

class SettingsRepository(private val context: Context) {
    private val gson = Gson()
    private object Keys {
        val ACTIVE_API_ID = stringPreferencesKey("active_api_id")
        val ACTIVE_CHAR_ID = stringPreferencesKey("active_char_id")
        val ACTIVE_PERSONA_ID = stringPreferencesKey("active_persona_id")
        val ACTIVE_PRESET_ID = stringPreferencesKey("active_preset_id")
        val LONG_TERM_MEMORY = stringPreferencesKey("long_term_memory")
        val API_PROFILES = stringPreferencesKey("api_profiles")
        val CHARACTERS = stringPreferencesKey("characters")
        val PERSONAS = stringPreferencesKey("personas")
        val PRESETS = stringPreferencesKey("presets")
        val REGEX_SCRIPTS = stringPreferencesKey("regex_scripts")
        val GLOBAL_BG = stringPreferencesKey("global_background")
        val GLOBAL_BG_GIF = stringPreferencesKey("global_background_gif")
        val CHAT_HISTORY = stringPreferencesKey("chat_history")
    }

    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        val defaultApi = ApiProfile(name = "OpenAI")
        val defaultChar = Character()
        val defaultPersona = UserPersona()
        val defaultPreset = GenerationPreset()
        fun <T> list(key: Preferences.Key<String>, default: List<T>, type: java.lang.reflect.Type): List<T> = try {
            val json = prefs[key]
            if (json.isNullOrBlank()) default else gson.fromJson<List<T>>(json, type) ?: default
        } catch (_: Exception) { default }
        val apiProfiles = list(Keys.API_PROFILES, listOf(defaultApi), object : TypeToken<List<ApiProfile>>() {}.type)
        val characters = list(Keys.CHARACTERS, listOf(defaultChar), object : TypeToken<List<Character>>() {}.type)
        val personas = list(Keys.PERSONAS, listOf(defaultPersona), object : TypeToken<List<UserPersona>>() {}.type)
        val presets = list(Keys.PRESETS, listOf(defaultPreset), object : TypeToken<List<GenerationPreset>>() {}.type)
        val regexScripts = list(Keys.REGEX_SCRIPTS, emptyList<RegexScript>(), object : TypeToken<List<RegexScript>>() {}.type)
        AppSettings(
            activeApiId = prefs[Keys.ACTIVE_API_ID] ?: apiProfiles.firstOrNull()?.id.orEmpty(),
            activeCharacterId = prefs[Keys.ACTIVE_CHAR_ID] ?: characters.firstOrNull()?.id.orEmpty(),
            activePersonaId = prefs[Keys.ACTIVE_PERSONA_ID] ?: personas.firstOrNull()?.id.orEmpty(),
            activePresetId = prefs[Keys.ACTIVE_PRESET_ID] ?: presets.firstOrNull()?.id.orEmpty(),
            longTermMemory = prefs[Keys.LONG_TERM_MEMORY] ?: "",
            apiProfiles = apiProfiles,
            characters = characters,
            personas = personas,
            presets = presets,
            regexScripts = regexScripts,
            globalBackgroundUri = prefs[Keys.GLOBAL_BG] ?: "",
            globalBackgroundIsGif = prefs[Keys.GLOBAL_BG_GIF] == "true"
        )
    }

    suspend fun saveSettings(settings: AppSettings) = context.dataStore.edit { prefs ->
        prefs[Keys.ACTIVE_API_ID] = settings.activeApiId
        prefs[Keys.ACTIVE_CHAR_ID] = settings.activeCharacterId
        prefs[Keys.ACTIVE_PERSONA_ID] = settings.activePersonaId
        prefs[Keys.ACTIVE_PRESET_ID] = settings.activePresetId
        prefs[Keys.LONG_TERM_MEMORY] = settings.longTermMemory
        prefs[Keys.API_PROFILES] = gson.toJson(settings.apiProfiles)
        prefs[Keys.CHARACTERS] = gson.toJson(settings.characters)
        prefs[Keys.PERSONAS] = gson.toJson(settings.personas)
        prefs[Keys.PRESETS] = gson.toJson(settings.presets)
        prefs[Keys.REGEX_SCRIPTS] = gson.toJson(settings.regexScripts)
        prefs[Keys.GLOBAL_BG] = settings.globalBackgroundUri
        prefs[Keys.GLOBAL_BG_GIF] = settings.globalBackgroundIsGif.toString()
    }

    val chatHistoryFlow: Flow<String> = context.dataStore.data.map { it[Keys.CHAT_HISTORY] ?: "[]" }
    suspend fun saveChatHistory(json: String) = context.dataStore.edit { it[Keys.CHAT_HISTORY] = json }
}
