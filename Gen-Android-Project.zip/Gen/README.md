# Gen – AI Roleplay Chat App

Simple Android RP chat app (inspired by Tavo).  
Works with **any OpenAI-compatible API**.

## Features
- Any OpenAI-compatible endpoint (OpenAI, OpenRouter, Groq, Together, DeepSeek, Ollama, etc.)
- Character name + System Prompt
- Local chat history
- Clean dark UI

---

## Easiest way to get the APK (Online / GitHub)

### 1. Create a new GitHub repository
- Go to https://github.com/new
- Name it something like `Gen-RP`
- Make it **Public** (needed for free Actions)
- Don’t add README (we already have one)

### 2. Upload this project
You can either:
- Download the zip, extract it, then drag the files into the new GitHub repo, **or**
- Use GitHub Desktop / command line

### 3. Build the APK automatically
1. Go to the **Actions** tab of your new repo
2. Click **Build APK** (or the workflow name)
3. Click **Run workflow** → **Run workflow**
4. Wait 2–4 minutes
5. When it finishes, open the run → download the artifact called **Gen-APK**
6. Inside the zip you’ll find `app-debug.apk`

That’s it — install the APK on your phone (enable “Install from unknown sources”).

---

## Alternative: Build locally with Android Studio
1. Open the project folder in Android Studio
2. Build → Build Bundle(s) / APK(s) → Build APK(s)
3. APK will be in `app/build/outputs/apk/debug/`

---

## First time setup in the app
1. Open Settings (gear icon)
2. API Base URL example: `https://openrouter.ai/api/v1`
3. Paste your API Key
4. Model example: `openai/gpt-4o-mini` or `llama-3.1-70b-versatile`
5. Write character system prompt
6. Save and chat
