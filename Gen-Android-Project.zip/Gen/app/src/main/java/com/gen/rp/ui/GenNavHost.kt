package com.gen.rp.ui

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.gen.rp.ui.screens.ChatScreen
import com.gen.rp.ui.screens.SettingsScreen
import com.gen.rp.viewmodel.ChatViewModel

@Composable
fun GenNavHost() {
    val navController = rememberNavController()
    val viewModel: ChatViewModel = viewModel()

    NavHost(navController = navController, startDestination = "chat") {
        composable("chat") {
            ChatScreen(
                viewModel = viewModel,
                onOpenSettings = { navController.navigate("settings") }
            )
        }
        composable("settings") {
            SettingsScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
