package com.gen.rp.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.gen.rp.data.AppSettings
import com.gen.rp.viewmodel.ChatViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: ChatViewModel,
    onBack: () -> Unit
) {
    val current by viewModel.settings.collectAsState()

    var apiBase by remember { mutableStateOf(current.apiBaseUrl) }
    var apiKey by remember { mutableStateOf(current.apiKey) }
    var model by remember { mutableStateOf(current.model) }
    var charName by remember { mutableStateOf(current.characterName) }
    var systemPrompt by remember { mutableStateOf(current.systemPrompt) }

    // Keep in sync if settings change externally
    LaunchedEffect(current) {
        apiBase = current.apiBaseUrl
        apiKey = current.apiKey
        model = current.model
        charName = current.characterName
        systemPrompt = current.systemPrompt
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("API Configuration", style = MaterialTheme.typography.titleMedium)

            OutlinedTextField(
                value = apiBase,
                onValueChange = { apiBase = it },
                label = { Text("API Base URL") },
                placeholder = { Text("https://api.openai.com/v1") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = apiKey,
                onValueChange = { apiKey = it },
                label = { Text("API Key") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                visualTransformation = PasswordVisualTransformation()
            )

            OutlinedTextField(
                value = model,
                onValueChange = { model = it },
                label = { Text("Model") },
                placeholder = { Text("gpt-4o-mini / llama-3.1-70b / etc.") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            HorizontalDivider()

            Text("Character", style = MaterialTheme.typography.titleMedium)

            OutlinedTextField(
                value = charName,
                onValueChange = { charName = it },
                label = { Text("Character Name") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = systemPrompt,
                onValueChange = { systemPrompt = it },
                label = { Text("System Prompt / Personality") },
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 120.dp),
                maxLines = 8
            )

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = {
                    viewModel.updateSettings(
                        AppSettings(
                            apiBaseUrl = apiBase.trim(),
                            apiKey = apiKey.trim(),
                            model = model.trim(),
                            characterName = charName.trim().ifBlank { "Character" },
                            systemPrompt = systemPrompt.trim()
                        )
                    )
                    onBack()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Save")
            }

            Text(
                text = "Works with any OpenAI-compatible API:\n• OpenAI\n• OpenRouter\n• Groq\n• Together\n• DeepSeek\n• Local (Ollama / LM Studio)",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
