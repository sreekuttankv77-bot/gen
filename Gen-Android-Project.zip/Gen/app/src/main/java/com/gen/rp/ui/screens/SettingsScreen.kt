package com.gen.rp.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.gen.rp.data.*
import com.gen.rp.viewmodel.ChatViewModel
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: ChatViewModel,
    onBack: () -> Unit
) {
    val settings by viewModel.settings.collectAsState()
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("APIs", "Characters", "Memory", "Presets", "Regex", "Background")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            ScrollableTabRow(selectedTabIndex = selectedTab) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(title) }
                    )
                }
            }

            when (selectedTab) {
                0 -> ApisTab(viewModel, settings)
                1 -> CharactersTab(viewModel, settings)
                2 -> MemoryTab(viewModel, settings)
                3 -> PresetsTab(viewModel, settings)
                4 -> RegexTab(viewModel, settings)
                5 -> BackgroundTab(viewModel, settings)
            }
        }
    }
}

// ==================== APIs ====================

@Composable
private fun ApisTab(viewModel: ChatViewModel, settings: AppSettings) {
    var editing by remember { mutableStateOf<ApiProfile?>(null) }
    var showAdd by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("API Profiles", style = MaterialTheme.typography.titleMedium)
        Text(
            "Switch between different providers (OpenAI, OpenRouter, Groq, local, etc.)",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        settings.apiProfiles.forEach { profile ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.setActiveApi(profile.id) },
                colors = CardDefaults.cardColors(
                    containerColor = if (profile.id == settings.activeApiId)
                        MaterialTheme.colorScheme.primaryContainer
                    else MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(profile.name, style = MaterialTheme.typography.titleSmall)
                        Text(profile.model, style = MaterialTheme.typography.bodySmall)
                        Text(profile.baseUrl, style = MaterialTheme.typography.bodySmall, maxLines = 1)
                    }
                    IconButton(onClick = { editing = profile }) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit")
                    }
                    if (settings.apiProfiles.size > 1) {
                        IconButton(onClick = { viewModel.deleteApiProfile(profile.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete")
                        }
                    }
                }
            }
        }

        Button(
            onClick = { showAdd = true },
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Add API Profile")
        }
    }

    if (showAdd || editing != null) {
        ApiProfileDialog(
            initial = editing ?: ApiProfile(),
            onDismiss = { showAdd = false; editing = null },
            onSave = { profile ->
                if (editing != null) viewModel.updateApiProfile(profile)
                else viewModel.addApiProfile(profile)
                showAdd = false
                editing = null
            }
        )
    }
}

@Composable
private fun ApiProfileDialog(
    initial: ApiProfile,
    onDismiss: () -> Unit,
    onSave: (ApiProfile) -> Unit
) {
    var name by remember { mutableStateOf(initial.name) }
    var baseUrl by remember { mutableStateOf(initial.baseUrl) }
    var apiKey by remember { mutableStateOf(initial.apiKey) }
    var model by remember { mutableStateOf(initial.model) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial.name == "Default" && initial.apiKey.isBlank()) "New API Profile" else "Edit API Profile") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = baseUrl, onValueChange = { baseUrl = it }, label = { Text("Base URL") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, label = { Text("API Key") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = model, onValueChange = { model = it }, label = { Text("Model") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(initial.copy(name = name.trim().ifBlank { "API" }, baseUrl = baseUrl.trim(), apiKey = apiKey.trim(), model = model.trim()))
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// ==================== Characters ====================

@Composable
private fun CharactersTab(viewModel: ChatViewModel, settings: AppSettings) {
    val context = LocalContext.current
    var editing by remember { mutableStateOf<Character?>(null) }
    var showAdd by remember { mutableStateOf(false) }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        try {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                val json = BufferedReader(InputStreamReader(stream)).readText()
                viewModel.importCharacterCard(json)
            }
        } catch (e: Exception) {
            // error already set in ViewModel
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Characters", style = MaterialTheme.typography.titleMedium)

        settings.characters.forEach { char ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.setActiveCharacter(char.id) },
                colors = CardDefaults.cardColors(
                    containerColor = if (char.id == settings.activeCharacterId)
                        MaterialTheme.colorScheme.primaryContainer
                    else MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(char.name, style = MaterialTheme.typography.titleSmall)
                        if (char.description.isNotBlank()) {
                            Text(char.description, style = MaterialTheme.typography.bodySmall, maxLines = 2)
                        }
                    }
                    IconButton(onClick = { editing = char }) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit")
                    }
                    if (settings.characters.size > 1) {
                        IconButton(onClick = { viewModel.deleteCharacter(char.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete")
                        }
                    }
                }
            }
        }

        Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Add Character")
        }

        OutlinedButton(
            onClick = { importLauncher.launch("application/json") },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Import Character Card (JSON)")
        }

        Text(
            "Supports SillyTavern / TavernAI character card JSON (v1 & v2).",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }

    if (showAdd || editing != null) {
        CharacterDialog(
            initial = editing ?: Character(),
            onDismiss = { showAdd = false; editing = null },
            onSave = { char ->
                if (editing != null) viewModel.updateCharacter(char)
                else viewModel.addCharacter(char)
                showAdd = false
                editing = null
            }
        )
    }
}

@Composable
private fun CharacterDialog(
    initial: Character,
    onDismiss: () -> Unit,
    onSave: (Character) -> Unit
) {
    var name by remember { mutableStateOf(initial.name) }
    var description by remember { mutableStateOf(initial.description) }
    var personality by remember { mutableStateOf(initial.personality) }
    var scenario by remember { mutableStateOf(initial.scenario) }
    var systemPrompt by remember { mutableStateOf(initial.systemPrompt) }
    var firstMessage by remember { mutableStateOf(initial.firstMessage) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Character") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Description") }, modifier = Modifier.fillMaxWidth(), maxLines = 3)
                OutlinedTextField(value = personality, onValueChange = { personality = it }, label = { Text("Personality") }, modifier = Modifier.fillMaxWidth(), maxLines = 3)
                OutlinedTextField(value = scenario, onValueChange = { scenario = it }, label = { Text("Scenario") }, modifier = Modifier.fillMaxWidth(), maxLines = 3)
                OutlinedTextField(value = systemPrompt, onValueChange = { systemPrompt = it }, label = { Text("System Prompt") }, modifier = Modifier.fillMaxWidth().heightIn(min = 100.dp), maxLines = 6)
                OutlinedTextField(value = firstMessage, onValueChange = { firstMessage = it }, label = { Text("First Message") }, modifier = Modifier.fillMaxWidth(), maxLines = 4)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(
                    initial.copy(
                        name = name.trim().ifBlank { "Character" },
                        description = description.trim(),
                        personality = personality.trim(),
                        scenario = scenario.trim(),
                        systemPrompt = systemPrompt.trim(),
                        firstMessage = firstMessage.trim()
                    )
                )
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// ==================== Long-term Memory ====================

@Composable
private fun MemoryTab(viewModel: ChatViewModel, settings: AppSettings) {
    var memory by remember { mutableStateOf(settings.longTermMemory) }

    LaunchedEffect(settings.longTermMemory) {
        memory = settings.longTermMemory
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Long-term Memory", style = MaterialTheme.typography.titleMedium)
        Text(
            "This text is always injected into the system prompt so the character remembers important facts across the whole conversation.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        OutlinedTextField(
            value = memory,
            onValueChange = { memory = it },
            label = { Text("Memory") },
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 200.dp),
            maxLines = 20,
            placeholder = { Text("e.g. User's name is Alex. They live in Tokyo. They hate spiders...") }
        )

        Button(
            onClick = { viewModel.updateLongTermMemory(memory.trim()) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Save Memory")
        }
    }
}

// ==================== Presets ====================

@Composable
private fun PresetsTab(viewModel: ChatViewModel, settings: AppSettings) {
    var editing by remember { mutableStateOf<GenerationPreset?>(null) }
    var showAdd by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Generation Presets", style = MaterialTheme.typography.titleMedium)
        Text(
            "Temperature, max tokens, top-p, penalties…",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        settings.presets.forEach { preset ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.setActivePreset(preset.id) },
                colors = CardDefaults.cardColors(
                    containerColor = if (preset.id == settings.activePresetId)
                        MaterialTheme.colorScheme.primaryContainer
                    else MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(preset.name, style = MaterialTheme.typography.titleSmall)
                        Text(
                            "temp=${preset.temperature}  max=${preset.maxTokens}  top_p=${preset.topP}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    IconButton(onClick = { editing = preset }) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit")
                    }
                    if (settings.presets.size > 1) {
                        IconButton(onClick = { viewModel.deletePreset(preset.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete")
                        }
                    }
                }
            }
        }

        Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Add Preset")
        }
    }

    if (showAdd || editing != null) {
        PresetDialog(
            initial = editing ?: GenerationPreset(),
            onDismiss = { showAdd = false; editing = null },
            onSave = { p ->
                if (editing != null) viewModel.updatePreset(p)
                else viewModel.addPreset(p)
                showAdd = false
                editing = null
            }
        )
    }
}

@Composable
private fun PresetDialog(
    initial: GenerationPreset,
    onDismiss: () -> Unit,
    onSave: (GenerationPreset) -> Unit
) {
    var name by remember { mutableStateOf(initial.name) }
    var temperature by remember { mutableStateOf(initial.temperature.toString()) }
    var maxTokens by remember { mutableStateOf(initial.maxTokens.toString()) }
    var topP by remember { mutableStateOf(initial.topP.toString()) }
    var freqPenalty by remember { mutableStateOf(initial.frequencyPenalty.toString()) }
    var presPenalty by remember { mutableStateOf(initial.presencePenalty.toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Generation Preset") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = temperature, onValueChange = { temperature = it }, label = { Text("Temperature") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = maxTokens, onValueChange = { maxTokens = it }, label = { Text("Max Tokens") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = topP, onValueChange = { topP = it }, label = { Text("Top P") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = freqPenalty, onValueChange = { freqPenalty = it }, label = { Text("Frequency Penalty") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = presPenalty, onValueChange = { presPenalty = it }, label = { Text("Presence Penalty") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(
                    initial.copy(
                        name = name.trim().ifBlank { "Preset" },
                        temperature = temperature.toDoubleOrNull() ?: 0.9,
                        maxTokens = maxTokens.toIntOrNull() ?: 1024,
                        topP = topP.toDoubleOrNull() ?: 1.0,
                        frequencyPenalty = freqPenalty.toDoubleOrNull() ?: 0.0,
                        presencePenalty = presPenalty.toDoubleOrNull() ?: 0.0
                    )
                )
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// ==================== Regex ====================

@Composable
private fun RegexTab(viewModel: ChatViewModel, settings: AppSettings) {
    var editing by remember { mutableStateOf<RegexScript?>(null) }
    var showAdd by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Regex Scripts", style = MaterialTheme.typography.titleMedium)
        Text(
            "Find & replace rules applied to messages (before send / after receive).",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        settings.regexScripts.forEach { script ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(script.name + if (!script.enabled) " (disabled)" else "", style = MaterialTheme.typography.titleSmall)
                        Text("Find: ${script.find}", style = MaterialTheme.typography.bodySmall, maxLines = 1)
                        Text("Replace: ${script.replace}", style = MaterialTheme.typography.bodySmall, maxLines = 1)
                    }
                    IconButton(onClick = { editing = script }) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit")
                    }
                    IconButton(onClick = { viewModel.deleteRegexScript(script.id) }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete")
                    }
                }
            }
        }

        Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Add Regex Script")
        }
    }

    if (showAdd || editing != null) {
        RegexDialog(
            initial = editing ?: RegexScript(),
            onDismiss = { showAdd = false; editing = null },
            onSave = { s ->
                if (editing != null) viewModel.updateRegexScript(s)
                else viewModel.addRegexScript(s)
                showAdd = false
                editing = null
            }
        )
    }
}

@Composable
private fun RegexDialog(
    initial: RegexScript,
    onDismiss: () -> Unit,
    onSave: (RegexScript) -> Unit
) {
    var name by remember { mutableStateOf(initial.name) }
    var find by remember { mutableStateOf(initial.find) }
    var replace by remember { mutableStateOf(initial.replace) }
    var enabled by remember { mutableStateOf(initial.enabled) }
    var applyToUser by remember { mutableStateOf(initial.applyToUser) }
    var applyToAssistant by remember { mutableStateOf(initial.applyToAssistant) }
    var isRegex by remember { mutableStateOf(initial.isRegex) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Regex Script") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = find, onValueChange = { find = it }, label = { Text("Find") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = replace, onValueChange = { replace = it }, label = { Text("Replace") }, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = enabled, onCheckedChange = { enabled = it })
                    Text("Enabled")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isRegex, onCheckedChange = { isRegex = it })
                    Text("Treat as Regex")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = applyToUser, onCheckedChange = { applyToUser = it })
                    Text("Apply to User")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = applyToAssistant, onCheckedChange = { applyToAssistant = it })
                    Text("Apply to Assistant")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(
                    initial.copy(
                        name = name.trim().ifBlank { "Script" },
                        find = find,
                        replace = replace,
                        enabled = enabled,
                        applyToUser = applyToUser,
                        applyToAssistant = applyToAssistant,
                        isRegex = isRegex
                    )
                )
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// ==================== Background ====================

@Composable
private fun BackgroundTab(viewModel: ChatViewModel, settings: AppSettings) {
    val context = LocalContext.current
    val character = settings.activeCharacter()

    val charBgLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        // Take persistent permission if possible
        try {
            context.contentResolver.takePersistableUriPermission(
                uri,
                android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: Exception) { }
        viewModel.setCharacterBackground(character.id, uri.toString())
    }

    val globalBgLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        try {
            context.contentResolver.takePersistableUriPermission(
                uri,
                android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: Exception) { }
        viewModel.setGlobalBackground(uri.toString())
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Background Image", style = MaterialTheme.typography.titleMedium)
        Text(
            "Set a background for the current character or a global fallback.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Text("Current character: ${character.name}", style = MaterialTheme.typography.titleSmall)

        Button(
            onClick = { charBgLauncher.launch("image/*") },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Set Character Background")
        }

        if (character.backgroundUri.isNotBlank()) {
            OutlinedButton(
                onClick = { viewModel.setCharacterBackground(character.id, "") },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Clear Character Background")
            }
        }

        HorizontalDivider()

        Button(
            onClick = { globalBgLauncher.launch("image/*") },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Set Global Background")
        }

        if (settings.globalBackgroundUri.isNotBlank()) {
            OutlinedButton(
                onClick = { viewModel.setGlobalBackground("") },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Clear Global Background")
            }
        }
    }
}
