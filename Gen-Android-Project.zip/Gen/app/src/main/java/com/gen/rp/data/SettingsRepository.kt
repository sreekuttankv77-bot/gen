package com.gen.rp.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "gen_settings")

class SettingsRepository(private val context: Context) {

    private object Keys {
        val API_BASE = stringPreferencesKey("api_base")
        val API_KEY = stringPreferencesKey("api_key")
        val MODEL = stringPreferencesKey("model")
        val CHAR_NAME = stringPreferencesKey("char_name")
        val SYSTEM_PROMPT = stringPreferencesKey("system_prompt")
        val CHAT_HISTORY = stringPreferencesKey("chat_history")
    }

    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        AppSettings(
            apiBaseUrl = prefs[Keys.API_BASE] ?: "https://api.openai.com/v1",
            apiKey = prefs[Keys.API_KEY] ?: "",
            model = prefs[Keys.MODEL] ?: "gpt-4o-mini",
            characterName = prefs[Keys.CHAR_NAME] ?: "Character",
            systemPrompt = prefs[Keys.SYSTEM_PROMPT] ?: "You are a helpful and immersive roleplay character. Stay in character at all times."
        )
    }

    suspend fun saveSettings(settings: AppSettings) {
        context.dataStore.edit { prefs ->
            prefs[Keys.API_BASE] = settings.apiBaseUrl
            prefs[Keys.API_KEY] = settings.apiKey
            prefs[Keys.MODEL] = settings.model
            prefs[Keys.CHAR_NAME] = settings.characterName
            prefs[Keys.SYSTEM_PROMPT] = settings.systemPrompt
        }
    }

    val chatHistoryFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[Keys.CHAT_HISTORY] ?: "[]"
    }

    suspend fun saveChatHistory(json: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.CHAT_HISTORY] = json
        }
    }
}
