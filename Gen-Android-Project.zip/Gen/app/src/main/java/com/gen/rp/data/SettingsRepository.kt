package com.gen.rp.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "gen_settings")

class SettingsRepository(private val context: Context) {

    private val gson = Gson()

    private object Keys {
        val ACTIVE_API_ID = stringPreferencesKey("active_api_id")
        val ACTIVE_CHAR_ID = stringPreferencesKey("active_char_id")
        val ACTIVE_PRESET_ID = stringPreferencesKey("active_preset_id")
        val LONG_TERM_MEMORY = stringPreferencesKey("long_term_memory")
        val API_PROFILES = stringPreferencesKey("api_profiles")
        val CHARACTERS = stringPreferencesKey("characters")
        val PRESETS = stringPreferencesKey("presets")
        val REGEX_SCRIPTS = stringPreferencesKey("regex_scripts")
        val GLOBAL_BG = stringPreferencesKey("global_background")
        val CHAT_HISTORY = stringPreferencesKey("chat_history")
    }

    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        val defaultApi = ApiProfile(name = "OpenAI")
        val defaultChar = Character()
        val defaultPreset = GenerationPreset()

        val apiProfiles: List<ApiProfile> = try {
            val json = prefs[Keys.API_PROFILES]
            if (json.isNullOrBlank()) listOf(defaultApi)
            else gson.fromJson(json, object : TypeToken<List<ApiProfile>>() {}.type) ?: listOf(defaultApi)
        } catch (_: Exception) { listOf(defaultApi) }

        val characters: List<Character> = try {
            val json = prefs[Keys.CHARACTERS]
            if (json.isNullOrBlank()) listOf(defaultChar)
            else gson.fromJson(json, object : TypeToken<List<Character>>() {}.type) ?: listOf(defaultChar)
        } catch (_: Exception) { listOf(defaultChar) }

        val presets: List<GenerationPreset> = try {
            val json = prefs[Keys.PRESETS]
            if (json.isNullOrBlank()) listOf(defaultPreset)
            else gson.fromJson(json, object : TypeToken<List<GenerationPreset>>() {}.type) ?: listOf(defaultPreset)
        } catch (_: Exception) { listOf(defaultPreset) }

        val regexScripts: List<RegexScript> = try {
            val json = prefs[Keys.REGEX_SCRIPTS]
            if (json.isNullOrBlank()) emptyList()
            else gson.fromJson(json, object : TypeToken<List<RegexScript>>() {}.type) ?: emptyList()
        } catch (_: Exception) { emptyList() }

        AppSettings(
            activeApiId = prefs[Keys.ACTIVE_API_ID] ?: apiProfiles.firstOrNull()?.id.orEmpty(),
            activeCharacterId = prefs[Keys.ACTIVE_CHAR_ID] ?: characters.firstOrNull()?.id.orEmpty(),
            activePresetId = prefs[Keys.ACTIVE_PRESET_ID] ?: presets.firstOrNull()?.id.orEmpty(),
            longTermMemory = prefs[Keys.LONG_TERM_MEMORY] ?: "",
            apiProfiles = apiProfiles,
            characters = characters,
            presets = presets,
            regexScripts = regexScripts,
            globalBackgroundUri = prefs[Keys.GLOBAL_BG] ?: ""
        )
    }

    suspend fun saveSettings(settings: AppSettings) {
        context.dataStore.edit { prefs ->
            prefs[Keys.ACTIVE_API_ID] = settings.activeApiId
            prefs[Keys.ACTIVE_CHAR_ID] = settings.activeCharacterId
            prefs[Keys.ACTIVE_PRESET_ID] = settings.activePresetId
            prefs[Keys.LONG_TERM_MEMORY] = settings.longTermMemory
            prefs[Keys.API_PROFILES] = gson.toJson(settings.apiProfiles)
            prefs[Keys.CHARACTERS] = gson.toJson(settings.characters)
            prefs[Keys.PRESETS] = gson.toJson(settings.presets)
            prefs[Keys.REGEX_SCRIPTS] = gson.toJson(settings.regexScripts)
            prefs[Keys.GLOBAL_BG] = settings.globalBackgroundUri
        }
    }

    val chatHistoryFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[Keys.CHAT_HISTORY] ?: "[]"
    }

    suspend fun saveChatHistory(json: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.CHAT_HISTORY] = json
        }
    }
}
