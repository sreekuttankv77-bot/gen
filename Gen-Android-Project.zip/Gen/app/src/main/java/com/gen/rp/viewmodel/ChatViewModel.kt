package com.gen.rp.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.gen.rp.data.ApiMessage
import com.gen.rp.data.AppSettings
import com.gen.rp.data.ChatMessage
import com.gen.rp.data.SettingsRepository
import com.gen.rp.network.ApiClient
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = SettingsRepository(application)
    private val api = ApiClient()
    private val gson = Gson()

    private val _settings = MutableStateFlow(AppSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    init {
        viewModelScope.launch {
            _settings.value = repo.settingsFlow.first()
            loadHistory()
        }
        viewModelScope.launch {
            repo.settingsFlow.collect { _settings.value = it }
        }
    }

    private suspend fun loadHistory() {
        val json = repo.chatHistoryFlow.first()
        try {
            val type = object : TypeToken<List<ChatMessage>>() {}.type
            val list: List<ChatMessage> = gson.fromJson(json, type) ?: emptyList()
            _messages.value = list
        } catch (_: Exception) {
            _messages.value = emptyList()
        }
    }

    private fun saveHistory() {
        viewModelScope.launch {
            val json = gson.toJson(_messages.value)
            repo.saveChatHistory(json)
        }
    }

    fun updateSettings(newSettings: AppSettings) {
        viewModelScope.launch {
            repo.saveSettings(newSettings)
            _settings.value = newSettings
        }
    }

    fun clearChat() {
        _messages.value = emptyList()
        saveHistory()
    }

    fun sendMessage(userText: String) {
        if (userText.isBlank() || _isLoading.value) return

        val currentSettings = _settings.value
        if (currentSettings.apiKey.isBlank()) {
            _error.value = "Please set your API Key in Settings"
            return
        }

        val userMsg = ChatMessage("user", userText.trim())
        _messages.value = _messages.value + userMsg
        saveHistory()
        _isLoading.value = true
        _error.value = null

        viewModelScope.launch {
            val apiMessages = mutableListOf<ApiMessage>()

            // System prompt
            if (currentSettings.systemPrompt.isNotBlank()) {
                apiMessages.add(ApiMessage("system", currentSettings.systemPrompt))
            }

            // History (limit last 20 messages to keep context reasonable)
            _messages.value.takeLast(20).forEach { msg ->
                apiMessages.add(ApiMessage(msg.role, msg.content))
            }

            val result = api.sendChat(
                baseUrl = currentSettings.apiBaseUrl,
                apiKey = currentSettings.apiKey,
                model = currentSettings.model,
                messages = apiMessages
            )

            result.onSuccess { reply ->
                val assistantMsg = ChatMessage("assistant", reply)
                _messages.value = _messages.value + assistantMsg
                saveHistory()
            }.onFailure { e ->
                _error.value = e.message ?: "Unknown error"
                // Optional: remove the user message on failure
                // _messages.value = _messages.value.dropLast(1)
            }

            _isLoading.value = false
        }
    }

    fun clearError() {
        _error.value = null
    }
}
