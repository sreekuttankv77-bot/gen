package com.gen.rp.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.gen.rp.data.*
import com.gen.rp.network.ApiClient
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.UUID

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = SettingsRepository(application)
    private val api = ApiClient()
    private val gson = Gson()

    private val _settings = MutableStateFlow(AppSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    // Multi-select for delete
    private val _selectionMode = MutableStateFlow(false)
    val selectionMode: StateFlow<Boolean> = _selectionMode.asStateFlow()

    private val _selectedIds = MutableStateFlow<Set<String>>(emptySet())
    val selectedIds: StateFlow<Set<String>> = _selectedIds.asStateFlow()

    init {
        viewModelScope.launch {
            _settings.value = repo.settingsFlow.first()
            // Ensure active IDs point to something real
            val s = _settings.value
            if (s.activeApiId.isBlank() && s.apiProfiles.isNotEmpty()) {
                updateSettings(s.copy(activeApiId = s.apiProfiles.first().id))
            }
            if (s.activeCharacterId.isBlank() && s.characters.isNotEmpty()) {
                updateSettings(s.copy(activeCharacterId = s.characters.first().id))
            }
            if (s.activePresetId.isBlank() && s.presets.isNotEmpty()) {
                updateSettings(s.copy(activePresetId = s.presets.first().id))
            }
            loadHistory()
        }
        viewModelScope.launch {
            repo.settingsFlow.collect { _settings.value = it }
        }
    }

    // ---------- History ----------

    private suspend fun loadHistory() {
        val json = repo.chatHistoryFlow.first()
        try {
            val type = object : TypeToken<List<ChatMessage>>() {}.type
            val list: List<ChatMessage> = gson.fromJson(json, type) ?: emptyList()
            // Ensure every message has an id (migration from old format)
            _messages.value = list.map { msg ->
                if (msg.id.isBlank()) msg.copy(id = java.util.UUID.randomUUID().toString()) else msg
            }
        } catch (_: Exception) {
            _messages.value = emptyList()
        }
    }

    private fun saveHistory() {
        viewModelScope.launch {
            val json = gson.toJson(_messages.value)
            repo.saveChatHistory(json)
        }
    }

    fun updateSettings(newSettings: AppSettings) {
        viewModelScope.launch {
            repo.saveSettings(newSettings)
            _settings.value = newSettings
        }
    }

    fun clearChat() {
        _messages.value = emptyList()
        _selectedIds.value = emptySet()
        _selectionMode.value = false
        saveHistory()
    }

    // ---------- Selection / Delete ----------

    fun enterSelectionMode(messageId: String) {
        _selectionMode.value = true
        _selectedIds.value = setOf(messageId)
    }

    fun toggleSelection(messageId: String) {
        val current = _selectedIds.value.toMutableSet()
        if (current.contains(messageId)) current.remove(messageId) else current.add(messageId)
        _selectedIds.value = current
        if (current.isEmpty()) _selectionMode.value = false
    }

    fun exitSelectionMode() {
        _selectionMode.value = false
        _selectedIds.value = emptySet()
    }

    fun deleteSelected() {
        val ids = _selectedIds.value
        if (ids.isEmpty()) return
        _messages.value = _messages.value.filter { it.id !in ids }
        saveHistory()
        exitSelectionMode()
    }

    fun deleteMessage(id: String) {
        _messages.value = _messages.value.filter { it.id != id }
        saveHistory()
    }

    // ---------- Regex ----------

    private fun applyRegex(text: String, role: String): String {
        var result = text
        val scripts = _settings.value.regexScripts.filter { it.enabled }
        for (script in scripts) {
            if (role == "user" && !script.applyToUser) continue
            if (role == "assistant" && !script.applyToAssistant) continue
            if (script.find.isBlank()) continue
            try {
                result = if (script.isRegex) {
                    result.replace(Regex(script.find), script.replace)
                } else {
                    result.replace(script.find, script.replace)
                }
            } catch (_: Exception) {
                // ignore bad regex
            }
        }
        return result
    }

    // ---------- Send ----------

    fun sendMessage(userText: String) {
        if (userText.isBlank() || _isLoading.value) return

        val current = _settings.value
        val apiProfile = current.activeApi()
        val character = current.activeCharacter()
        val preset = current.activePreset()

        if (apiProfile.apiKey.isBlank()) {
            _error.value = "Please set your API Key in Settings → APIs"
            return
        }

        val processedUser = applyRegex(userText.trim(), "user")
        val userMsg = ChatMessage(role = "user", content = processedUser)
        _messages.value = _messages.value + userMsg
        saveHistory()
        _isLoading.value = true
        _error.value = null

        viewModelScope.launch {
            val apiMessages = mutableListOf<ApiMessage>()

            // Build system prompt: character + long-term memory
            val systemParts = mutableListOf<String>()
            if (character.systemPrompt.isNotBlank()) systemParts.add(character.systemPrompt)
            if (character.description.isNotBlank()) systemParts.add("Description: ${character.description}")
            if (character.personality.isNotBlank()) systemParts.add("Personality: ${character.personality}")
            if (character.scenario.isNotBlank()) systemParts.add("Scenario: ${character.scenario}")
            if (current.longTermMemory.isNotBlank()) {
                systemParts.add("Long-term Memory:\n${current.longTermMemory}")
            }
            if (systemParts.isNotEmpty()) {
                apiMessages.add(ApiMessage("system", systemParts.joinToString("\n\n")))
            }

            // Example messages (if any)
            if (character.exampleMessages.isNotBlank()) {
                // simple: treat as a system note
                apiMessages.add(ApiMessage("system", "Example dialogue:\n${character.exampleMessages}"))
            }

            // History (last 30 messages)
            _messages.value.takeLast(30).forEach { msg ->
                apiMessages.add(ApiMessage(msg.role, msg.content))
            }

            val result = api.sendChat(
                baseUrl = apiProfile.baseUrl,
                apiKey = apiProfile.apiKey,
                model = apiProfile.model,
                messages = apiMessages,
                preset = preset
            )

            result.onSuccess { reply ->
                val processedReply = applyRegex(reply, "assistant")
                val assistantMsg = ChatMessage(role = "assistant", content = processedReply)
                _messages.value = _messages.value + assistantMsg
                saveHistory()
            }.onFailure { e ->
                _error.value = e.message ?: "Unknown error"
            }

            _isLoading.value = false
        }
    }

    fun clearError() {
        _error.value = null
    }

    // ---------- API Profiles ----------

    fun addApiProfile(profile: ApiProfile) {
        val s = _settings.value
        updateSettings(s.copy(apiProfiles = s.apiProfiles + profile))
    }

    fun updateApiProfile(profile: ApiProfile) {
        val s = _settings.value
        updateSettings(s.copy(apiProfiles = s.apiProfiles.map { if (it.id == profile.id) profile else it }))
    }

    fun deleteApiProfile(id: String) {
        val s = _settings.value
        if (s.apiProfiles.size <= 1) return
        val newList = s.apiProfiles.filter { it.id != id }
        val newActive = if (s.activeApiId == id) newList.first().id else s.activeApiId
        updateSettings(s.copy(apiProfiles = newList, activeApiId = newActive))
    }

    fun setActiveApi(id: String) {
        updateSettings(_settings.value.copy(activeApiId = id))
    }

    // ---------- Characters ----------

    fun addCharacter(character: Character) {
        val s = _settings.value
        updateSettings(s.copy(characters = s.characters + character))
    }

    fun updateCharacter(character: Character) {
        val s = _settings.value
        updateSettings(s.copy(characters = s.characters.map { if (it.id == character.id) character else it }))
    }

    fun deleteCharacter(id: String) {
        val s = _settings.value
        if (s.characters.size <= 1) return
        val newList = s.characters.filter { it.id != id }
        val newActive = if (s.activeCharacterId == id) newList.first().id else s.activeCharacterId
        updateSettings(s.copy(characters = newList, activeCharacterId = newActive))
    }

    fun setActiveCharacter(id: String) {
        updateSettings(_settings.value.copy(activeCharacterId = id))
        // Optionally clear chat when switching character
        // clearChat()
    }

    fun importCharacterCard(json: String): Boolean {
        return try {
            val card = gson.fromJson(json, CharacterCard::class.java)
            val data = card.data
            val name = data?.name ?: card.name ?: "Imported Character"
            val description = data?.description ?: card.description ?: ""
            val personality = data?.personality ?: card.personality ?: ""
            val scenario = data?.scenario ?: card.scenario ?: ""
            val firstMes = data?.first_mes ?: card.first_mes ?: ""
            val mesExample = data?.mes_example ?: card.mes_example ?: ""
            val systemPrompt = data?.system_prompt ?: card.system_prompt
                ?: listOfNotNull(
                    description.takeIf { it.isNotBlank() },
                    personality.takeIf { it.isNotBlank() }?.let { "Personality: $it" },
                    scenario.takeIf { it.isNotBlank() }?.let { "Scenario: $it" }
                ).joinToString("\n\n").ifBlank {
                    "You are $name. Stay in character at all times."
                }

            val character = Character(
                name = name,
                description = description,
                personality = personality,
                scenario = scenario,
                systemPrompt = systemPrompt,
                firstMessage = firstMes,
                exampleMessages = mesExample
            )
            addCharacter(character)
            setActiveCharacter(character.id)

            // Send first message if present
            if (firstMes.isNotBlank()) {
                val msg = ChatMessage(role = "assistant", content = firstMes)
                _messages.value = listOf(msg)
                saveHistory()
            }
            true
        } catch (e: Exception) {
            _error.value = "Failed to import character card: ${e.message}"
            false
        }
    }

    // ---------- Presets ----------

    fun addPreset(preset: GenerationPreset) {
        val s = _settings.value
        updateSettings(s.copy(presets = s.presets + preset))
    }

    fun updatePreset(preset: GenerationPreset) {
        val s = _settings.value
        updateSettings(s.copy(presets = s.presets.map { if (it.id == preset.id) preset else it }))
    }

    fun deletePreset(id: String) {
        val s = _settings.value
        if (s.presets.size <= 1) return
        val newList = s.presets.filter { it.id != id }
        val newActive = if (s.activePresetId == id) newList.first().id else s.activePresetId
        updateSettings(s.copy(presets = newList, activePresetId = newActive))
    }

    fun setActivePreset(id: String) {
        updateSettings(_settings.value.copy(activePresetId = id))
    }

    // ---------- Regex Scripts ----------

    fun addRegexScript(script: RegexScript) {
        val s = _settings.value
        updateSettings(s.copy(regexScripts = s.regexScripts + script))
    }

    fun updateRegexScript(script: RegexScript) {
        val s = _settings.value
        updateSettings(s.copy(regexScripts = s.regexScripts.map { if (it.id == script.id) script else it }))
    }

    fun deleteRegexScript(id: String) {
        val s = _settings.value
        updateSettings(s.copy(regexScripts = s.regexScripts.filter { it.id != id }))
    }

    // ---------- Long-term memory ----------

    fun updateLongTermMemory(memory: String) {
        updateSettings(_settings.value.copy(longTermMemory = memory))
    }

    // ---------- Background ----------

    fun setCharacterBackground(characterId: String, uri: String) {
        val s = _settings.value
        val updated = s.characters.map {
            if (it.id == characterId) it.copy(backgroundUri = uri) else it
        }
        updateSettings(s.copy(characters = updated))
    }

    fun setGlobalBackground(uri: String) {
        updateSettings(_settings.value.copy(globalBackgroundUri = uri))
    }
}
