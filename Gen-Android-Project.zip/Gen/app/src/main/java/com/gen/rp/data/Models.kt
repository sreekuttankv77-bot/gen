package com.gen.rp.data

data class ChatMessage(
    val role: String, // "user", "assistant", "system"
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class AppSettings(
    val apiBaseUrl: String = "https://api.openai.com/v1",
    val apiKey: String = "",
    val model: String = "gpt-4o-mini",
    val characterName: String = "Character",
    val systemPrompt: String = "You are a helpful and immersive roleplay character. Stay in character at all times."
)

data class ChatCompletionRequest(
    val model: String,
    val messages: List<ApiMessage>,
    val temperature: Double = 0.9,
    val max_tokens: Int = 1024,
    val stream: Boolean = false
)

data class ApiMessage(
    val role: String,
    val content: String
)

data class ChatCompletionResponse(
    val choices: List<Choice>?
)

data class Choice(
    val message: ApiMessage?
)
