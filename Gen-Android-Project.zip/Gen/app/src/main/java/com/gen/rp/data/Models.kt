package com.gen.rp.data

import java.util.UUID

// ---------- Core chat ----------

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val role: String, // "user", "assistant", "system"
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)

// ---------- API Profiles (multiple APIs) ----------

data class ApiProfile(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Default",
    val baseUrl: String = "https://api.openai.com/v1",
    val apiKey: String = "",
    val model: String = "gpt-4o-mini"
)

// ---------- Characters ----------

data class Character(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Character",
    val description: String = "",
    val personality: String = "",
    val scenario: String = "",
    val systemPrompt: String = "You are a helpful and immersive roleplay character. Stay in character at all times.",
    val firstMessage: String = "",
    val exampleMessages: String = "",
    val backgroundUri: String = ""          // content URI or file path
)

// ---------- Generation Presets ----------

data class GenerationPreset(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Default",
    val temperature: Double = 0.9,
    val maxTokens: Int = 1024,
    val topP: Double = 1.0,
    val frequencyPenalty: Double = 0.0,
    val presencePenalty: Double = 0.0
)

// ---------- Regex Scripts ----------

data class RegexScript(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "New Script",
    val find: String = "",
    val replace: String = "",
    val enabled: Boolean = true,
    val applyToUser: Boolean = true,
    val applyToAssistant: Boolean = true,
    val isRegex: Boolean = true             // if false, simple string replace
)

// ---------- App Settings (top-level) ----------

data class AppSettings(
    // Active selections
    val activeApiId: String = "",
    val activeCharacterId: String = "",
    val activePresetId: String = "",

    // Long-term memory (always injected)
    val longTermMemory: String = "",

    // Lists (stored as JSON in DataStore)
    val apiProfiles: List<ApiProfile> = listOf(ApiProfile(name = "OpenAI")),
    val characters: List<Character> = listOf(Character()),
    val presets: List<GenerationPreset> = listOf(GenerationPreset()),
    val regexScripts: List<RegexScript> = emptyList(),

    // Global background (fallback if character has none)
    val globalBackgroundUri: String = ""
) {
    fun activeApi(): ApiProfile =
        apiProfiles.find { it.id == activeApiId } ?: apiProfiles.firstOrNull() ?: ApiProfile()

    fun activeCharacter(): Character =
        characters.find { it.id == activeCharacterId } ?: characters.firstOrNull() ?: Character()

    fun activePreset(): GenerationPreset =
        presets.find { it.id == activePresetId } ?: presets.firstOrNull() ?: GenerationPreset()
}

// ---------- API request / response ----------

data class ChatCompletionRequest(
    val model: String,
    val messages: List<ApiMessage>,
    val temperature: Double = 0.9,
    val max_tokens: Int = 1024,
    val top_p: Double = 1.0,
    val frequency_penalty: Double = 0.0,
    val presence_penalty: Double = 0.0,
    val stream: Boolean = false
)

data class ApiMessage(
    val role: String,
    val content: String
)

data class ChatCompletionResponse(
    val choices: List<Choice>?
)

data class Choice(
    val message: ApiMessage?
)

// ---------- Character Card (import) ----------

/**
 * Supports common SillyTavern / TavernAI JSON card formats (spec v1 / v2).
 * We map the most useful fields.
 */
data class CharacterCard(
    val name: String? = null,
    val description: String? = null,
    val personality: String? = null,
    val scenario: String? = null,
    val first_mes: String? = null,
    val mes_example: String? = null,
    val system_prompt: String? = null,
    val post_history_instructions: String? = null,
    // Spec v2 nested
    val data: CharacterCardData? = null
)

data class CharacterCardData(
    val name: String? = null,
    val description: String? = null,
    val personality: String? = null,
    val scenario: String? = null,
    val first_mes: String? = null,
    val mes_example: String? = null,
    val system_prompt: String? = null,
    val post_history_instructions: String? = null
)
