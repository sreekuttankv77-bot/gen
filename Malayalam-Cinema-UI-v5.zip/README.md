# Malayalam Cinema

Offline Android Malayalam cinema archive UI based on the supplied reference design.

## UI
- Exact dark Apple-style structure from the supplied reference: Home, Years, Year detail, Movie detail, Favorites, Search and More.
- Yellow accent, rounded cards, bottom navigation, year browsing and timeline-ready architecture.
- Favorites are stored locally with SharedPreferences.

## Data
The current working base contains the movie records supplied in `app/src/main/assets/movies.json`. It is intentionally kept separate from the UI so the full archive can be swapped in without redesigning the app.

## Build
GitHub Actions installs Gradle 8.10.2 and runs `./gradlew assembleDebug`.
