# CHITHRAM v11 — Full Malayalam Cinema Catalog

This build keeps the approved UI and CHITHRAM splash screen. The catalog now performs a background full-catalog sync from M3DB's Malayalam film archive by year (1928–2026) and stores the result locally as `movies_full_v11.json` for subsequent launches.

The bundled 106-film JSON remains as an offline bootstrap so the app has content immediately before the first sync completes.

Catalog fields collected from the archive include title, year, director, screenplay, and release date where available. Posters continue to load/cache from the existing poster pipeline.

Source: https://m3db.com/archive/year
