#!/usr/bin/env python3
"""Build the released Malayalam-film catalogue from MalayalaChalachithram.

The source's English year lists are used to discover films. Each movie detail
page is then checked for release status and enriched with available metadata.
"""
import concurrent.futures
import io
import json
import re
import sys
import threading
import time
from pathlib import Path
from urllib.parse import parse_qs, urlencode, urljoin, urlparse, urlunparse

import requests
from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "app" / "src" / "main" / "assets" / "movies.json"
CACHE = ROOT / "tools" / ".movie_cache.json"
BASE = "https://www.malayalachalachithram.com/"
START = 1928
END = 2026
WORKERS = 8
UA = "Mozilla/5.0 (X11; Linux x86_64) Chithram-Full-Database/16"

thread_local = threading.local()


def session():
    if not hasattr(thread_local, "session"):
        s = requests.Session()
        s.headers.update({"User-Agent": UA, "Accept-Language": "en-US,en;q=0.8"})
        thread_local.session = s
    return thread_local.session


def clean(value):
    return " ".join((value or "").split()).strip()


def norm(value):
    return re.sub(r"[^a-z0-9]+", " ", clean(value).lower()).strip()


def fetch(url, attempts=4):
    last = None
    for attempt in range(attempts):
        try:
            r = session().get(url, timeout=30)
            r.raise_for_status()
            return r.text
        except Exception as exc:
            last = exc
            time.sleep(1.5 * (attempt + 1))
    raise last


def english_url(url):
    p = urlparse(url)
    q = parse_qs(p.query)
    q["ln"] = ["en"]
    return urlunparse((p.scheme, p.netloc, p.path, p.params, urlencode(q, doseq=True), p.fragment))


def discover_year(year):
    """Follow all pagination links for a year and return movie candidates."""
    first = f"{BASE}movieslist.php?{urlencode({'y': year, 'ln': 'en'})}"
    queue = [first]
    seen = set()
    movies = {}

    while queue:
        url = queue.pop(0)
        if url in seen:
            continue
        seen.add(url)
        html = fetch(url)
        soup = BeautifulSoup(html, "html.parser")

        for a in soup.select('a[href*="movie.php"]'):
            title = clean(a.get_text(" ", strip=True))
            href = a.get("href", "")
            if not title or title.lower() in {"movie details", "list songs"}:
                continue
            detail = english_url(urljoin(BASE, href))
            if "movie.php" not in detail:
                continue

            parent = a.parent
            block = clean(parent.get_text(" ", strip=True)) if parent else ""
            if len(block) < len(title):
                block = title
            starring = ""
            m = re.search(r"Starring\s*:\s*(.*?)(?:Movie Details|List songs|$)", block, re.I)
            if m:
                starring = clean(m.group(1))

            key = (norm(title), year, detail)
            movies[key] = {
                "title": title,
                "year": year,
                "detailUrl": detail,
                "cast": starring,
                "source": "MalayalaChalachithram",
            }

        # The pagination links are all on the current year list.
        for a in soup.select('a[href*="movieslist.php"]'):
            href = urljoin(BASE, a.get("href", ""))
            q = parse_qs(urlparse(href).query)
            if str(year) in q.get("y", []) and "p" in q:
                href = english_url(href)
                if href not in seen:
                    queue.append(href)

    return list(movies.values())


LABELS = [
    "Status", "Direction", "Director", "Production", "Producer", "Banner",
    "Story", "Screenplay", "Dialogue", "Cinematography", "Editing",
    "Art Direction", "Costume", "Makeup", "Distribution", "Music",
    "Background Music", "Lyrics", "Singers",
]
LABEL_RE = re.compile(
    r"(?:^|\s)(" + "|".join(re.escape(x) for x in LABELS) + r")\s*:?\s*",
    re.I,
)


def fields_from_text(text):
    matches = list(LABEL_RE.finditer(text))
    out = {}
    for i, m in enumerate(matches):
        label = m.group(1).lower().replace(" ", "_")
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        value = clean(text[m.end():end])
        if value:
            out[label] = value
    return out


def poster_url(soup, detail_url):
    # Prefer images whose alt/class/filename suggests a poster.
    candidates = []
    for img in soup.find_all("img"):
        src = img.get("src") or img.get("data-src") or ""
        if not src:
            continue
        alt = clean(img.get("alt", "")).lower()
        score = 0
        if "poster" in alt:
            score += 5
        if "poster" in src.lower():
            score += 3
        if "movie" in src.lower():
            score += 1
        candidates.append((score, urljoin(detail_url, src)))
    candidates.sort(reverse=True)
    return candidates[0][1] if candidates else ""


def parse_detail(candidate):
    html = fetch(candidate["detailUrl"])
    soup = BeautifulSoup(html, "html.parser")
    text = clean(soup.get_text(" ", strip=True))
    fields = fields_from_text(text)

    status = fields.get("status", "")
    status_low = status.lower()
    # Only keep films explicitly marked as released. This intentionally rejects
    # upcoming/to-be-released entries and avoids guessing when status is absent.
    if "release" not in status_low or any(x in status_low for x in ["upcoming", "to be released", "not released"]):
        return None

    result = dict(candidate)
    result["releaseStatus"] = status
    result["releaseDate"] = ""
    date_match = re.search(r"(\d{1,2}[-/]\d{1,2}[-/]\d{4})", status)
    if date_match:
        result["releaseDate"] = date_match.group(1)

    result["director"] = fields.get("direction", fields.get("director", ""))
    result["producer"] = fields.get("production", fields.get("producer", ""))
    result["banner"] = fields.get("banner", "")
    result["story"] = fields.get("story", "")
    result["screenplay"] = fields.get("screenplay", "")
    result["dialogue"] = fields.get("dialogue", "")
    result["cinematography"] = fields.get("cinematography", "")
    result["editing"] = fields.get("editing", "")
    result["music"] = fields.get("music", "")
    result["backgroundMusic"] = fields.get("background_music", "")
    result["poster"] = poster_url(soup, candidate["detailUrl"])
    result["genre"] = ""
    result["rating"] = None
    result["synopsis"] = ""
    result.pop("detailUrl", None)
    return result



def poster_filename(movie):
    key = re.sub(r"[^A-Za-z0-9_-]", "_", norm(movie.get("title", ""))) + "_" + str(movie.get("year", 0))
    return key + ".jpg"


def download_one_poster(movie):
    src = (movie.get("poster") or "").strip()
    if not src:
        return False
    filename = poster_filename(movie)
    target = POSTER_DIR / filename
    if target.exists() and target.stat().st_size > 0:
        movie["posterLocal"] = "posters/" + filename
        return True
    try:
        r = requests.get(src, headers={"User-Agent": "Mozilla/5.0 Chithram Malayalam Cinema"}, timeout=(8, 20))
        r.raise_for_status()
        from PIL import Image
        image = Image.open(io.BytesIO(r.content)).convert("RGB")
        image.thumbnail((700, 1050), Image.Resampling.LANCZOS)
        POSTER_DIR.mkdir(parents=True, exist_ok=True)
        image.save(target, "JPEG", quality=82, optimize=True)
        movie["posterLocal"] = "posters/" + filename
        return True
    except Exception:
        try:
            if target.exists(): target.unlink()
        except Exception:
            pass
        return False


def download_posters(data):
    POSTER_DIR.mkdir(parents=True, exist_ok=True)
    done = 0
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        futures = [pool.submit(download_one_poster, m) for m in data if m.get("poster")]
        for i, f in enumerate(concurrent.futures.as_completed(futures), 1):
            if f.result(): done += 1
            if i % 100 == 0 or i == len(futures):
                print(f"Posters: {i}/{len(futures)} | local={done}", flush=True)
    return done


def load_cache():
    if not CACHE.exists():
        return {}
    try:
        return json.loads(CACHE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_cache(cache):
    CACHE.parent.mkdir(parents=True, exist_ok=True)
    CACHE.write_text(json.dumps(cache, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")


def main():
    print(f"Discovering released Malayalam films from {START} through {END}...", flush=True)
    candidates = {}
    failed_years = []
    for year in range(START, END + 1):
        try:
            found = discover_year(year)
            for item in found:
                candidates[(norm(item["title"]), year, item["detailUrl"])] = item
            print(f"{year}: {len(found)} candidates | total={len(candidates)}", flush=True)
        except Exception as exc:
            failed_years.append(year)
            print(f"{year}: FAILED ({exc})", file=sys.stderr, flush=True)

    if len(failed_years) > 5:
        raise RuntimeError(f"Too many year-list failures: {failed_years}")

    cache = load_cache()
    released = []
    detail_failures = 0
    candidates_list = list(candidates.values())

    def work(item):
        key = item["detailUrl"]
        if key in cache:
            return cache[key]
        try:
            result = parse_detail(item)
            cache[key] = result if result is not None else False
            return result
        except Exception as exc:
            return exc

    with concurrent.futures.ThreadPoolExecutor(max_workers=WORKERS) as pool:
        futures = [pool.submit(work, item) for item in candidates_list]
        for i, future in enumerate(concurrent.futures.as_completed(futures), 1):
            result = future.result()
            if isinstance(result, Exception):
                detail_failures += 1
            elif result:
                released.append(result)
            if i % 100 == 0 or i == len(futures):
                print(f"Details: {i}/{len(futures)} | released={len(released)} | failures={detail_failures}", flush=True)
                save_cache(cache)

    if detail_failures > max(25, int(len(candidates_list) * 0.10)):
        raise RuntimeError(f"Too many movie-detail failures: {detail_failures}/{len(candidates_list)}")

    # De-duplicate by normalized English title + year.
    unique = {}
    for movie in released:
        key = (norm(movie.get("title", "")), int(movie.get("year", 0)))
        if key[0]:
            unique[key] = movie

    data = sorted(unique.values(), key=lambda m: (-int(m.get("year", 0)), norm(m.get("title", ""))))
    if len(data) < 3000:
        raise RuntimeError(f"Released-film database unexpectedly small: {len(data)} records")

    local_posters = download_posters(data)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(data, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    print(f"Wrote {len(data)} released Malayalam films to {OUT}; local posters={local_posters}", flush=True)


if __name__ == "__main__":
    main()
