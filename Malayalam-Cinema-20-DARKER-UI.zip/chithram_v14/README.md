# CHITHRAM v13

Malayalam Cinema Archive demo.

## What changed
- Existing approved UI retained.
- English/Latin-script movie titles are the display standard.
- Apple-style Android typography using the platform sans-serif family (no Apple proprietary font files redistributed).
- Year and decade movie lists use a clean 2-column responsive grid.
- Duplicate records are deduplicated by normalized English title + year.
- Startup no longer performs a full catalog crawl.
- The app loads the bundled catalog immediately.
- Full year data is fetched lazily only when a year/decade is opened, then cached locally.
- Real poster loader remains separate and asynchronous.

## Full catalog behavior
The complete source archive currently lists 7,011 Malayalam film records. This build does not bundle copyrighted third-party poster files or pretend that all 7,011 records are already embedded. Instead, it expands the catalog on demand from the source archive and caches fetched records locally.

Source reference: https://www.malayalachalachithram.com/movie.php?i=&ln=ml

### Local posters
The database build downloads available poster URLs, resizes them for Android, stores them under `app/src/main/assets/posters/`, and records `posterLocal` in `movies.json`. The app prefers bundled posters and falls back to network lookup only when a bundled poster is unavailable.
