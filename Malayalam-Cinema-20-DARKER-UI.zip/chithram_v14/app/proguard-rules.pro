# Keep rules for the Malayalam Cinema app.
