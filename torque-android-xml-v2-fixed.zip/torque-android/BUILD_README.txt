TORQUE Android project
======================
This is a complete Gradle Android project.

Build:
  ./gradlew assembleDebug

GitHub Actions:
  Use Gradle 8.10.2 + JDK 17.
  The project includes gradlew so workflows can locate it.
