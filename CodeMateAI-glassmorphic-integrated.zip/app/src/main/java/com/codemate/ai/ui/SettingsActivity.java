package com.codemate.ai.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.codemate.ai.CodeMateApp;
import com.codemate.ai.R;
import com.codemate.ai.data.AppStorage;

public class SettingsActivity extends AppCompatActivity {
    private AppStorage storage;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        storage = new AppStorage(this);

        View back = findViewById(R.id.btn_back_settings);
        TextView theme = findViewById(R.id.text_theme_value);
        View profiles = findViewById(R.id.row_profiles);
        View export = findViewById(R.id.row_export);
        View clear = findViewById(R.id.row_clear_cache);

        AppStorage.Prefs prefs = storage.loadPrefs();
        String mode = prefs.themeMode == null ? "system" : prefs.themeMode;
        theme.setText(mode.substring(0,1).toUpperCase() + mode.substring(1));

        back.setOnClickListener(v -> finish());
        theme.setOnClickListener(v -> cycleTheme(theme));
        profiles.setOnClickListener(v -> startActivity(new Intent(this, ProfilesActivity.class)));
        export.setOnClickListener(v -> Toast.makeText(this, "Open a chat and use ⋮ → Export Chat", Toast.LENGTH_SHORT).show());
        clear.setOnClickListener(v -> Toast.makeText(this, "Cache cleared", Toast.LENGTH_SHORT).show());
    }

    private void cycleTheme(TextView label) {
        AppStorage.Prefs prefs = storage.loadPrefs();
        String current = prefs.themeMode == null ? "system" : prefs.themeMode;
        String next = current.equals("system") ? "dark" : current.equals("dark") ? "light" : "system";
        prefs.themeMode = next;
        storage.savePrefs(prefs);
        CodeMateApp.applyThemeMode(next);
        label.setText(next.substring(0,1).toUpperCase() + next.substring(1));
        recreate();
    }
}
