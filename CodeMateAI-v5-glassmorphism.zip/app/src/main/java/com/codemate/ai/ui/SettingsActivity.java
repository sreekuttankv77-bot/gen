package com.codemate.ai.ui;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.codemate.ai.R;
import com.codemate.ai.CodeMateApp;
import com.codemate.ai.data.ApiProfile;
import com.codemate.ai.data.AppStorage;
import com.codemate.ai.data.ChatSession;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Full-screen Settings page. Replaces the chat screen entirely (no drawer,
 * no dialog) and matches the app's dark glassmorphism design system.
 */
public class SettingsActivity extends AppCompatActivity {

    private static final int REQ_IMPORT = 4821;

    private AppStorage storage;
    private AppStorage.Prefs prefs;
    private final Gson gson = new Gson();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        storage = new AppStorage(this);
        prefs = storage.loadPrefs();

        findViewById(R.id.btn_back_settings).setOnClickListener(v -> finish());

        bindAppearanceRow();
        bindStaticInfoRows();
        bindToggles();
        bindApiAndDataRows();
        updateCacheSizeLabel();
    }

    // ---------------- Appearance ----------------

    private void bindAppearanceRow() {
        TextView valueView = findViewById(R.id.text_appearance_value);
        valueView.setText(themeLabel(prefs.themeMode));
        findViewById(R.id.row_appearance).setOnClickListener(v -> {
            cycleTheme();
            valueView.setText(themeLabel(prefs.themeMode));
        });
    }

    private String themeLabel(String mode) {
        if ("light".equals(mode)) return "Light";
        if ("dark".equals(mode)) return "Dark";
        return "System";
    }

    private void cycleTheme() {
        String current = prefs.themeMode == null ? "system" : prefs.themeMode;
        String next;
        switch (current) {
            case "light": next = "dark"; break;
            case "dark": next = "system"; break;
            default: next = "light"; break;
        }
        prefs.themeMode = next;
        storage.savePrefs(prefs);
        CodeMateApp.applyThemeMode(next);
        recreate();
    }

    // ---------------- Static info rows (Theme Color / Language / About / Legal) ----------------

    private void bindStaticInfoRows() {
        findViewById(R.id.row_theme_color).setOnClickListener(v ->
                Toast.makeText(this, "Orange is CodeMate AI's signature accent color", Toast.LENGTH_SHORT).show());

        findViewById(R.id.row_language).setOnClickListener(v ->
                Toast.makeText(this, "Follows your system language", Toast.LENGTH_SHORT).show());

        findViewById(R.id.row_about).setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("About CodeMate AI")
                .setMessage("CodeMate AI\nVersion 1.0.0\n\nAn AI coding assistant that connects to your own API profiles.")
                .setPositiveButton("OK", null)
                .show());

        findViewById(R.id.row_privacy).setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Privacy Policy")
                .setMessage("Add your privacy policy content here, or link out to a hosted policy page.")
                .setPositiveButton("OK", null)
                .show());

        findViewById(R.id.row_licenses).setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Open Source Licenses")
                .setMessage("AndroidX, Material Components, and Gson are used under their respective open source licenses.")
                .setPositiveButton("OK", null)
                .show());
    }

    // ---------------- Toggles ----------------

    private void bindToggles() {
        bindToggle(R.id.toggle_notifications, R.id.knob_notifications, prefs.notificationsEnabled,
                v -> { prefs.notificationsEnabled = v; storage.savePrefs(prefs); });

        bindToggle(R.id.toggle_autosave, R.id.knob_autosave, prefs.autoSaveChats,
                v -> { prefs.autoSaveChats = v; storage.savePrefs(prefs); });

        bindToggle(R.id.toggle_stream, R.id.knob_stream, prefs.streamResponses,
                v -> { prefs.streamResponses = v; storage.savePrefs(prefs); });

        bindToggle(R.id.toggle_codehl, R.id.knob_codehl, prefs.codeHighlighting,
                v -> { prefs.codeHighlighting = v; storage.savePrefs(prefs); });

        bindToggle(R.id.toggle_linenumbers, R.id.knob_linenumbers, prefs.showLineNumbers,
                v -> { prefs.showLineNumbers = v; storage.savePrefs(prefs); });

        bindToggle(R.id.toggle_haptics, R.id.knob_haptics, prefs.hapticFeedback,
                v -> { prefs.hapticFeedback = v; storage.savePrefs(prefs); });
    }

    private interface ToggleListener { void onChange(boolean value); }

    private void bindToggle(int trackId, int knobId, boolean initial, ToggleListener listener) {
        FrameLayout track = findViewById(trackId);
        View knob = findViewById(knobId);
        setToggleVisual(track, knob, initial);

        final boolean[] state = { initial };
        track.setOnClickListener(v -> {
            state[0] = !state[0];
            setToggleVisual(track, knob, state[0]);
            if (prefs.hapticFeedback) {
                v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
            }
            listener.onChange(state[0]);
        });
    }

    private void setToggleVisual(FrameLayout track, View knob, boolean on) {
        track.setBackgroundResource(on ? R.drawable.bg_toggle_on : R.drawable.bg_toggle_off);
        knob.setBackgroundResource(on ? R.drawable.oval_toggle_knob_on : R.drawable.oval_toggle_knob_off);
        float knobTravelDp = 19f; // 46dp track - 21dp knob - 2*3dp margin
        float density = getResources().getDisplayMetrics().density;
        knob.setTranslationX(on ? knobTravelDp * density : 0f);
    }

    // ---------------- API & Data ----------------

    private void bindApiAndDataRows() {
        findViewById(R.id.row_api_profiles).setOnClickListener(v ->
                startActivity(new Intent(this, ProfilesActivity.class)));

        findViewById(R.id.row_export_chats).setOnClickListener(v -> exportAllChats());

        findViewById(R.id.row_import_data).setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("application/json");
            startActivityForResult(Intent.createChooser(intent, "Import CodeMate AI backup"), REQ_IMPORT);
        });

        findViewById(R.id.row_clear_cache).setOnClickListener(v -> {
            deleteRecursive(getCacheDir());
            updateCacheSizeLabel();
            Toast.makeText(this, "Cache cleared", Toast.LENGTH_SHORT).show();
        });
    }

    private void updateCacheSizeLabel() {
        long bytes = dirSize(getCacheDir());
        TextView label = findViewById(R.id.text_cache_size);
        label.setText(String.format("%.1f MB", bytes / (1024.0 * 1024.0)));
    }

    private long dirSize(File dir) {
        if (dir == null || !dir.exists()) return 0;
        long total = 0;
        File[] files = dir.listFiles();
        if (files == null) return 0;
        for (File f : files) {
            total += f.isDirectory() ? dirSize(f) : f.length();
        }
        return total;
    }

    private void deleteRecursive(File dir) {
        if (dir == null || !dir.exists()) return;
        File[] files = dir.listFiles();
        if (files != null) {
            for (File f : files) {
                if (f.isDirectory()) deleteRecursive(f);
                else f.delete();
            }
        }
    }

    private void exportAllChats() {
        List<ChatSession> chats = storage.loadChats();
        List<ApiProfile> profiles = storage.loadProfiles();
        if (chats.isEmpty() && profiles.isEmpty()) {
            Toast.makeText(this, "Nothing to export yet", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            Map<String, Object> backup = new HashMap<>();
            backup.put("chats", chats);
            backup.put("profiles", profiles);

            File exportDir = new File(getCacheDir(), "exports");
            if (!exportDir.exists()) exportDir.mkdirs();
            File outFile = new File(exportDir, "codemate_backup.json");
            try (FileOutputStream fos = new FileOutputStream(outFile)) {
                fos.write(gson.toJson(backup).getBytes(StandardCharsets.UTF_8));
            }

            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", outFile);
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("application/json");
            shareIntent.putExtra(Intent.EXTRA_STREAM, uri);
            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(shareIntent, "Save or share backup"));
        } catch (Exception e) {
            Toast.makeText(this, "Export failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_IMPORT && resultCode == RESULT_OK && data != null && data.getData() != null) {
            importBackup(data.getData());
        }
    }

    @SuppressWarnings("unchecked")
    private void importBackup(Uri uri) {
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) throw new IllegalStateException("Could not open file");
            byte[] bytes = readAll(in);
            String json = new String(bytes, StandardCharsets.UTF_8);

            Type mapType = new TypeToken<Map<String, Object>>() {}.getType();
            Map<String, Object> backup = gson.fromJson(json, mapType);
            if (backup == null) throw new IllegalStateException("File is not a valid backup");

            int importedChats = 0;
            int importedProfiles = 0;

            if (backup.containsKey("chats")) {
                Type chatListType = new TypeToken<List<ChatSession>>() {}.getType();
                List<ChatSession> importedChatList = gson.fromJson(gson.toJson(backup.get("chats")), chatListType);
                if (importedChatList != null) {
                    List<ChatSession> existing = storage.loadChats();
                    existing.addAll(importedChatList);
                    storage.saveChats(existing);
                    importedChats = importedChatList.size();
                }
            }

            if (backup.containsKey("profiles")) {
                Type profileListType = new TypeToken<List<ApiProfile>>() {}.getType();
                List<ApiProfile> importedProfileList = gson.fromJson(gson.toJson(backup.get("profiles")), profileListType);
                if (importedProfileList != null) {
                    List<ApiProfile> existing = storage.loadProfiles();
                    existing.addAll(importedProfileList);
                    storage.saveProfiles(existing);
                    importedProfiles = importedProfileList.size();
                }
            }

            Toast.makeText(this, "Imported " + importedChats + " chat(s), " + importedProfiles + " profile(s)",
                    Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Import failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private byte[] readAll(InputStream in) throws Exception {
        java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream();
        byte[] chunk = new byte[8192];
        int n;
        while ((n = in.read(chunk)) != -1) {
            buffer.write(chunk, 0, n);
        }
        return buffer.toByteArray();
    }
}
