package com.malayalam.cinema;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.view.Gravity;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class SplashActivity extends Activity {
  int dp(float n){ return (int)(n*getResources().getDisplayMetrics().density+.5f); }
  @Override public void onCreate(Bundle b){ super.onCreate(b);
    getWindow().setStatusBarColor(Color.rgb(14,14,18)); getWindow().setNavigationBarColor(Color.rgb(14,14,18));
    LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER); root.setBackgroundColor(Color.rgb(14,14,18));
    ImageView logo=new ImageView(this); logo.setImageResource(R.drawable.app_logo); logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE); root.addView(logo,new LinearLayout.LayoutParams(dp(120),dp(120)));
    TextView title=new TextView(this); title.setText("CHITHRAM"); title.setTextColor(Color.WHITE); title.setTextSize(30); title.setGravity(Gravity.CENTER); title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); root.addView(title,new LinearLayout.LayoutParams(-1,dp(48)));
    TextView sub=new TextView(this); sub.setText("MALAYALAM CINEMA ARCHIVE"); sub.setTextColor(Color.rgb(232,184,109)); sub.setTextSize(11); sub.setGravity(Gravity.CENTER); root.addView(sub,new LinearLayout.LayoutParams(-1,dp(28)));
    TextView load=new TextView(this); load.setText("Every film. Every year. One archive."); load.setTextColor(Color.rgb(150,150,158)); load.setTextSize(12); load.setGravity(Gravity.CENTER); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(42));lp.topMargin=dp(18);root.addView(load,lp);
    setContentView(root);
    logo.setAlpha(0f); logo.setScaleX(.72f); logo.setScaleY(.72f); title.setAlpha(0f); sub.setAlpha(0f); load.setAlpha(0f);
    logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(650).setInterpolator(new AccelerateDecelerateInterpolator()).start();
    title.animate().alpha(1f).setStartDelay(420).setDuration(500).start();
    sub.animate().alpha(1f).setStartDelay(650).setDuration(450).start();
    load.animate().alpha(1f).setStartDelay(900).setDuration(400).start();
    new android.os.Handler().postDelayed(()->{startActivity(new Intent(this,MainActivity.class));finish();overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);},1800);
  }
}
