#!/usr/bin/env python3
import json, re, sys, time
from pathlib import Path
import requests
from bs4 import BeautifulSoup

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'app'/'src'/'main'/'assets'/'movies.json'
START=1928
END=2026
UA='Mozilla/5.0 (X11; Linux x86_64) Chithram-Full-Database/14'

def norm(t):
    return re.sub(r'[^a-z0-9]+',' ',t.lower()).strip()

def main():
    existing=[]
    if OUT.exists():
        try: existing=json.loads(OUT.read_text(encoding='utf-8'))
        except Exception: existing=[]
    movies={}
    for m in existing:
        if m.get('title') and m.get('year'):
            movies[(norm(m['title']),int(m['year']))]=m
    session=requests.Session(); session.headers.update({'User-Agent':UA})
    for year in range(START,END+1):
        url=f'https://www.malayalachalachithram.com/movieslist.php?y={year}&ln=en'
        try:
            r=session.get(url,timeout=25); r.raise_for_status()
            soup=BeautifulSoup(r.text,'html.parser')
            found=0
            for a in soup.select('a[href*="movie.php"]'):
                title=' '.join(a.get_text(' ',strip=True).split())
                href=a.get('href','')
                if not title or len(title)>180 or 'movie.php' not in href: continue
                key=(norm(title),year)
                if key not in movies:
                    movies[key]={'title':title,'year':year,'genre':'Unknown','director':'Unknown','synopsis':'','poster':'','screenplay':'','releaseDate':'','source':'MalayalaChalachithram'}
                    found+=1
            print(f'{year}: +{found}  total={len(movies)}',flush=True)
        except Exception as e:
            print(f'{year}: skipped ({e})',file=sys.stderr,flush=True)
    data=sorted(movies.values(),key=lambda m:(-int(m.get('year',0)),m.get('title','').lower()))
    OUT.write_text(json.dumps(data,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
    print(f'Wrote {len(data)} released-candidate movie records to {OUT}')

if __name__=='__main__': main()
