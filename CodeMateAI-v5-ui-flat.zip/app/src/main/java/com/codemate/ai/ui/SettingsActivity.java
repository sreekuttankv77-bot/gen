package com.codemate.ai.ui;

import android.os.Bundle;
import android.text.format.Formatter;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.codemate.ai.CodeMateApp;
import com.codemate.ai.R;
import com.codemate.ai.data.AppStorage;
import com.google.android.material.switchmaterial.SwitchMaterial;

import java.io.File;

public class SettingsActivity extends AppCompatActivity {

    private AppStorage storage;
    private AppStorage.Prefs prefs;

    private TextView languageValue;
    private TextView cacheSizeLabel;
    private SwitchMaterial switchNotifications;
    private SwitchMaterial switchAutoSave;
    private SwitchMaterial switchHighlighting;
    private SwitchMaterial switchLineNumbers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        storage = new AppStorage(this);
        prefs = storage.loadPrefs();

        findViewById(R.id.btn_back_settings).setOnClickListener(v -> finish());

        languageValue = findViewById(R.id.text_language_value);
        cacheSizeLabel = findViewById(R.id.text_cache_size);
        switchNotifications = findViewById(R.id.switch_notifications);
        switchAutoSave = findViewById(R.id.switch_autosave);
        switchHighlighting = findViewById(R.id.switch_highlighting);
        switchLineNumbers = findViewById(R.id.switch_line_numbers);

        switchNotifications.setChecked(prefs.notificationsEnabled());
        switchAutoSave.setChecked(prefs.autoSaveChats());
        switchHighlighting.setChecked(prefs.codeHighlighting());
        switchLineNumbers.setChecked(prefs.showLineNumbers());

        switchNotifications.setOnCheckedChangeListener((CompoundButton b, boolean checked) -> {
            prefs.notificationsEnabled = checked;
            savePrefs();
        });
        switchAutoSave.setOnCheckedChangeListener((CompoundButton b, boolean checked) -> {
            prefs.autoSaveChats = checked;
            savePrefs();
        });
        switchHighlighting.setOnCheckedChangeListener((CompoundButton b, boolean checked) -> {
            prefs.codeHighlighting = checked;
            savePrefs();
        });
        switchLineNumbers.setOnCheckedChangeListener((CompoundButton b, boolean checked) -> {
            prefs.showLineNumbers = checked;
            savePrefs();
        });

        findViewById(R.id.row_appearance).setOnClickListener(v -> showAppearanceDialog());
        findViewById(R.id.row_behavior).setOnClickListener(v -> showBehaviorDialog());
        findViewById(R.id.row_language).setOnClickListener(v -> showLanguageDialog());
        findViewById(R.id.row_clear_cache).setOnClickListener(v -> clearCache());
        findViewById(R.id.row_export_chats).setOnClickListener(v -> exportAllChats());
        findViewById(R.id.row_about).setOnClickListener(v -> showAboutDialog());

        updateCacheSizeLabel();
    }

    private void savePrefs() {
        storage.savePrefs(prefs);
    }

    // ---------------- Appearance ----------------

    private void showAppearanceDialog() {
        String current = prefs.themeMode == null ? "system" : prefs.themeMode;
        String[] labels = {"Light", "Dark", "System default"};
        String[] values = {"light", "dark", "system"};
        int checked = 2;
        for (int i = 0; i < values.length; i++) if (values[i].equals(current)) checked = i;

        new AlertDialog.Builder(this)
                .setTitle("Appearance")
                .setSingleChoiceItems(labels, checked, (dialog, which) -> {
                    prefs.themeMode = values[which];
                    savePrefs();
                    CodeMateApp.applyThemeMode(values[which]);
                    dialog.dismiss();
                    recreate();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ---------------- Behavior ----------------

    private void showBehaviorDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Behavior")
                .setMessage("Chat, copy, and other preferences live here. Auto-save, syntax highlighting, and line numbers can be toggled below in the Chat section.")
                .setPositiveButton("OK", null)
                .show();
    }

    // ---------------- Language ----------------

    private void showLanguageDialog() {
        String[] labels = {"System default"};
        new AlertDialog.Builder(this)
                .setTitle("Language")
                .setSingleChoiceItems(labels, 0, (dialog, which) -> {
                    languageValue.setText(labels[which]);
                    dialog.dismiss();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ---------------- Data & storage ----------------

    private void updateCacheSizeLabel() {
        long bytes = dirSize(getCacheDir());
        cacheSizeLabel.setText(Formatter.formatShortFileSize(this, bytes));
    }

    private long dirSize(File dir) {
        if (dir == null || !dir.exists()) return 0;
        long total = 0;
        File[] files = dir.listFiles();
        if (files == null) return 0;
        for (File f : files) {
            total += f.isDirectory() ? dirSize(f) : f.length();
        }
        return total;
    }

    private void deleteDirContents(File dir) {
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File f : files) {
            if (f.isDirectory()) {
                deleteDirContents(f);
            }
            f.delete();
        }
    }

    private void clearCache() {
        deleteDirContents(getCacheDir());
        updateCacheSizeLabel();
        Toast.makeText(this, "Cache cleared", Toast.LENGTH_SHORT).show();
    }

    private void exportAllChats() {
        Toast.makeText(this, "Open a chat and use its export icon to save or share it", Toast.LENGTH_LONG).show();
    }

    // ---------------- About ----------------

    private void showAboutDialog() {
        new AlertDialog.Builder(this)
                .setTitle("About CodeMate AI")
                .setMessage("CodeMate AI\nVersion 1.0.0\n\nA coding assistant chat client.")
                .setPositiveButton("OK", null)
                .show();
    }
}
