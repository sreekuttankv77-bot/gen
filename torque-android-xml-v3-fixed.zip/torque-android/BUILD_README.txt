Torque Android project

Build requirements:
- Java 17
- Gradle 8.10.2 (GitHub Actions workflow sets this up)

The project uses Android XML layouts and Java. The search field uses the
standard Android EditText attribute textColorHint for compatibility with AAPT.

Main package: com.torque.app
Application: Torque
