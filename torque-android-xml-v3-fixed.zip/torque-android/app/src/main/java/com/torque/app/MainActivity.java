package com.torque.app;

import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    FrameLayout container;
    int current;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        container = findViewById(R.id.screenContainer);
        findViewById(R.id.navHome).setOnClickListener(v -> show(R.layout.home));
        findViewById(R.id.navMap).setOnClickListener(v -> show(R.layout.map));
        findViewById(R.id.navSearch).setOnClickListener(v -> show(R.layout.search));
        findViewById(R.id.navGarage).setOnClickListener(v -> show(R.layout.home));
        show(R.layout.home);
    }
    void show(int layout) {
        container.removeAllViews();
        View v = getLayoutInflater().inflate(layout, container, false);
        container.addView(v);
        wire(v, layout);
        current = layout;
    }
    void wire(View v, int layout) {
        int id;
        id = getResources().getIdentifier("findButton", "id", getPackageName());
        View find = v.findViewById(id); if (find != null) find.setOnClickListener(x -> show(R.layout.nearby));
        id = getResources().getIdentifier("shop1", "id", getPackageName());
        View shop = v.findViewById(id); if (shop != null) shop.setOnClickListener(x -> show(R.layout.detail));
        id = getResources().getIdentifier("mapShop", "id", getPackageName());
        View mapShop = v.findViewById(id); if (mapShop != null) mapShop.setOnClickListener(x -> show(R.layout.detail));
        id = getResources().getIdentifier("directions", "id", getPackageName());
        View dir = v.findViewById(id); if (dir != null) dir.setOnClickListener(x -> show(R.layout.navigate));
    }
    @Override public void onBackPressed() {
        if (current != R.layout.home) show(R.layout.home); else super.onBackPressed();
    }
}
