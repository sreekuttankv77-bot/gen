@echo off
setlocal
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
echo Gradle wrapper is configured for GitHub Actions. Please run this project on an environment with Gradle installed.
exit /b 1
