package com.malayalam.cinema;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.Holder> {
    interface OnWishChanged { void changed(); }
    private final Context c; private final List<MainActivity.Movie> data;
    private final SharedPreferences prefs; private final OnWishChanged cb;

    MovieAdapter(Context c,List<MainActivity.Movie> d,SharedPreferences p,OnWishChanged cb){
        this.c=c;data=d;prefs=p;this.cb=cb;
    }
    @Override public Holder onCreateViewHolder(ViewGroup parent,int viewType){
        LinearLayout card=new LinearLayout(c); card.setOrientation(LinearLayout.HORIZONTAL);
        card.setPadding(dp(12),dp(12),dp(12),dp(12)); card.setBackgroundResource(R.drawable.bg_card);
        RecyclerView.LayoutParams cp=new RecyclerView.LayoutParams(-1,dp(142)); cp.setMargins(0,0,0,dp(12)); card.setLayoutParams(cp);

        TextView poster=new TextView(c); poster.setGravity(Gravity.CENTER); poster.setTextColor(Color.WHITE);
        poster.setTextSize(13); poster.setTypeface(null,1); poster.setBackgroundResource(R.drawable.bg_poster);
        card.addView(poster,new LinearLayout.LayoutParams(dp(82),-1));

        LinearLayout info=new LinearLayout(c); info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(14),0,0,0);
        card.addView(info,new LinearLayout.LayoutParams(0,-1,1));

        LinearLayout top=new LinearLayout(c); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=new TextView(c); title.setTextSize(18); title.setTextColor(Color.rgb(16,17,20)); title.setTypeface(null,1);
        top.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        TextView heart=new TextView(c); heart.setTextSize(22); heart.setGravity(Gravity.CENTER);
        top.addView(heart,new LinearLayout.LayoutParams(dp(40),dp(40)));
        info.addView(top);

        TextView meta=new TextView(c); meta.setTextSize(13); meta.setTextColor(Color.rgb(112,115,122)); info.addView(meta);
        TextView desc=new TextView(c); desc.setTextSize(13); desc.setTextColor(Color.rgb(70,72,78)); desc.setMaxLines(2); desc.setPadding(0,dp(7),0,0); info.addView(desc);

        return new Holder(card,poster,title,heart,meta,desc);
    }
    @Override public void onBindViewHolder(Holder h,int pos){
        MainActivity.Movie m=data.get(pos);
        h.poster.setText(String.valueOf(m.year));
        h.title.setText(m.title);
        h.meta.setText(m.year+"  •  "+m.genre+"  •  "+m.director);
        h.desc.setText(m.synopsis);
        h.heart.setText(prefs.getBoolean(m.key(),false) ? "♥" : "♡");
        h.heart.setOnClickListener(v->{boolean now=!prefs.getBoolean(m.key(),false);prefs.edit().putBoolean(m.key(),now).apply();h.heart.setText(now?"♥":"♡");cb.changed();});
    }
    @Override public int getItemCount(){return data.size();}
    static class Holder extends RecyclerView.ViewHolder{
        TextView poster,title,heart,meta,desc;
        Holder(View v,TextView p,TextView t,TextView h,TextView m,TextView d){super(v);poster=p;title=t;heart=h;meta=m;desc=d;}
    }
    private int dp(int n){return Math.round(n*c.getResources().getDisplayMetrics().density);}
}
