package com.malayalam.cinema;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class MainActivity extends android.app.Activity {
    private final List<Movie> all = new ArrayList<>();
    private final List<Movie> filtered = new ArrayList<>();
    private MovieAdapter adapter;
    private String activeFilter = "All";
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("wishlist", MODE_PRIVATE);
        loadMovies();
        setup();
    }

    private void loadMovies() {
        try {
            InputStream in = getAssets().open("movies.json");
            byte[] data = new byte[in.available()];
            in.read(data); in.close();
            JSONArray arr = new JSONArray(new String(data, StandardCharsets.UTF_8));
            for (int i=0;i<arr.length();i++) {
                JSONObject o=arr.getJSONObject(i);
                all.add(new Movie(o.optString("title"), o.optInt("year"), o.optString("genre"),
                        o.optString("director"), o.optString("synopsis")));
            }
        } catch(Exception ignored) {}
        filtered.addAll(all);
    }

    private void setup() {
        RecyclerView list=findViewById(R.id.list);
        list.setLayoutManager(new LinearLayoutManager(this));
        adapter=new MovieAdapter(this, filtered, prefs, this::refreshWishlist);
        list.setAdapter(adapter);

        LinearLayout chips=findViewById(R.id.chips);
        String[] filters={"All","Drama","Comedy","Thriller","Romance","Action","Crime","Family"};
        for(String f:filters) {
            TextView chip=new TextView(this);
            chip.setText(f); chip.setTextSize(14); chip.setGravity(Gravity.CENTER);
            chip.setTextColor(Color.BLACK); chip.setBackgroundResource(R.drawable.bg_chip);
            chip.setSelected(f.equals("All"));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, dp(38));
            lp.setMargins(0,0,dp(8),0); chip.setLayoutParams(lp);
            chip.setOnClickListener(v -> {
                activeFilter=f;
                for(int i=0;i<chips.getChildCount();i++) chips.getChildAt(i).setSelected(false);
                v.setSelected(true); apply();
            });
            chips.addView(chip);
        }
        EditText search=findViewById(R.id.search);
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){ apply(); }
            public void afterTextChanged(Editable e){}
        });
        refreshWishlist();
    }

    private void apply() {
        EditText s=findViewById(R.id.search);
        String q=s.getText().toString().trim().toLowerCase(Locale.ROOT);
        filtered.clear();
        for(Movie m:all) {
            boolean filter=activeFilter.equals("All") || m.genre.toLowerCase(Locale.ROOT).contains(activeFilter.toLowerCase(Locale.ROOT));
            boolean query=q.isEmpty() || m.title.toLowerCase(Locale.ROOT).contains(q)
                    || m.director.toLowerCase(Locale.ROOT).contains(q)
                    || m.genre.toLowerCase(Locale.ROOT).contains(q);
            if(filter && query) filtered.add(m);
        }
        adapter.notifyDataSetChanged();
        ((TextView)findViewById(R.id.resultCount)).setText(String.valueOf(filtered.size()));
    }

    private void refreshWishlist() {
        int count=0;
        for(Movie m:all) if(prefs.getBoolean(m.key(),false)) count++;
        ((TextView)findViewById(R.id.wishlistCount)).setText("♡ "+count);
        ((TextView)findViewById(R.id.resultCount)).setText(String.valueOf(filtered.size()));
    }

    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}

    public static class Movie {
        final String title,genre,director,synopsis; final int year;
        Movie(String t,int y,String g,String d,String s){title=t;year=y;genre=g;director=d;synopsis=s;}
        String key(){return title.replaceAll("[^A-Za-z0-9]","_")+"_"+year;}
    }
}
