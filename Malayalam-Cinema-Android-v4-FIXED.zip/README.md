# Malayalam Cinema

Android offline Malayalam cinema catalogue prototype.

## Build
The GitHub Actions workflow installs Java 17 and Gradle 8.10.2, then builds the debug APK.

## Fixed in v4
- Added the missing AndroidX RecyclerView dependency.
- Kept the Android project at the ZIP root.
- Gradle launcher uses the Gradle installed by GitHub Actions.
