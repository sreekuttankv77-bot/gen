package com.codemate.ai.net;

import android.os.Handler;
import android.os.Looper;

import com.codemate.ai.data.ApiProfile;
import com.codemate.ai.data.ChatMessage;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.sse.EventSource;
import okhttp3.sse.EventSourceListener;
import okhttp3.sse.EventSources;

/**
 * Talks to any OpenAI-compatible /chat/completions endpoint (OpenAI, OpenRouter,
 * local servers like LM Studio / Ollama's OpenAI shim, Groq, Together, etc.)
 * and streams the response token-by-token via Server-Sent Events.
 */
public class OpenAiClient {

    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    private final OkHttpClient http;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private EventSource activeSource;

    public interface StreamListener {
        void onToken(String delta);
        void onComplete(String fullText);
        void onError(String message);
    }

    public OpenAiClient() {
        http = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(0, TimeUnit.MILLISECONDS) // streaming: no read timeout
                .writeTimeout(30, TimeUnit.SECONDS)
                .build();
    }

    private String resolveEndpoint(String baseUrl) {
        String url = baseUrl == null ? "" : baseUrl.trim();
        if (url.endsWith("/")) url = url.substring(0, url.length() - 1);
        if (url.endsWith("/chat/completions")) return url;
        return url + "/chat/completions";
    }

    public void streamChat(ApiProfile profile, List<ChatMessage> history, StreamListener listener) {
        String endpoint = resolveEndpoint(profile.baseUrl);

        JsonObject body = new JsonObject();
        body.addProperty("model", profile.model);
        body.addProperty("stream", true);
        body.addProperty("temperature", profile.temperature);

        JsonArray messages = new JsonArray();
        for (ChatMessage m : history) {
            JsonObject jm = new JsonObject();
            jm.addProperty("role", m.role);
            jm.addProperty("content", m.content);
            messages.add(jm);
        }
        body.add("messages", messages);

        Request.Builder reqBuilder = new Request.Builder()
                .url(endpoint)
                .post(RequestBody.create(new Gson().toJson(body), JSON));

        if (profile.apiKey != null && !profile.apiKey.trim().isEmpty()) {
            reqBuilder.addHeader("Authorization", "Bearer " + profile.apiKey.trim());
        }
        reqBuilder.addHeader("Content-Type", "application/json");

        Request request = reqBuilder.build();

        StringBuilder full = new StringBuilder();
        AtomicBoolean finished = new AtomicBoolean(false);

        activeSource = EventSources.createFactory(http).newEventSource(request, new EventSourceListener() {
            @Override
            public void onOpen(EventSource eventSource, Response response) {
                // connected
            }

            @Override
            public void onEvent(EventSource eventSource, String id, String type, String data) {
                if (data == null) return;
                if ("[DONE]".equals(data.trim())) {
                    if (finished.compareAndSet(false, true)) postComplete(listener, full.toString());
                    return;
                }
                try {
                    JsonObject obj = JsonParser.parseString(data).getAsJsonObject();
                    if (obj.has("error")) {
                        String msg = obj.get("error").isJsonObject()
                                ? obj.getAsJsonObject("error").get("message").getAsString()
                                : obj.get("error").toString();
                        if (finished.compareAndSet(false, true)) postError(listener, msg);
                        return;
                    }
                    JsonArray choices = obj.getAsJsonArray("choices");
                    if (choices != null && choices.size() > 0) {
                        JsonObject choice = choices.get(0).getAsJsonObject();
                        JsonObject delta = choice.has("delta") ? choice.getAsJsonObject("delta") : null;
                        String piece = null;
                        if (delta != null && delta.has("content") && !delta.get("content").isJsonNull()) {
                            piece = delta.get("content").getAsString();
                        } else if (choice.has("message")) {
                            // non-streaming-style fallback within a stream chunk
                            JsonObject msg = choice.getAsJsonObject("message");
                            if (msg.has("content") && !msg.get("content").isJsonNull()) {
                                piece = msg.get("content").getAsString();
                            }
                        }
                        if (piece != null && !piece.isEmpty()) {
                            full.append(piece);
                            postToken(listener, piece);
                        }
                        if (choice.has("finish_reason") && !choice.get("finish_reason").isJsonNull()) {
                            String reason = choice.get("finish_reason").getAsString();
                            if (reason != null && !reason.isEmpty()) {
                                if (finished.compareAndSet(false, true)) postComplete(listener, full.toString());
                            }
                        }
                    }
                } catch (Exception e) {
                    // Ignore malformed chunk lines, keep streaming
                }
            }

            @Override
            public void onClosed(EventSource eventSource) {
                if (finished.compareAndSet(false, true)) postComplete(listener, full.toString());
            }

            @Override
            public void onFailure(EventSource eventSource, Throwable t, Response response) {
                String msg;
                try {
                    if (response != null && response.body() != null) {
                        String errBody = response.body().string();
                        msg = "HTTP " + response.code() + ": " + errBody;
                    } else if (t != null) {
                        msg = t.getMessage() != null ? t.getMessage() : t.toString();
                    } else {
                        msg = "Unknown network error";
                    }
                } catch (Exception e) {
                    msg = "Request failed";
                }
                if (finished.compareAndSet(false, true)) postError(listener, msg);
            }
        });
    }

    public void cancel() {
        if (activeSource != null) {
            activeSource.cancel();
            activeSource = null;
        }
    }

    private void postToken(StreamListener listener, String token) {
        mainHandler.post(() -> listener.onToken(token));
    }

    private void postComplete(StreamListener listener, String full) {
        mainHandler.post(() -> listener.onComplete(full));
    }

    private void postError(StreamListener listener, String message) {
        mainHandler.post(() -> listener.onError(message));
    }
}
