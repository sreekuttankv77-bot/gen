package com.codemate.ai.ui;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.codemate.ai.R;
import com.codemate.ai.data.ApiProfile;
import com.codemate.ai.data.AppStorage;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class ProfilesActivity extends AppCompatActivity {

    private AppStorage storage;
    private List<ApiProfile> profiles;
    private RecyclerView recyclerView;
    private ProfileAdapter adapter;
    private TextView emptyView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profiles);
        storage = new AppStorage(this);
        profiles = storage.loadProfiles();

        recyclerView = findViewById(R.id.recycler_profiles);
        emptyView = findViewById(R.id.text_empty_profiles);
        FloatingActionButton fabAdd = findViewById(R.id.fab_add_profile);
        View backBtn = findViewById(R.id.btn_back_profiles);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ProfileAdapter();
        recyclerView.setAdapter(adapter);
        refreshEmpty();

        fabAdd.setOnClickListener(v -> showEditDialog(null));
        backBtn.setOnClickListener(v -> finish());
    }

    private void refreshEmpty() {
        boolean empty = profiles.isEmpty();
        emptyView.setVisibility(empty ? View.VISIBLE : View.GONE);
        recyclerView.setVisibility(empty ? View.GONE : View.VISIBLE);
    }

    private void showEditDialog(ApiProfile existing) {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_edit_profile, null);
        EditText nameField = view.findViewById(R.id.field_name);
        EditText urlField = view.findViewById(R.id.field_url);
        EditText keyField = view.findViewById(R.id.field_key);
        EditText modelField = view.findViewById(R.id.field_model);

        if (existing != null) {
            nameField.setText(existing.name);
            urlField.setText(existing.baseUrl);
            keyField.setText(existing.apiKey);
            modelField.setText(existing.model);
        } else {
            urlField.setText("https://api.openai.com/v1");
        }

        new AlertDialog.Builder(this, R.style.AppTheme_Dialog)
                .setTitle(existing == null ? "Add API profile" : "Edit profile")
                .setView(view)
                .setPositiveButton("Save", (dialog, which) -> {
                    String name = nameField.getText().toString().trim();
                    String url = urlField.getText().toString().trim();
                    String key = keyField.getText().toString().trim();
                    String model = modelField.getText().toString().trim();

                    if (TextUtils.isEmpty(name) || TextUtils.isEmpty(url) || TextUtils.isEmpty(model)) {
                        Toast.makeText(this, "Name, base URL, and model are required", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (existing != null) {
                        existing.name = name;
                        existing.baseUrl = url;
                        existing.apiKey = key;
                        existing.model = model;
                    } else {
                        profiles.add(new ApiProfile(name, url, key, model));
                    }
                    storage.saveProfiles(profiles);
                    adapter.notifyDataSetChanged();
                    refreshEmpty();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void deleteProfile(ApiProfile p) {
        new AlertDialog.Builder(this)
                .setTitle("Delete \"" + p.name + "\"?")
                .setMessage("Chats using this profile will keep their history but stop working until you assign a different profile.")
                .setPositiveButton("Delete", (d, w) -> {
                    profiles.remove(p);
                    storage.saveProfiles(profiles);
                    adapter.notifyDataSetChanged();
                    refreshEmpty();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    class ProfileAdapter extends RecyclerView.Adapter<ProfileAdapter.VH> {
        @androidx.annotation.NonNull
        @Override
        public VH onCreateViewHolder(@androidx.annotation.NonNull android.view.ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_profile, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(@androidx.annotation.NonNull VH holder, int position) {
            ApiProfile p = profiles.get(position);
            holder.name.setText(p.name);
            holder.details.setText(p.model + "  ·  " + p.baseUrl);
            holder.itemView.setOnClickListener(v -> showEditDialog(p));
            holder.delete.setOnClickListener(v -> deleteProfile(p));
        }

        @Override
        public int getItemCount() {
            return profiles.size();
        }

        class VH extends RecyclerView.ViewHolder {
            TextView name, details;
            ImageView delete;

            VH(View itemView) {
                super(itemView);
                name = itemView.findViewById(R.id.text_profile_name);
                details = itemView.findViewById(R.id.text_profile_details);
                delete = itemView.findViewById(R.id.btn_delete_profile);
            }
        }
    }
}
