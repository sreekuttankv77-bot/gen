package com.codemate.ai.ui;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.codemate.ai.R;
import com.codemate.ai.data.ApiProfile;
import com.codemate.ai.data.AppStorage;
import com.codemate.ai.data.ChatMessage;
import com.codemate.ai.data.ChatSession;
import com.codemate.ai.net.OpenAiClient;
import com.codemate.ai.ui.adapter.MessageAdapter;

import io.noties.markwon.Markwon;
import io.noties.markwon.ext.strikethrough.StrikethroughPlugin;
import io.noties.markwon.ext.tables.TablePlugin;
import io.noties.markwon.linkify.LinkifyPlugin;

import java.util.ArrayList;
import java.util.List;

public class ChatActivity extends AppCompatActivity {

    private AppStorage storage;
    private OpenAiClient client;
    private ChatSession session;
    private ApiProfile profile;
    private List<ChatSession> allChats;

    private RecyclerView recyclerView;
    private MessageAdapter adapter;
    private EditText input;
    private ImageButton sendBtn;
    private TextView profileLabel;
    private View typingIndicator;

    private boolean isStreaming = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        storage = new AppStorage(this);
        client = new OpenAiClient();

        String chatId = getIntent().getStringExtra("chat_id");
        allChats = storage.loadChats();
        for (ChatSession c : allChats) {
            if (c.id.equals(chatId)) {
                session = c;
                break;
            }
        }
        if (session == null) {
            Toast.makeText(this, "Chat not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        List<ApiProfile> profiles = storage.loadProfiles();
        for (ApiProfile p : profiles) {
            if (p.id.equals(session.profileId)) {
                profile = p;
                break;
            }
        }
        if (profile == null && !profiles.isEmpty()) {
            profile = profiles.get(0);
            session.profileId = profile.id;
        }

        recyclerView = findViewById(R.id.recycler_messages);
        input = findViewById(R.id.edit_input);
        sendBtn = findViewById(R.id.btn_send);
        profileLabel = findViewById(R.id.text_profile_label);
        typingIndicator = findViewById(R.id.typing_indicator);
        View backBtn = findViewById(R.id.btn_back);

        Markwon markwon = Markwon.builder(this)
                .usePlugin(StrikethroughPlugin.create())
                .usePlugin(TablePlugin.create(this))
                .usePlugin(LinkifyPlugin.create())
                .build();

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new MessageAdapter(session.messages, markwon);
        recyclerView.setAdapter(adapter);
        scrollToBottom();

        profileLabel.setText(profile != null ? (profile.name + " · " + profile.model) : "No profile — tap to add");
        profileLabel.setOnClickListener(v -> pickProfile(profiles));

        backBtn.setOnClickListener(v -> finish());
        sendBtn.setOnClickListener(v -> onSendClicked());
    }

    private void pickProfile(List<ApiProfile> profiles) {
        if (profiles.isEmpty()) {
            Toast.makeText(this, "No profiles yet — add one in Settings", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] names = new String[profiles.size()];
        for (int i = 0; i < profiles.size(); i++) names[i] = profiles.get(i).name + " (" + profiles.get(i).model + ")";
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Switch profile")
                .setItems(names, (dialog, which) -> {
                    profile = profiles.get(which);
                    session.profileId = profile.id;
                    profileLabel.setText(profile.name + " · " + profile.model);
                    AppStorage.Prefs prefs = storage.loadPrefs();
                    prefs.lastProfileId = profile.id;
                    storage.savePrefs(prefs);
                    persistSession();
                })
                .show();
    }

    private void onSendClicked() {
        if (isStreaming) {
            client.cancel();
            setStreaming(false);
            return;
        }
        String text = input.getText().toString().trim();
        if (TextUtils.isEmpty(text)) return;
        if (profile == null) {
            Toast.makeText(this, "Add an API profile first", Toast.LENGTH_LONG).show();
            return;
        }

        ChatMessage userMsg = new ChatMessage(ChatMessage.ROLE_USER, text);
        session.messages.add(userMsg);
        adapter.notifyItemInserted(session.messages.size() - 1);
        input.setText("");
        scrollToBottom();

        if (session.title == null || "New Chat".equals(session.title)) {
            session.title = text.length() > 40 ? text.substring(0, 40) + "…" : text;
        }
        session.updatedAt = System.currentTimeMillis();
        persistSession();

        // Placeholder assistant message that we fill in as tokens arrive
        ChatMessage assistantMsg = new ChatMessage(ChatMessage.ROLE_ASSISTANT, "");
        session.messages.add(assistantMsg);
        int assistantIndex = session.messages.size() - 1;
        adapter.notifyItemInserted(assistantIndex);
        scrollToBottom();

        setStreaming(true);

        List<ChatMessage> history = new ArrayList<>(session.messages.subList(0, assistantIndex));

        client.streamChat(profile, history, new OpenAiClient.StreamListener() {
            @Override
            public void onToken(String delta) {
                assistantMsg.content += delta;
                adapter.notifyItemChanged(assistantIndex);
                scrollToBottom();
            }

            @Override
            public void onComplete(String fullText) {
                if (assistantMsg.content.isEmpty() && !fullText.isEmpty()) {
                    assistantMsg.content = fullText;
                }
                setStreaming(false);
                session.updatedAt = System.currentTimeMillis();
                persistSession();
                adapter.notifyItemChanged(assistantIndex);
            }

            @Override
            public void onError(String message) {
                assistantMsg.isError = true;
                assistantMsg.content = message;
                adapter.notifyItemChanged(assistantIndex);
                setStreaming(false);
                persistSession();
            }
        });
    }

    private void setStreaming(boolean streaming) {
        isStreaming = streaming;
        typingIndicator.setVisibility(streaming ? View.VISIBLE : View.GONE);
        sendBtn.setImageResource(streaming ? R.drawable.ic_stop : R.drawable.ic_send);
    }

    private void persistSession() {
        for (int i = 0; i < allChats.size(); i++) {
            if (allChats.get(i).id.equals(session.id)) {
                allChats.set(i, session);
                storage.saveChats(allChats);
                return;
            }
        }
    }

    private void scrollToBottom() {
        recyclerView.post(() -> {
            if (adapter.getItemCount() > 0) {
                recyclerView.scrollToPosition(adapter.getItemCount() - 1);
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        client.cancel();
    }
}
