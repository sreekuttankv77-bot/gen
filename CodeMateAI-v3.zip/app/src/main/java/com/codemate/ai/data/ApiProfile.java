package com.codemate.ai.data;

import java.util.UUID;

public class ApiProfile {
    public String id;
    public String name;
    public String baseUrl;
    public String apiKey;
    public String model;
    public double temperature = 0.7;

    public ApiProfile() {
        this.id = UUID.randomUUID().toString();
    }

    public ApiProfile(String name, String baseUrl, String apiKey, String model) {
        this.id = UUID.randomUUID().toString();
        this.name = name;
        this.baseUrl = baseUrl;
        this.apiKey = apiKey;
        this.model = model;
    }
}
