package com.codemate.ai.ui.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.codemate.ai.R;
import com.codemate.ai.data.ChatMessage;
import io.noties.markwon.Markwon;

import java.util.List;

public class MessageAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int TYPE_USER = 1;
    private static final int TYPE_ASSISTANT = 2;

    private final List<ChatMessage> data;
    private final Markwon markwon;

    public MessageAdapter(List<ChatMessage> data, Markwon markwon) {
        this.data = data;
        this.markwon = markwon;
    }

    @Override
    public int getItemViewType(int position) {
        ChatMessage m = data.get(position);
        return ChatMessage.ROLE_USER.equals(m.role) ? TYPE_USER : TYPE_ASSISTANT;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        int layout = viewType == TYPE_USER ? R.layout.item_message_user : R.layout.item_message_assistant;
        View v = LayoutInflater.from(parent.getContext()).inflate(layout, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ChatMessage m = data.get(position);
        VH vh = (VH) holder;
        String content = m.content == null ? "" : m.content;
        if (m.isError) {
            vh.text.setText("⚠ " + content);
        } else if (getItemViewType(position) == TYPE_ASSISTANT) {
            markwon.setMarkdown(vh.text, content.isEmpty() ? "…" : content);
        } else {
            vh.text.setText(content);
        }
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView text;

        VH(View itemView) {
            super(itemView);
            text = itemView.findViewById(R.id.text_message);
        }
    }
}
