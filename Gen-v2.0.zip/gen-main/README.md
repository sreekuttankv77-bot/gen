# Gen 2.0

Gen is a clean Android roleplay/chat client with OpenAI-compatible API profiles.

## Gen 2.0 highlights
- Apple-inspired clean Compose UI
- Three-dot chat menu for Settings and quick selectors
- PNG character-card import (common Tavern/SillyTavern V1/V2 metadata)
- JSON character-card import
- ZIP character-pack import
- Saved character library with avatars
- Multiple user personas
- JSON-backed generation presets
- Regex scripts
- Long-term memory
- Image and animated GIF chat backgrounds
- Reroll the current/latest character response without adding the old response to context
- Version 2.0

## Build
Use the included Gradle wrapper:

```bash
./gradlew assembleDebug
```
