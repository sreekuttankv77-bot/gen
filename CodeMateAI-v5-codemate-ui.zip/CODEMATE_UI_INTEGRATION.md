# CodeMate AI UI integration

Updated the Android project to closely match the supplied CodeMate AI reference UI.

## Main changes
- Dark-first visual system with orange accent and subtle borders.
- Chat header redesigned with CodeMate AI logo/title, theme button, and overflow menu.
- Chat bubbles, input field, send button, and code background updated to the reference styling.
- Overflow menu restyled as a dark rounded panel.
- Settings redesigned as a rounded modal sheet with dimmed background.
- Settings cards, section labels, switches, icons, and spacing updated.
- Settings entry from the main screen now opens `SettingsActivity`.
- New chats and existing chat/API functionality were left intact.
- Default theme is now dark when no saved theme preference exists.

## Build note
The included `gradlew` script delegates to a system `gradle` executable, so this environment could not run a local Gradle build because Gradle is not installed here. The source changes were made directly against the supplied project.
