package com.codemate.ai.ui;

import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.TextUtils;
import android.util.Base64;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.codemate.ai.R;
import com.codemate.ai.data.ApiProfile;
import com.codemate.ai.data.AppStorage;
import com.codemate.ai.data.ChatMessage;
import com.codemate.ai.data.ChatSession;
import com.codemate.ai.net.OpenAiClient;
import com.codemate.ai.ui.adapter.MessageAdapter;

import io.noties.markwon.Markwon;
import io.noties.markwon.ext.strikethrough.StrikethroughPlugin;
import io.noties.markwon.ext.tables.TablePlugin;
import io.noties.markwon.linkify.LinkifyPlugin;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class ChatActivity extends AppCompatActivity {

    private static final long MAX_TEXT_ATTACHMENT_BYTES = 200 * 1024; // 200KB cap for text file attachments
    private static final long MAX_IMAGE_ATTACHMENT_BYTES = 6 * 1024 * 1024; // 6MB cap for image attachments

    private AppStorage storage;
    private OpenAiClient client;
    private ChatSession session;
    private ApiProfile profile;
    private List<ChatSession> allChats;

    private RecyclerView recyclerView;
    private MessageAdapter adapter;
    private EditText input;
    private ImageButton sendBtn;
    private ImageButton imageGenBtn;
    private TextView profileLabel;
    private View typingIndicator;
    private View pendingAttachmentRow;
    private TextView pendingAttachmentLabel;

    private boolean isStreaming = false;

    // Pending attachment (picked but not yet sent)
    private String pendingAttachmentName;
    private String pendingAttachmentMime;
    private String pendingAttachmentImageBase64;
    private String pendingAttachmentTextContent;

    private ActivityResultLauncher<String> filePickerLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        storage = new AppStorage(this);
        client = new OpenAiClient();

        String chatId = getIntent().getStringExtra("chat_id");
        allChats = storage.loadChats();
        for (ChatSession c : allChats) {
            if (c.id.equals(chatId)) {
                session = c;
                break;
            }
        }
        if (session == null) {
            Toast.makeText(this, "Chat not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        List<ApiProfile> profiles = storage.loadProfiles();
        for (ApiProfile p : profiles) {
            if (p.id.equals(session.profileId)) {
                profile = p;
                break;
            }
        }
        if (profile == null && !profiles.isEmpty()) {
            profile = profiles.get(0);
            session.profileId = profile.id;
        }

        recyclerView = findViewById(R.id.recycler_messages);
        input = findViewById(R.id.edit_input);
        sendBtn = findViewById(R.id.btn_send);
        imageGenBtn = findViewById(R.id.btn_image_gen);
        profileLabel = findViewById(R.id.text_profile_label);
        typingIndicator = findViewById(R.id.typing_indicator);
        pendingAttachmentRow = findViewById(R.id.row_pending_attachment);
        pendingAttachmentLabel = findViewById(R.id.text_pending_attachment);
        View backBtn = findViewById(R.id.btn_back);
        View attachBtn = findViewById(R.id.btn_attach);
        View exportBtn = findViewById(R.id.btn_export);
        View menuBtn = findViewById(R.id.btn_menu);
        View themeBtn = findViewById(R.id.btn_theme);
        ImageView removeAttachmentBtn = findViewById(R.id.btn_remove_attachment);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        setupMarkwonAndAdapter();
        scrollToBottom();

        updateProfileLabel();
        profileLabel.setOnClickListener(v -> pickProfile(profiles));

        backBtn.setOnClickListener(v -> finish());
        sendBtn.setOnClickListener(v -> onSendClicked());
        attachBtn.setOnClickListener(v -> filePickerLauncher.launch("*/*"));
        exportBtn.setOnClickListener(v -> exportChat());
        menuBtn.setOnClickListener(this::showChatMenu);
        themeBtn.setOnClickListener(v -> cycleTheme());
        removeAttachmentBtn.setOnClickListener(v -> clearPendingAttachment());
        imageGenBtn.setOnClickListener(v -> onImageGenClicked());

        filePickerLauncher = registerForActivityResult(new ActivityResultContracts.GetContent(), this::onFilePicked);
    }

    // ---------------- Settings-driven rendering ----------------

    private Boolean lastCodeHighlighting;
    private Boolean lastShowLineNumbers;

    private void setupMarkwonAndAdapter() {
        AppStorage.Prefs prefs = storage.loadPrefs();
        boolean highlight = prefs.codeHighlighting();
        boolean lineNumbers = prefs.showLineNumbers();
        lastCodeHighlighting = highlight;
        lastShowLineNumbers = lineNumbers;

        Markwon.Builder builder = Markwon.builder(this)
                .usePlugin(StrikethroughPlugin.create())
                .usePlugin(TablePlugin.create(this))
                .usePlugin(LinkifyPlugin.create());

        if (highlight) {
            builder.usePlugin(new io.noties.markwon.AbstractMarkwonPlugin() {
                @Override
                public void configureTheme(io.noties.markwon.core.MarkwonTheme.Builder builder) {
                    int codeBg = androidx.core.content.ContextCompat.getColor(ChatActivity.this, R.color.code_bg);
                    builder.codeBackgroundColor(codeBg).codeBlockBackgroundColor(codeBg);
                }
            });
        }

        Markwon markwon = builder.build();
        adapter = new MessageAdapter(session.messages, markwon, lineNumbers);
        recyclerView.setAdapter(adapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        AppStorage.Prefs prefs = storage.loadPrefs();
        boolean highlight = prefs.codeHighlighting();
        boolean lineNumbers = prefs.showLineNumbers();
        boolean changed = lastCodeHighlighting == null
                || !lastCodeHighlighting.equals(highlight)
                || !lastShowLineNumbers.equals(lineNumbers);
        if (changed) {
            setupMarkwonAndAdapter();
        }
    }

    // ---------------- Overflow menu ----------------

    private void showChatMenu(View anchor) {
        View popupView = LayoutInflater.from(this).inflate(R.layout.popup_chat_menu, null);
        PopupWindow popup = new PopupWindow(popupView,
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
                true);
        popup.setBackgroundDrawable(new ColorDrawable(0));
        popup.setElevation(12f);

        popupView.findViewById(R.id.menu_new_chat).setOnClickListener(v -> {
            popup.dismiss();
            startNewChatFromHere();
        });
        popupView.findViewById(R.id.menu_history).setOnClickListener(v -> {
            popup.dismiss();
            finish();
        });
        popupView.findViewById(R.id.menu_profiles).setOnClickListener(v -> {
            popup.dismiss();
            startActivity(new Intent(this, ProfilesActivity.class));
        });
        popupView.findViewById(R.id.menu_settings).setOnClickListener(v -> {
            popup.dismiss();
            startActivity(new Intent(this, SettingsActivity.class));
        });
        popupView.findViewById(R.id.menu_export).setOnClickListener(v -> {
            popup.dismiss();
            exportChat();
        });
        popupView.findViewById(R.id.menu_import).setOnClickListener(v -> {
            popup.dismiss();
            Toast.makeText(this, "Import Data — coming soon", Toast.LENGTH_SHORT).show();
        });
        popupView.findViewById(R.id.menu_clear).setOnClickListener(v -> {
            popup.dismiss();
            confirmClearChat();
        });

        popup.showAsDropDown(anchor, -180, 8, Gravity.TOP);
    }

    private void startNewChatFromHere() {
        List<ApiProfile> profiles = storage.loadProfiles();
        if (profiles.isEmpty()) {
            Toast.makeText(this, "Add an API profile first", Toast.LENGTH_LONG).show();
            startActivity(new Intent(this, ProfilesActivity.class));
            return;
        }
        ChatSession newSession = new ChatSession();
        newSession.profileId = profile != null ? profile.id : profiles.get(0).id;
        List<ChatSession> chats = storage.loadChats();
        chats.add(0, newSession);
        storage.saveChats(chats);

        Intent intent = new Intent(this, ChatActivity.class);
        intent.putExtra("chat_id", newSession.id);
        startActivity(intent);
        finish();
    }

    private void confirmClearChat() {
        if (session.messages.isEmpty()) {
            Toast.makeText(this, "Chat is already empty", Toast.LENGTH_SHORT).show();
            return;
        }
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Clear chat?")
                .setMessage("This deletes every message in this chat. This can't be undone.")
                .setPositiveButton("Clear", (dialog, which) -> {
                    session.messages.clear();
                    adapter.notifyDataSetChanged();
                    session.updatedAt = System.currentTimeMillis();
                    persistSession();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void updateProfileLabel() {
        profileLabel.setText(getString(R.string.app_name));
        imageGenBtn.setVisibility(profile != null && profile.supportsImageGen ? View.VISIBLE : View.GONE);
    }

    private void cycleTheme() {
        AppStorage.Prefs prefs = storage.loadPrefs();
        String current = prefs.themeMode == null ? "dark" : prefs.themeMode;
        String next = "dark".equals(current) ? "light" : "dark";
        prefs.themeMode = next;
        storage.savePrefs(prefs);
        com.codemate.ai.CodeMateApp.applyThemeMode(next);
        recreate();
    }

    private void pickProfile(List<ApiProfile> profiles) {
        if (profiles.isEmpty()) {
            Toast.makeText(this, "No profiles yet — add one in Settings", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] names = new String[profiles.size()];
        for (int i = 0; i < profiles.size(); i++) names[i] = profiles.get(i).name + " (" + profiles.get(i).model + ")";
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Switch profile")
                .setItems(names, (dialog, which) -> {
                    profile = profiles.get(which);
                    session.profileId = profile.id;
                    updateProfileLabel();
                    AppStorage.Prefs prefs = storage.loadPrefs();
                    prefs.lastProfileId = profile.id;
                    storage.savePrefs(prefs);
                    persistSession();
                })
                .show();
    }

    // ---------------- File attach ----------------

    private void onFilePicked(Uri uri) {
        if (uri == null) return;
        ContentResolver resolver = getContentResolver();
        String mime = resolver.getType(uri);
        String displayName = queryDisplayName(uri);

        try {
            long size = querySize(uri);
            if (mime != null && mime.startsWith("image/")) {
                if (size > MAX_IMAGE_ATTACHMENT_BYTES) {
                    Toast.makeText(this, "Image too large (max 6MB)", Toast.LENGTH_LONG).show();
                    return;
                }
                try (InputStream is = resolver.openInputStream(uri)) {
                    byte[] bytes = readAllBytes(is);
                    pendingAttachmentImageBase64 = Base64.encodeToString(bytes, Base64.NO_WRAP);
                    pendingAttachmentMime = mime;
                    pendingAttachmentTextContent = null;
                    pendingAttachmentName = displayName != null ? displayName : "image";
                    showPendingAttachment();
                }
            } else {
                if (size > MAX_TEXT_ATTACHMENT_BYTES) {
                    Toast.makeText(this, "File too large to attach as text (max 200KB)", Toast.LENGTH_LONG).show();
                    return;
                }
                try (InputStream is = resolver.openInputStream(uri)) {
                    byte[] bytes = readAllBytes(is);
                    String text = new String(bytes, StandardCharsets.UTF_8);
                    if (looksBinary(text)) {
                        Toast.makeText(this, "Only text, code, and image files can be attached", Toast.LENGTH_LONG).show();
                        return;
                    }
                    pendingAttachmentTextContent = text;
                    pendingAttachmentImageBase64 = null;
                    pendingAttachmentMime = mime;
                    pendingAttachmentName = displayName != null ? displayName : "file.txt";
                    showPendingAttachment();
                }
            }
        } catch (Exception e) {
            Toast.makeText(this, "Couldn't read file: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private boolean looksBinary(String text) {
        int sampleLen = Math.min(text.length(), 2000);
        int suspicious = 0;
        for (int i = 0; i < sampleLen; i++) {
            char c = text.charAt(i);
            if (c == 0) return true;
            if (c < 9 && c != 0) suspicious++;
        }
        return sampleLen > 0 && suspicious > sampleLen * 0.05;
    }

    private byte[] readAllBytes(InputStream is) throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = is.read(buf)) != -1) bos.write(buf, 0, n);
        return bos.toByteArray();
    }

    private String queryDisplayName(Uri uri) {
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) return cursor.getString(idx);
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private long querySize(Uri uri) {
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(OpenableColumns.SIZE);
                if (idx >= 0 && !cursor.isNull(idx)) return cursor.getLong(idx);
            }
        } catch (Exception ignored) {
        }
        return 0;
    }

    private void showPendingAttachment() {
        pendingAttachmentRow.setVisibility(View.VISIBLE);
        pendingAttachmentLabel.setText("📎 " + pendingAttachmentName);
    }

    private void clearPendingAttachment() {
        pendingAttachmentName = null;
        pendingAttachmentMime = null;
        pendingAttachmentImageBase64 = null;
        pendingAttachmentTextContent = null;
        pendingAttachmentRow.setVisibility(View.GONE);
    }

    // ---------------- Send / stream ----------------

    private void onSendClicked() {
        if (isStreaming) {
            client.cancel();
            setStreaming(false);
            return;
        }
        String text = input.getText().toString().trim();
        boolean hasAttachment = pendingAttachmentImageBase64 != null || pendingAttachmentTextContent != null;
        if (TextUtils.isEmpty(text) && !hasAttachment) return;
        if (profile == null) {
            Toast.makeText(this, "Add an API profile first", Toast.LENGTH_LONG).show();
            return;
        }

        ChatMessage userMsg = new ChatMessage(ChatMessage.ROLE_USER, text);
        if (hasAttachment) {
            userMsg.attachmentName = pendingAttachmentName;
            userMsg.attachmentMime = pendingAttachmentMime;
            userMsg.attachmentImageBase64 = pendingAttachmentImageBase64;
            userMsg.attachmentTextContent = pendingAttachmentTextContent;
        }
        session.messages.add(userMsg);
        adapter.notifyItemInserted(session.messages.size() - 1);
        input.setText("");
        clearPendingAttachment();
        scrollToBottom();

        if (session.title == null || "New Chat".equals(session.title)) {
            String t = !TextUtils.isEmpty(text) ? text : (userMsg.attachmentName != null ? userMsg.attachmentName : "New Chat");
            session.title = t.length() > 40 ? t.substring(0, 40) + "…" : t;
        }
        session.updatedAt = System.currentTimeMillis();
        persistSession();

        ChatMessage assistantMsg = new ChatMessage(ChatMessage.ROLE_ASSISTANT, "");
        session.messages.add(assistantMsg);
        int assistantIndex = session.messages.size() - 1;
        adapter.notifyItemInserted(assistantIndex);
        scrollToBottom();

        setStreaming(true);

        List<ChatMessage> history = new ArrayList<>(session.messages.subList(0, assistantIndex));

        client.streamChat(profile, history, new OpenAiClient.StreamListener() {
            @Override
            public void onToken(String delta) {
                assistantMsg.content += delta;
                adapter.notifyItemChanged(assistantIndex);
                scrollToBottom();
            }

            @Override
            public void onComplete(String fullText) {
                if (assistantMsg.content.isEmpty() && !fullText.isEmpty()) {
                    assistantMsg.content = fullText;
                }
                setStreaming(false);
                session.updatedAt = System.currentTimeMillis();
                persistSession();
                adapter.notifyItemChanged(assistantIndex);
            }

            @Override
            public void onError(String message) {
                assistantMsg.isError = true;
                assistantMsg.content = message;
                adapter.notifyItemChanged(assistantIndex);
                setStreaming(false);
                persistSession();
            }
        });
    }

    // ---------------- Image generation ----------------

    private void onImageGenClicked() {
        if (profile == null || !profile.supportsImageGen) return;
        String prompt = input.getText().toString().trim();
        if (TextUtils.isEmpty(prompt)) {
            Toast.makeText(this, "Type a prompt first, then tap the image icon", Toast.LENGTH_SHORT).show();
            return;
        }

        ChatMessage userMsg = new ChatMessage(ChatMessage.ROLE_USER, "🎨 " + prompt);
        session.messages.add(userMsg);
        adapter.notifyItemInserted(session.messages.size() - 1);
        input.setText("");
        scrollToBottom();

        if (session.title == null || "New Chat".equals(session.title)) {
            session.title = prompt.length() > 40 ? prompt.substring(0, 40) + "…" : prompt;
        }
        persistSession();

        ChatMessage placeholder = new ChatMessage(ChatMessage.ROLE_ASSISTANT, "Generating image…");
        session.messages.add(placeholder);
        int idx = session.messages.size() - 1;
        adapter.notifyItemInserted(idx);
        scrollToBottom();
        setStreaming(true);

        client.generateImage(profile, prompt, new OpenAiClient.ImageListener() {
            @Override
            public void onSuccess(String base64Png) {
                placeholder.content = "";
                placeholder.generatedImageBase64 = base64Png;
                setStreaming(false);
                session.updatedAt = System.currentTimeMillis();
                persistSession();
                adapter.notifyItemChanged(idx);
            }

            @Override
            public void onError(String message) {
                placeholder.isError = true;
                placeholder.content = message;
                setStreaming(false);
                persistSession();
                adapter.notifyItemChanged(idx);
            }
        });
    }

    // ---------------- Export / download ----------------

    private void exportChat() {
        if (session.messages.isEmpty()) {
            Toast.makeText(this, "Nothing to export yet", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            StringBuilder sb = new StringBuilder();
            sb.append("# ").append(session.title == null ? "Chat" : session.title).append("\n\n");
            for (ChatMessage m : session.messages) {
                String who = ChatMessage.ROLE_USER.equals(m.role) ? "**You**" : "**Assistant**";
                sb.append(who).append(":\n\n");
                if (m.attachmentName != null) sb.append("_[attached: ").append(m.attachmentName).append("]_\n\n");
                if (m.generatedImageBase64 != null) sb.append("_[generated image]_\n\n");
                sb.append(m.content == null ? "" : m.content).append("\n\n---\n\n");
            }

            File exportDir = new File(getCacheDir(), "exports");
            if (!exportDir.exists()) exportDir.mkdirs();
            String safeTitle = (session.title == null ? "chat" : session.title)
                    .replaceAll("[^a-zA-Z0-9-_ ]", "").trim();
            if (safeTitle.isEmpty()) safeTitle = "chat";
            File outFile = new File(exportDir, safeTitle + ".md");
            try (FileOutputStream fos = new FileOutputStream(outFile)) {
                fos.write(sb.toString().getBytes(StandardCharsets.UTF_8));
            }

            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", outFile);
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/markdown");
            shareIntent.putExtra(Intent.EXTRA_STREAM, uri);
            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(shareIntent, "Save or share chat"));
        } catch (Exception e) {
            Toast.makeText(this, "Export failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    // ---------------- Helpers ----------------

    private void setStreaming(boolean streaming) {
        isStreaming = streaming;
        typingIndicator.setVisibility(streaming ? View.VISIBLE : View.GONE);
        sendBtn.setImageResource(streaming ? R.drawable.ic_stop : R.drawable.ic_send);
    }

    private void persistSession() {
        if (!storage.loadPrefs().autoSaveChats()) return;
        for (int i = 0; i < allChats.size(); i++) {
            if (allChats.get(i).id.equals(session.id)) {
                allChats.set(i, session);
                storage.saveChats(allChats);
                return;
            }
        }
    }

    private void scrollToBottom() {
        recyclerView.post(() -> {
            if (adapter.getItemCount() > 0) {
                recyclerView.scrollToPosition(adapter.getItemCount() - 1);
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        client.cancel();
    }
}
