package com.codemate.ai.ui.adapter;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.codemate.ai.R;
import com.codemate.ai.data.ChatMessage;
import io.noties.markwon.Markwon;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MessageAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int TYPE_USER = 1;
    private static final int TYPE_ASSISTANT = 2;

    // Matches fenced code blocks (```lang\n...code...\n```) so line numbers can be
    // prefixed to each line when the "Show Line Numbers" setting is on.
    private static final Pattern FENCE_PATTERN =
            Pattern.compile("```[a-zA-Z0-9_+-]*\\n([\\s\\S]*?)```");

    private final List<ChatMessage> data;
    private final Markwon markwon;
    private final boolean showLineNumbers;

    public MessageAdapter(List<ChatMessage> data, Markwon markwon) {
        this(data, markwon, false);
    }

    public MessageAdapter(List<ChatMessage> data, Markwon markwon, boolean showLineNumbers) {
        this.data = data;
        this.markwon = markwon;
        this.showLineNumbers = showLineNumbers;
    }

    private String withLineNumbers(String markdown) {
        if (!showLineNumbers || markdown == null) return markdown;
        Matcher matcher = FENCE_PATTERN.matcher(markdown);
        StringBuffer out = new StringBuffer();
        while (matcher.find()) {
            String code = matcher.group(1);
            String[] lines = code.split("\n", -1);
            StringBuilder numbered = new StringBuilder();
            int width = String.valueOf(lines.length).length();
            for (int i = 0; i < lines.length; i++) {
                if (i == lines.length - 1 && lines[i].isEmpty()) break; // trailing newline
                numbered.append(String.format("%" + width + "d| ", i + 1)).append(lines[i]).append("\n");
            }
            String fenceStart = matcher.group(0).substring(0, matcher.group(0).indexOf('\n') + 1);
            String replacement = Matcher.quoteReplacement(fenceStart + numbered + "```");
            matcher.appendReplacement(out, replacement);
        }
        matcher.appendTail(out);
        return out.toString();
    }

    @Override
    public int getItemViewType(int position) {
        ChatMessage m = data.get(position);
        return ChatMessage.ROLE_USER.equals(m.role) ? TYPE_USER : TYPE_ASSISTANT;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        int layout = viewType == TYPE_USER ? R.layout.item_message_user : R.layout.item_message_assistant;
        View v = LayoutInflater.from(parent.getContext()).inflate(layout, parent, false);
        return viewType == TYPE_USER ? new UserVH(v) : new AssistantVH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ChatMessage m = data.get(position);
        String content = m.content == null ? "" : m.content;

        if (holder instanceof UserVH) {
            UserVH vh = (UserVH) holder;
            vh.text.setText(content);
            if (m.attachmentName != null) {
                vh.attachmentRow.setVisibility(View.VISIBLE);
                vh.attachmentName.setText("📎 " + m.attachmentName);
                if (m.attachmentImageBase64 != null) {
                    vh.attachmentThumb.setVisibility(View.VISIBLE);
                    Bitmap bmp = decodeBase64(m.attachmentImageBase64);
                    if (bmp != null) vh.attachmentThumb.setImageBitmap(bmp);
                } else {
                    vh.attachmentThumb.setVisibility(View.GONE);
                }
            } else {
                vh.attachmentRow.setVisibility(View.GONE);
            }
        } else {
            AssistantVH vh = (AssistantVH) holder;
            if (m.isError) {
                vh.text.setText("⚠ " + content);
                vh.generatedImage.setVisibility(View.GONE);
            } else {
                String rendered = content.isEmpty() && m.generatedImageBase64 == null ? "…" : withLineNumbers(content);
                markwon.setMarkdown(vh.text, rendered);
                vh.text.setVisibility(content.isEmpty() ? View.GONE : View.VISIBLE);
                if (m.generatedImageBase64 != null) {
                    vh.generatedImage.setVisibility(View.VISIBLE);
                    Bitmap bmp = decodeBase64(m.generatedImageBase64);
                    if (bmp != null) vh.generatedImage.setImageBitmap(bmp);
                } else {
                    vh.generatedImage.setVisibility(View.GONE);
                }
            }
        }
    }

    private Bitmap decodeBase64(String b64) {
        try {
            byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    static class UserVH extends RecyclerView.ViewHolder {
        TextView text;
        View attachmentRow;
        TextView attachmentName;
        ImageView attachmentThumb;

        UserVH(View itemView) {
            super(itemView);
            text = itemView.findViewById(R.id.text_message);
            attachmentRow = itemView.findViewById(R.id.row_attachment);
            attachmentName = itemView.findViewById(R.id.text_attachment_name);
            attachmentThumb = itemView.findViewById(R.id.image_attachment_thumb);
        }
    }

    static class AssistantVH extends RecyclerView.ViewHolder {
        TextView text;
        ImageView generatedImage;

        AssistantVH(View itemView) {
            super(itemView);
            text = itemView.findViewById(R.id.text_message);
            generatedImage = itemView.findViewById(R.id.image_generated);
        }
    }
}
