# Malayalam Cinema

Free-first online Malayalam film catalogue Android starter.

## Current app
- Apple-style dark cinematic UI
- Home / Years / Search / More
- Year timeline from 1928 to 2026
- Search UI ready for an online catalogue
- Wishlist/recent cache concept
- Internet permission included

## Data architecture for the next stage
Connect the app to a free-tier backend such as Supabase. Keep movie metadata online and cache recently viewed records locally. Posters should be served as small WebP thumbnails rather than bundled into the APK.

## Build
Java 17 + Gradle 8.10.2 / Android Gradle Plugin 8.7.3.
