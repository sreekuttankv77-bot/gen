package com.malayalamcinema.app;

import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private FrameLayout content;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        content = findViewById(R.id.content);

        findViewById(R.id.homeTab).setOnClickListener(v -> show(R.layout.home));
        findViewById(R.id.yearTab).setOnClickListener(v -> show(R.layout.years));
        findViewById(R.id.searchTab).setOnClickListener(v -> show(R.layout.search));
        findViewById(R.id.moreTab).setOnClickListener(v -> show(R.layout.more));

        show(R.layout.home);
    }

    private void show(int layout) {
        content.removeAllViews();
        View view = getLayoutInflater().inflate(layout, content, false);
        content.addView(view);
    }
}
