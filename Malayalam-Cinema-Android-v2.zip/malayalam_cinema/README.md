# Malayalam Cinema — Android XML

This is a complete Android project for the Malayalam Cinema app concept.

### Includes
- Android XML UI with Apple-inspired dark spacing and cards
- Search by film, actor, director, or genre
- Decade filters from the 1920s onward
- Offline starter catalogue stored in the app
- GitHub Actions workflow
- Java + XML only; no Firebase, Maps, booking, or paid API

### GitHub build
Upload the **contents of this ZIP to the repository root**. The workflow installs Gradle 8.10.2 and JDK 17, then runs `gradle assembleDebug`.

### Important
This ZIP does **not** contain a 7,000+ complete film database. It contains a small starter catalogue so the project stays light and the data can later be replaced with a properly sourced/licensed JSON or SQLite database.
